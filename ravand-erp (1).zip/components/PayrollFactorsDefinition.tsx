
import React, { useState, useMemo } from 'react';
import type { PayrollFactor, AccountHeadGroup } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';

// FIX: Add updatePayrollFactor and deletePayrollFactor to handle editing and removing factors.
interface PayrollFactorsDefinitionProps {
    payrollFactors: PayrollFactor[];
    addPayrollFactor: (factor: Omit<PayrollFactor, 'id'>) => void;
    updatePayrollFactor: (factor: PayrollFactor) => void;
    deletePayrollFactor: (factorId: number) => void;
    accountHeads: AccountHeadGroup[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, required, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <input id={id} required={required} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }> = ({ label, id, children, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <select id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500">
            {children}
        </select>
    </div>
);

const FormRadioGroup: React.FC<{ label: string; name: string; value: boolean; onChange: (value: boolean) => void; }> = ({ label, name, value, onChange }) => (
    <div className="sm:col-span-1">
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <div className="mt-2 flex items-center space-x-4 rtl:space-x-reverse">
            <label className="flex items-center">
                <input type="radio" name={name} checked={value === true} onChange={() => onChange(true)} className="form-radio h-4 w-4 text-cyan-600 border-slate-300 focus:ring-cyan-500" />
                <span className="mr-2 text-sm text-slate-700 dark:text-slate-300">بله</span>
            </label>
            <label className="flex items-center">
                <input type="radio" name={name} checked={value === false} onChange={() => onChange(false)} className="form-radio h-4 w-4 text-cyan-600 border-slate-300 focus:ring-cyan-500" />
                <span className="mr-2 text-sm text-slate-700 dark:text-slate-300">خیر</span>
            </label>
        </div>
    </div>
);

const statusLabels: Record<PayrollFactor['status'], string> = {
    contractual: 'قراردادی',
    active: 'فعال',
    inactive: 'غیرفعال'
};

const towerCalculationLabels: Record<PayrollFactor['towerCalculation'], string> = {
    fixed: 'برج ثابت',
    variable: 'برج متغیر'
};

const effectTypeLabels: Record<PayrollFactor['effectType'], string> = {
    increasing: 'افزاینده حقوق',
    decreasing: 'کاهنده حقوق'
};

const calculationBasisLabels: Record<PayrollFactor['calculationBasis'], string> = {
    daily: 'نسبت به کارکرد روزانه',
    fixed: 'مبلغ ثابت',
    base_salary: 'نسبت به حقوق پایه',
    effective_coefficient: 'ضریب موثر و کارکرد مستقل',
    variable_number: 'برای عدد متغیر'
};

const PayrollFactorsDefinition: React.FC<PayrollFactorsDefinitionProps> = ({ payrollFactors, addPayrollFactor, updatePayrollFactor, deletePayrollFactor, accountHeads }) => {
    
    const allSubLedgers = useMemo(() => {
        return accountHeads.flatMap(group => group.children.flatMap(ledger => ledger.children));
    }, [accountHeads]);

    const subLedgerMap = useMemo(() => {
        return new Map(allSubLedgers.map(sl => [sl.id, sl.title]));
    }, [allSubLedgers]);

    const subLedgerOptions = useMemo(() => {
        return allSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}` }));
    }, [allSubLedgers]);

    const initialState = {
        title: '',
        displayPriority: '',
        subjectToTax: true,
        subjectToInsurance: true,
        subjectToEidBonus: true,
        subjectToSeverance: true,
        subjectToVacationPay: true,
        status: 'active',
        towerCalculation: 'fixed',
        effectType: 'increasing',
        calculationBasis: 'daily',
        relatedLedger: null as number | null,
        hourlyRateCoefficient: '',
    };
    
    const [formData, setFormData] = useState(initialState);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleRadioChange = (name: string, value: boolean) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSelectChange = (name: string, value: string | number | null) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        const newFactor: Omit<PayrollFactor, 'id'> = {
            title: formData.title,
            displayPriority: Number(formData.displayPriority),
            subjectToTax: formData.subjectToTax,
            subjectToInsurance: formData.subjectToInsurance,
            subjectToEidBonus: formData.subjectToEidBonus,
            subjectToSeverance: formData.subjectToSeverance,
            subjectToVacationPay: formData.subjectToVacationPay,
            status: formData.status as any,
            towerCalculation: formData.towerCalculation as any,
            effectType: formData.effectType as any,
            calculationBasis: formData.calculationBasis as any,
            relatedLedger: formData.relatedLedger,
            hourlyRateCoefficient: formData.hourlyRateCoefficient ? Number(formData.hourlyRateCoefficient) : undefined,
        };

        addPayrollFactor(newFactor);
        setFormData(initialState);
        alert('عامل حقوق و دستمزد جدید با موفقیت ذخیره شد.');
    };

    const handleDelete = (factorId: number) => {
        if (window.confirm('آیا از حذف این عامل اطمینان دارید؟')) {
            deletePayrollFactor(factorId);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف عوامل حقوق و دستمزد</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8 divide-y divide-slate-200 dark:divide-slate-700">
                    <div className="space-y-6 pt-2">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">اطلاعات پایه</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">اطلاعات کلی و شناسایی عامل حقوق را وارد کنید.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormInput label="عنوان" id="title" name="title" type="text" value={formData.title} onChange={handleChange} required />
                            <FormInput label="اولویت نمایش" id="displayPriority" name="displayPriority" type="number" value={formData.displayPriority} onChange={handleChange} required />
                            <FormSelect label="وضعیت" id="status" name="status" value={formData.status} onChange={handleChange}>
                                <option value="contractual">قراردادی</option>
                                <option value="active">فعال</option>
                                <option value="inactive">غیرفعال</option>
                            </FormSelect>
                            <FormSelect label="نوع تاثیر" id="effectType" name="effectType" value={formData.effectType} onChange={handleChange}>
                                <option value="increasing">افزاینده حقوق</option>
                                <option value="decreasing">کاهنده حقوق</option>
                            </FormSelect>
                        </div>
                    </div>
                    
                    <div className="space-y-6 pt-8">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">مشمولیت‌ها</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">مشخص کنید این عامل مشمول کدام موارد قانونی می‌شود.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-8">
                            <FormRadioGroup label="مشمول مالیات حقوق" name="subjectToTax" value={formData.subjectToTax} onChange={(val) => handleRadioChange('subjectToTax', val)} />
                            <FormRadioGroup label="مشمول بیمه تأمین اجتماعی" name="subjectToInsurance" value={formData.subjectToInsurance} onChange={(val) => handleRadioChange('subjectToInsurance', val)} />
                            <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-6">
                                <FormRadioGroup label="مشمول عیدی" name="subjectToEidBonus" value={formData.subjectToEidBonus} onChange={(val) => handleRadioChange('subjectToEidBonus', val)} />
                                <FormRadioGroup label="مشمول سنوات" name="subjectToSeverance" value={formData.subjectToSeverance} onChange={(val) => handleRadioChange('subjectToSeverance', val)} />
                                <FormRadioGroup label="مشمول مانده مرخصی" name="subjectToVacationPay" value={formData.subjectToVacationPay} onChange={(val) => handleRadioChange('subjectToVacationPay', val)} />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6 pt-8">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">قوانین محاسبه</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">نحوه محاسبه این عامل را مشخص کنید.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormSelect label="مبنای محاسبه" id="calculationBasis" name="calculationBasis" value={formData.calculationBasis} onChange={handleChange}>
                                <option value="daily">نسبت به کارکرد روزانه</option>
                                <option value="fixed">مبلغ ثابت</option>
                                <option value="base_salary">نسبت به حقوق پایه</option>
                                <option value="effective_coefficient">نسبت به ضریب موثر و کارکرد مستقل</option>
                                <option value="variable_number">برای عدد متغیر</option>
                            </FormSelect>
                            <FormSelect label="محاسبه برج" id="towerCalculation" name="towerCalculation" value={formData.towerCalculation} onChange={handleChange}>
                                <option value="fixed">برج ثابت</option>
                                <option value="variable">برج متغیر</option>
                            </FormSelect>
                             <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">معین مرتبط</label>
                                <SearchableSelect 
                                    options={subLedgerOptions} 
                                    value={formData.relatedLedger} 
                                    onChange={val => handleSelectChange('relatedLedger', val)} 
                                    placeholder="انتخاب معین..."
                                />
                            </div>
                            <FormInput label="ضریب هر ساعت (اختیاری)" id="hourlyRateCoefficient" name="hourlyRateCoefficient" type="number" step="0.01" value={formData.hourlyRateCoefficient} onChange={handleChange} placeholder="مثال: 1.5"/>
                        </div>
                    </div>

                    <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
                            ذخیره عامل
                        </button>
                    </div>
                </form>
            </Card>

             <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">عوامل حقوق و دستمزد تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full w-max divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr className="divide-x divide-slate-200 dark:divide-slate-600">
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider sticky right-0 bg-slate-50 dark:bg-slate-700">عنوان</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">اولویت</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">وضعیت</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">نوع تاثیر</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مبنای محاسبه</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">محاسبه برج</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مشمول مالیات</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مشمول بیمه</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مشمول عیدی</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مشمول سنوات</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مشمول مانده مرخصی</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">معین مرتبط</th>
                            <th scope="col" className="px-3 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">ضریب ساعتی</th>
                            <th scope="col" className="px-3 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider sticky left-0 bg-slate-50 dark:bg-slate-700">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {payrollFactors.length > 0 ? (
                            payrollFactors.map((factor) => (
                                <tr key={factor.id} className="divide-x divide-slate-200 dark:divide-slate-600">
                                    <td className="px-3 py-4 whitespace-nowrap font-medium text-slate-900 dark:text-white sticky right-0 bg-white dark:bg-slate-800">{factor.title}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.displayPriority}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{statusLabels[factor.status]}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{effectTypeLabels[factor.effectType]}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{calculationBasisLabels[factor.calculationBasis]}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{towerCalculationLabels[factor.towerCalculation]}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.subjectToTax ? 'بله' : 'خیر'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.subjectToInsurance ? 'بله' : 'خیر'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.subjectToEidBonus ? 'بله' : 'خیر'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.subjectToSeverance ? 'بله' : 'خیر'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.subjectToVacationPay ? 'بله' : 'خیر'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.relatedLedger ? subLedgerMap.get(factor.relatedLedger) : '-'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{factor.hourlyRateCoefficient ?? '-'}</td>
                                    <td className="px-3 py-4 whitespace-nowrap text-center space-x-2 rtl:space-x-reverse sticky left-0 bg-white dark:bg-slate-800">
                                        <button className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(factor.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={14} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز عاملی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

        </div>
    );
};

export default PayrollFactorsDefinition;
