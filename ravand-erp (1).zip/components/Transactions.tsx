
import React, { useState, useMemo } from 'react';
import type { Transaction, Account } from '../types';
import { TransactionType } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';


interface TransactionsProps {
  transactions: Transaction[];
  accounts: Account[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
}

const TransactionForm: React.FC<{
  accounts: Account[];
  onSubmit: (transaction: Omit<Transaction, 'id'>) => void;
  onClose: () => void;
}> = ({ accounts, onSubmit, onClose }) => {
  const [description, setDescription] = useState('');
  const [accountId, setAccountId] = useState<number | null>(accounts[0]?.id || null);
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<TransactionType>(TransactionType.Expense);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount || !accountId) return;
    
    onSubmit({
      description,
      accountId: Number(accountId),
      amount: Number(amount),
      date,
      type,
    });
    onClose();
  };
  
  const accountOptions = useMemo(() => accounts.map(acc => ({ value: acc.id, label: acc.name })), [accounts]);
  const typeOptions = [
      { value: TransactionType.Income, label: TransactionType.Income },
      { value: TransactionType.Expense, label: TransactionType.Expense },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">توضیحات</label>
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
          required
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium">مبلغ (تومان)</label>
          <FormattedNumberInput
            value={amount}
            onValueChange={setAmount}
            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium">تاریخ</label>
          <ShamsiDatePicker
            value={date}
            onChange={setDate}
            className="mt-1 block w-full"
            required
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium">نوع</label>
           <SearchableSelect options={typeOptions} value={type} onChange={val => setType(val as TransactionType)} />
        </div>
        <div>
          <label className="block text-sm font-medium">حساب</label>
          <SearchableSelect options={accountOptions} value={accountId} onChange={val => setAccountId(val as number)} />
        </div>
      </div>
      <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
          لغو
        </button>
        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
          ثبت تراکنش
        </button>
      </div>
    </form>
  );
};


const Transactions: React.FC<TransactionsProps> = ({ transactions, accounts, addTransaction }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const accountMap = useMemo(() => {
    return accounts.reduce((map, acc) => {
      map[acc.id] = acc.name;
      return map;
    }, {} as { [key: number]: string });
  }, [accounts]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تراکنش‌ها</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-custom-blue-primary"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          تراکنش جدید
        </button>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">تاریخ</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">توضیحات</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">حساب</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">نوع</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مبلغ</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {transactions.map((t) => (
                <tr key={t.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{toShamsi(t.date)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{t.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{accountMap[t.accountId]}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        t.type === TransactionType.Income
                          ? 'bg-custom-blue-light/70 text-blue-800 dark:bg-blue-900/50 dark:text-custom-blue-light'
                          : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                      }`}>
                      {t.type}
                    </span>
                  </td>
                  <td className={`px-6 py-4 whitespace-nowrap text-sm text-left font-semibold ${t.type === TransactionType.Income ? 'text-custom-blue-primary' : 'text-red-600'}`}>
                    {new Intl.NumberFormat('en-US').format(t.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="افزودن تراکنش جدید">
        <TransactionForm accounts={accounts} onSubmit={addTransaction} onClose={() => setIsModalOpen(false)} />
      </Modal>

    </div>
  );
};

export default Transactions;
