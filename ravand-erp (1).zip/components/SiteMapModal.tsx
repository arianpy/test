import React, { useState } from 'react';
import Modal from './ui/Modal';
import { sidebarStructure, GroupItem, ModuleItem, SubViewGroup, SubViewSimple, SubViewEntry } from '../data/sidebarStructure';
import type { SubView } from '../App';
import GanttChart, { generateGanttData } from './GanttChart';

type FormFieldMap = Partial<Record<SubView, string[]>>;
type FormTypeMap = Partial<Record<SubView, 'Data Entry' | 'Data Analysis'>>;

interface SiteMapModalProps {
    isOpen: boolean;
    onClose: () => void;
    formFields: FormFieldMap;
    formTypes: FormTypeMap;
}

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

const SiteMapModal: React.FC<SiteMapModalProps> = ({ isOpen, onClose, formFields, formTypes }) => {
    const [activeTab, setActiveTab] = useState('map');
    const [expandedFields, setExpandedFields] = useState<Record<string, boolean>>({});

    const toggleFields = (id: string) => {
        setExpandedFields(prev => ({ ...prev, [id]: !prev[id] }));
    };
    
    const handleMapExport = () => {
        const headers = ["سطح ۱", "سطح ۲", "سطح ۳", "فرم", "تعداد فیلد", "نوع فرم", "فیلد"];
        const csvRows: (string|number)[][] = [];
    
        const traverse = (items: (GroupItem | ModuleItem | SubViewEntry)[], path: string[]) => {
            items.forEach(item => {
                const currentPath = [...path, item.label];
                const children = 'modules' in item ? item.modules : ('subViews' in item ? item.subViews : []);
    
                if (!('type' in item) || (item.type !== 'group' && item.type !== 'module' && item.type !== 'subgroup')) {
                    const subViewItem = item as SubViewSimple;
                    const fields = formFields[subViewItem.id as SubView] || [];
                    const fieldCount = fields.length;
                    const type = formTypes[subViewItem.id as SubView] || 'نامشخص';
                    const typeText = fieldCount > 0 ? (type === 'Data Entry' ? 'ورود اطلاعات (فرانت)' : 'تحلیل داده (بک اند)') : '';
    
                    if (fields.length > 0) {
                        fields.forEach(field => {
                            const row = new Array(headers.length).fill('');
                            for(let i=0; i < currentPath.length && i < 4; i++) {
                                row[i] = currentPath[i];
                            }
                            row[4] = fieldCount;
                            row[5] = typeText;
                            row[6] = field;
                            csvRows.push(row);
                        });
                    } else {
                        const row = new Array(headers.length).fill('');
                        for(let i=0; i < currentPath.length && i < 4; i++) {
                            row[i] = currentPath[i];
                        }
                        row[4] = 0;
                        csvRows.push(row);
                    }
                } else {
                    const row = new Array(headers.length).fill('');
                    for(let i=0; i < currentPath.length && i < 4; i++) {
                        row[i] = currentPath[i];
                    }
                    csvRows.push(row);
    
                    if (children.length > 0) {
                        traverse(children, currentPath);
                    }
                }
            });
        };
    
        traverse(sidebarStructure, []);
        exportToCsv('نقشه-برنامه.csv', [headers, ...csvRows]);
    };
    
    const handleGanttExport = () => {
        const { tasks, totalHours } = generateGanttData({ formFields, formTypes });
        
        if (tasks.length === 0) {
            alert("داده‌ای برای خروجی گرفتن وجود ندارد.");
            return;
        }

        const totalDays = Math.ceil(totalHours / 8);
        const headers: (string | number)[] = ["Task Name", "Team", "Total Fields"];
        for (let i = 1; i <= totalDays; i++) {
            headers.push(`Day ${i}`);
        }

        const csvRows = tasks.map(task => {
            const numFields = task.fieldCount;
            const taskDurationHours = task.duration;
            const row: (string | number)[] = [task.name, task.team, numFields];

            for (let d = 1; d <= totalDays; d++) {
                const dayStartHour = (d - 1) * 8;
                const dayEndHour = d * 8;
                const taskStartHour = task.start;
                const taskEndHour = task.start + taskDurationHours;

                const overlapStart = Math.max(dayStartHour, taskStartHour);
                const overlapEnd = Math.min(dayEndHour, taskEndHour);
                const overlapHours = Math.max(0, overlapEnd - overlapStart);

                if (overlapHours > 0 && taskDurationHours > 0) {
                    const workForDay = (numFields / taskDurationHours) * overlapHours;
                    row.push(workForDay.toFixed(2));
                } else {
                    row.push('');
                }
            }
            return row;
        });
        
        exportToCsv('gantt-chart-ms-project-style.csv', [headers, ...csvRows]);
    };

    const renderNode = (item: GroupItem | ModuleItem | SubViewEntry, level = 0): React.ReactElement => {
        const padding = `${level * 24}px`;
        const itemKey = 'id' in item ? item.id : `subgroup-${item.label}`;
        
        if ('type' in item && (item.type === 'group' || item.type === 'module' || item.type === 'subgroup')) {
            const children = 'modules' in item ? item.modules : item.subViews;
            let bgClass = 'bg-slate-100 dark:bg-slate-700/50';
            let textClass = 'font-semibold text-slate-800 dark:text-slate-200';
            if (level === 0) { bgClass = 'bg-slate-200 dark:bg-slate-800'; textClass = 'font-bold text-lg'; }
            if (level === 2) { bgClass = 'bg-slate-50 dark:bg-slate-700/30'; textClass = 'font-medium'; }

            return (
                <div key={itemKey}>
                    <div className={`p-2 rounded-t-md ${bgClass}`} style={{ paddingRight: padding }}>
                        <p className={textClass}>{item.label}</p>
                    </div>
                    <div className="border-r-2 dark:border-slate-600" style={{ marginRight: padding }}>
                        {children.map(child => renderNode(child, level + 1))}
                    </div>
                </div>
            );
        } else { // SubViewSimple
            const subViewItem = item as SubViewSimple;
            const fields = formFields[subViewItem.id as SubView] || [];
            const fieldCount = fields.length;
            const type = formTypes[subViewItem.id as SubView] || 'نامشخص';
            const typeText = type === 'Data Entry' ? 'ورود اطلاعات (فرانت)' : 'تحلیل داده (بک اند)';
            const isExpanded = expandedFields[subViewItem.id];

            return (
                 <div key={subViewItem.id} className="pt-2" style={{ paddingRight: padding }}>
                    <div className="flex items-center">
                         {fieldCount > 0 && (
                            <button onClick={() => toggleFields(subViewItem.id)} className="ml-2 p-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200">
                                <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
                            </button>
                        )}
                        <p className="font-medium text-cyan-600 dark:text-cyan-400">
                            {subViewItem.label}
                            {fieldCount > 0 && (
                                <span className="text-xs font-normal text-slate-500 dark:text-slate-400 mr-2">
                                    (فیلدها: {fieldCount}، نوع: {typeText})
                                </span>
                            )}
                        </p>
                    </div>
                     {isExpanded && fieldCount > 0 && (
                        <ul className="mt-2 mr-8 pr-4 border-r-2 border-slate-300 dark:border-slate-600 space-y-1 text-sm text-slate-600 dark:text-slate-400 list-disc list-inside">
                            {fields.map((field, index) => (
                                <li key={index}>{field}</li>
                            ))}
                        </ul>
                    )}
                </div>
            );
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="پلتفرم در یک نگاه" size="7xl">
            <div className="flex justify-between items-center mb-4">
                <div className="flex border-b border-slate-300 dark:border-slate-600">
                    <button
                        onClick={() => setActiveTab('map')}
                        className={`px-4 py-2 text-sm font-medium transition-colors duration-200 focus:outline-none ${
                            activeTab === 'map'
                                ? 'border-b-2 border-custom-blue-primary text-custom-blue-primary'
                                : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                        }`}
                    >
                        نقشه برنامه
                    </button>
                    <button
                        onClick={() => setActiveTab('gantt')}
                        className={`px-4 py-2 text-sm font-medium transition-colors duration-200 focus:outline-none ${
                            activeTab === 'gantt'
                                ? 'border-b-2 border-custom-blue-primary text-custom-blue-primary'
                                : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                        }`}
                    >
                        گانت چارت عملیاتی
                    </button>
                </div>
                <div>
                    {activeTab === 'map' && (
                        <button onClick={handleMapExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                            خروجی اکسل نقشه
                        </button>
                    )}
                    {activeTab === 'gantt' && (
                        <button onClick={handleGanttExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                            خروجی اکسل گانت
                        </button>
                    )}
                </div>
            </div>

            {activeTab === 'map' ? (
                <div className="p-4 bg-white dark:bg-slate-900 border dark:border-slate-700 rounded-lg max-h-[70vh] overflow-auto space-y-2">
                    {sidebarStructure.map(item => renderNode(item))}
                </div>
            ) : (
                <div className="max-h-[70vh] overflow-auto">
                    <GanttChart formFields={formFields} formTypes={formTypes} />
                </div>
            )}
        </Modal>
    );
};

export default SiteMapModal;