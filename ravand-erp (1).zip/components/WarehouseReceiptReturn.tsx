import React, { useState, useMemo, useEffect } from 'react';
import type {
    WarehouseReceiptReturn,
    WarehouseReceipt,
    WarehouseReceiptItem,
    Warehouse,
    PurchaseItem,
} from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';

interface WarehouseReceiptReturnProps {
    receiptReturns: WarehouseReceiptReturn[];
    // FIX: Updated prop type to match what App.tsx provides, which is an object without Auditable fields.
    addReceiptReturn: (receiptReturn: Omit<WarehouseReceiptReturn, 'id'>) => void;
    receipts: WarehouseReceipt[];
    warehouses: Warehouse[];
    purchaseItems: PurchaseItem[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        <input id={id} {...props} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-700" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const WarehouseReceiptReturnComponent: React.FC<WarehouseReceiptReturnProps> = ({ receiptReturns, addReceiptReturn, receipts, warehouses, purchaseItems }) => {
    
    const getInitialState = () => ({
        originalReceiptId: null as number | null,
        warehouseId: '',
        returnToName: '',
        docNumber: '',
        date: new Date().toISOString().split('T')[0],
        description: '',
    });
    
    const [header, setHeader] = useState(getInitialState());
    const [items, setItems] = useState<Omit<WarehouseReceiptItem, 'id'>[]>([]);

    const purchaseItemMap = useMemo(() => purchaseItems.reduce((map, item) => {
        map[item.id] = item;
        return map;
    }, {} as Record<number, PurchaseItem>), [purchaseItems]);

    useEffect(() => {
        if (header.originalReceiptId) {
            const selectedReceipt = receipts.find(r => r.id === header.originalReceiptId);
            if (selectedReceipt) {
                setItems(selectedReceipt.items.map(item => ({...item, quantity: 0}))); // Set initial return quantity to 0
                setHeader(prev => ({
                    ...prev,
                    warehouseId: selectedReceipt.warehouseId.toString(),
                    returnToName: selectedReceipt.delivererName,
                }));
            }
        } else {
            setItems([]);
            setHeader(prev => ({...prev, warehouseId: '', returnToName: ''}));
        }
    }, [header.originalReceiptId, receipts]);

    const handleHeaderChange = (field: keyof typeof header, value: any) => {
        setHeader(prev => ({ ...prev, [field]: value }));
    };
    
    const handleItemChange = (index: number, field: keyof Omit<WarehouseReceiptItem, 'id'>, value: string | number) => {
        const newItems = [...items];
        const originalReceipt = receipts.find(r => r.id === header.originalReceiptId);
        const originalItem = originalReceipt?.items.find(i => i.purchaseItemId === newItems[index].purchaseItemId);
        
        if (field === 'quantity' && originalItem && Number(value) > originalItem.quantity) {
             alert(`تعداد برگشتی نمی‌تواند بیشتر از تعداد رسید شده (${originalItem.quantity}) باشد.`);
            (newItems[index] as any)[field] = originalItem.quantity;
        } else {
            (newItems[index] as any)[field] = value;
        }
        setItems(newItems);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!header.originalReceiptId || !header.warehouseId) {
            alert('لطفا رسید اصلی و انبار را انتخاب کنید.');
            return;
        }
        const returnedItems = items.filter(i => i.quantity > 0);
        if (returnedItems.length === 0) {
            alert('لطفا تعداد کالاهای برگشتی را مشخص کنید.');
            return;
        }

// FIX: Added auditable properties to satisfy the WarehouseReceiptReturn type.
        addReceiptReturn({
            ...header,
            warehouseId: Number(header.warehouseId),
            originalReceiptId: Number(header.originalReceiptId),
            items: returnedItems.map(item => ({...item, id: Date.now() + Math.random()})),
            createdAt: new Date().toISOString(),
            createdBy: 'کاربر تست',
            updatedAt: new Date().toISOString(),
            updatedBy: 'کاربر تست',
        });
        setHeader(getInitialState());
        setItems([]);
        alert('برگشت از رسید انبار با موفقیت ثبت شد.');
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت برگشت رسید انبار</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 border rounded-lg dark:border-slate-700">
                        <CustomFormSelect label="انتخاب رسید اصلی">
                           <SearchableSelect options={receipts.map(r=>({value: r.id, label: `${r.docNumber} - ${r.delivererName}`}))} value={header.originalReceiptId} onChange={val => handleHeaderChange('originalReceiptId', val)} />
                        </CustomFormSelect>
                        <FormInput label="شماره سند برگشتی" name="docNumber" value={header.docNumber} onChange={e => handleHeaderChange('docNumber', e.target.value)} required/>
                        <FormInput label="تاریخ" name="date" type="date" value={header.date} onChange={e => handleHeaderChange('date', e.target.value)} required />
                        <CustomFormSelect label="انبار">
                           <SearchableSelect options={warehouses.map(w => ({ value: w.id, label: w.name }))} value={header.warehouseId} onChange={() => {}} disabled />
                        </CustomFormSelect>
                        <FormInput label="تحویل به" name="returnToName" value={header.returnToName} disabled />
                    </div>
                    
                    <div className="space-y-4 pt-4 border-t dark:border-slate-700">
                        <h3 className="text-lg font-semibold">اقلام برگشتی</h3>
                         <div className="overflow-x-auto">
                             <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                                 <thead className="bg-slate-50 dark:bg-slate-700">
                                     <tr>
                                         <th className="px-2 py-3 text-right font-medium">کالا</th>
                                         <th className="px-2 py-3 text-right font-medium">تعداد رسید شده</th>
                                         <th className="px-2 py-3 text-right font-medium">تعداد برگشتی</th>
                                     </tr>
                                 </thead>
                                 <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                     {items.map((item, index) => {
                                        const originalQty = receipts.find(r => r.id === header.originalReceiptId)?.items.find(i => i.purchaseItemId === item.purchaseItemId)?.quantity || 0;
                                        return (
                                         <tr key={index}>
                                             <td className="p-2">{purchaseItemMap[item.purchaseItemId]?.title || '-'}</td>
                                             <td className="p-2 text-center">{originalQty}</td>
                                             <td className="p-1 w-32"><FormattedNumberInput value={item.quantity} onValueChange={val => handleItemChange(index, 'quantity', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                         </tr>
                                     )})}
                                     {items.length === 0 && (
                                        <tr><td colSpan={3} className="text-center py-4 text-slate-500 dark:text-slate-400">لطفا یک رسید اصلی انتخاب کنید.</td></tr>
                                     )}
                                 </tbody>
                             </table>
                         </div>
                    </div>

                    <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ثبت برگشت رسید</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">رسیدهای برگشتی ثبت شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">تاریخ</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شماره سند برگشتی</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شماره رسید اصلی</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">تحویل به</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {receiptReturns.length > 0 ? (
                            receiptReturns.map((rr) => (
                                <tr key={rr.id}>
                                    <td className="px-4 py-4">{new Date(rr.date).toLocaleDateString('fa-IR')}</td>
                                    <td className="px-4 py-4">{rr.docNumber}</td>
                                    <td className="px-4 py-4">{receipts.find(r => r.id === rr.originalReceiptId)?.docNumber || rr.originalReceiptId}</td>
                                    <td className="px-4 py-4">{rr.returnToName}</td>
                                </tr>
                            ))
                        ) : (
                            <tr><td colSpan={4} className="text-center py-4">سندی ثبت نشده است.</td></tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

        </div>
    );
};

export default WarehouseReceiptReturnComponent;
