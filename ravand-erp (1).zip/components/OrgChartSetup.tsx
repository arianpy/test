
import React, { useState, useEffect } from 'react';
import type { OrgChartNode } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';

// Preview Modal Component with new graphical tree view
const OrgChartPreviewModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    nodes: OrgChartNode[];
}> = ({ isOpen, onClose, nodes }) => {
    
    const handlePrint = () => {
        const printContents = document.getElementById('printable-chart-area')?.innerHTML;
        const originalContents = document.body.innerHTML;
        if (printContents) {
            document.body.innerHTML = `
                <html>
                    <head>
                        <title>چارت سازمانی</title>
                        <script src="https://cdn.tailwindcss.com"></script>
                         <link rel="stylesheet" href="https://cdn.font-face.ir/css/vazir/vazir.css" />
                        <style>
                            body { 
                                font-family: Vazir, sans-serif;
                                direction: rtl; 
                            }
                            @page {
                                size: A3 landscape;
                                margin: 20px;
                            }
                            .dark {
                                --tw-bg-opacity: 1;
                                background-color: rgb(255 255 255 / var(--tw-bg-opacity));
                            }
                             .dark\\:bg-slate-800 {
                                --tw-bg-opacity: 1;
                                background-color: rgb(255 255 255 / var(--tw-bg-opacity)) !important;
                             }
                            .dark\\:text-slate-200 {
                                --tw-text-opacity: 1;
                                color: rgb(0 0 0 / var(--tw-text-opacity)) !important;
                            }
                             .dark\\:bg-slate-700 {
                                 --tw-bg-opacity: 1;
                                 background-color: rgb(241 245 249 / var(--tw-bg-opacity)) !important;
                             }
                              .dark\\:border-slate-500 {
                                  --tw-border-opacity: 1;
                                  border-color: rgb(156 163 175 / var(--tw-border-opacity)) !important;
                              }
                        </style>
                    </head>
                    <body>${printContents}</body>
                </html>
            `;
            window.print();
            document.body.innerHTML = originalContents;
            // We need to re-trigger the app's event listeners if they were lost
            window.location.reload(); 
        }
    };

    const ChartNode: React.FC<{ node: OrgChartNode; level?: number }> = ({ node, level = 0 }) => {
        const colors = [
            'bg-sky-100 border-sky-300 text-sky-800 dark:bg-sky-900/50 dark:border-sky-700 dark:text-sky-200',
            'bg-green-100 border-green-300 text-green-800 dark:bg-green-900/50 dark:border-green-700 dark:text-green-200',
            'bg-amber-100 border-amber-300 text-amber-800 dark:bg-amber-900/50 dark:border-amber-700 dark:text-amber-200',
            'bg-indigo-100 border-indigo-300 text-indigo-800 dark:bg-indigo-900/50 dark:border-indigo-700 dark:text-indigo-200',
            'bg-pink-100 border-pink-300 text-pink-800 dark:bg-pink-900/50 dark:border-pink-700 dark:text-pink-200',
            'bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900/50 dark:border-teal-700 dark:text-teal-200',
        ];
        const colorClass = colors[level % colors.length];

        return (
             <div className="inline-flex flex-col items-center text-center">
                <div className={`px-6 py-3 rounded-lg border-2 shadow-md ${colorClass} min-w-[150px]`}>
                    <p className="font-semibold">{node.title}</p>
                </div>
                {node.children?.length > 0 && (
                    <div className="flex pt-12 relative">
                        {/* vertical line from parent down */}
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-12 bg-slate-400 dark:bg-slate-500"></div>
                        {node.children.map((child, index) => (
                            <div key={child.id} className="px-4 relative">
                                {/* horizontal line */}
                                <div className={`absolute top-12 h-0.5 bg-slate-400 dark:bg-slate-500
                                    ${index === 0 ? 'left-1/2' : 'left-0'}
                                    ${index === node.children.length - 1 ? 'right-1/2' : 'right-0'}
                                    ${node.children.length === 1 ? 'hidden' : ''}
                                `}></div>
                                {/* vertical line from child up */}
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-12 bg-slate-400 dark:bg-slate-500"></div>
                                <ChartNode node={child} level={level + 1} />
                            </div>
                        ))}
                    </div>
                )}
            </div>
        );
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="پیش‌نمایش چارت سازمانی" size="5xl">
             <div id="printable-chart-area" className="printable-area p-4 bg-white dark:bg-slate-800 overflow-x-auto">
                <h2 className="text-2xl font-bold text-center mb-12 text-slate-800 dark:text-slate-200">چارت سازمانی</h2>
                 <div className="flex justify-center">
                    {nodes.length > 0 ? (
                        <div className="inline-block">
                            {nodes.map(node => <ChartNode key={node.id} node={node} level={0} />)}
                        </div>
                    ) : (
                        <p className="text-center py-8">چارت سازمانی تعریف نشده است.</p>
                    )}
                 </div>
            </div>
            <div className="flex justify-end pt-4 mt-4 border-t dark:border-slate-600 no-print">
                <button onClick={handlePrint} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">خروجی PDF</button>
            </div>
        </Modal>
    );
};


// Main Component
// FIX: Add deleteNode prop to handle deleting nodes.
interface OrgChartSetupProps {
    nodes: OrgChartNode[];
    addNode: (node: Omit<OrgChartNode, 'id' | 'children'>) => void;
    updateNode: (nodeId: number, newTitle: string) => void;
    deleteNode: (nodeId: number) => void;
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
    </div>
);

const NodeTree: React.FC<{ 
    nodes: OrgChartNode[]; 
    onAddSubNode: (parentId: number, parentTitle: string) => void;
    onEditNode: (nodeId: number, currentTitle: string) => void;
    // FIX: Add onDeleteNode prop for handling deletions.
    onDeleteNode: (nodeId: number, nodeTitle: string) => void;
}> = ({ nodes, onAddSubNode, onEditNode, onDeleteNode }) => {
    
    const renderNode = (node: OrgChartNode) => (
        <li key={node.id}>
            <div className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg flex justify-between items-center">
                <span className="font-medium text-slate-800 dark:text-slate-200">{node.title}</span>
                <div className="flex space-x-2 rtl:space-x-reverse">
                    <button onClick={() => onDeleteNode(node.id, node.title)} className="text-xs px-3 py-1 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 rounded-full hover:bg-red-200">حذف</button>
                    <button onClick={() => onEditNode(node.id, node.title)} className="text-xs px-3 py-1 bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300 rounded-full hover:bg-amber-200">ویرایش</button>
                    <button onClick={() => onAddSubNode(node.id, node.title)} className="text-xs px-3 py-1 bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300 rounded-full hover:bg-cyan-200">افزودن زیرمجموعه</button>
                </div>
            </div>
            {node.children && node.children.length > 0 && (
                <ul className="mt-2 mr-6 pr-6 border-r-2 border-slate-200 dark:border-slate-600 space-y-2">
                    {node.children.map(child => renderNode(child))}
                </ul>
            )}
        </li>
    );

    return <ul className="space-y-2">{nodes.map(node => renderNode(node))}</ul>;
};


const OrgChartSetup: React.FC<OrgChartSetupProps> = ({ nodes, addNode, updateNode, deleteNode }) => {
    const [rootNodeTitle, setRootNodeTitle] = useState('');
    const [isAddModalOpen, setAddModalOpen] = useState(false);
    const [subNodeTitle, setSubNodeTitle] = useState('');
    const [parentInfo, setParentInfo] = useState<{ id: number; title: string } | null>(null);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [editedNodeTitle, setEditedNodeTitle] = useState('');
    const [editingNodeInfo, setEditingNodeInfo] = useState<{ id: number; title: string } | null>(null);
    const [isPreviewModalOpen, setPreviewModalOpen] = useState(false);

    useEffect(() => { if (editingNodeInfo) { setEditedNodeTitle(editingNodeInfo.title); } }, [editingNodeInfo]);

    const handleAddRootNode = (e: React.FormEvent) => {
        e.preventDefault();
        if (!rootNodeTitle.trim()) return;
        addNode({ title: rootNodeTitle, parentId: null });
        setRootNodeTitle('');
    };

    const handleOpenSubNodeModal = (parentId: number, parentTitle: string) => {
        setParentInfo({ id: parentId, title: parentTitle });
        setAddModalOpen(true);
    };

    const handleCloseAddModal = () => {
        setAddModalOpen(false);
        setSubNodeTitle('');
        setParentInfo(null);
    };

    const handleAddSubNode = (e: React.FormEvent) => {
        e.preventDefault();
        if (!subNodeTitle.trim() || !parentInfo) return;
        addNode({ title: subNodeTitle, parentId: parentInfo.id });
        handleCloseAddModal();
    };

    const handleOpenEditModal = (nodeId: number, currentTitle: string) => {
        setEditingNodeInfo({ id: nodeId, title: currentTitle });
        setEditModalOpen(true);
    };
    
    const handleCloseEditModal = () => {
        setEditModalOpen(false);
        setEditedNodeTitle('');
        setEditingNodeInfo(null);
    };

    const handleUpdateNode = (e: React.FormEvent) => {
        e.preventDefault();
        if (!editedNodeTitle.trim() || !editingNodeInfo) return;
        updateNode(editingNodeInfo.id, editedNodeTitle);
        handleCloseEditModal();
    };

    const handleDeleteNode = (nodeId: number, nodeTitle: string) => {
        if (window.confirm(`آیا از حذف واحد "${nodeTitle}" و تمام زیرمجموعه‌های آن اطمینان دارید؟`)) {
            deleteNode(nodeId);
        }
    };


    return (
        <div className="space-y-6">
             <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیم چارت سازمانی</h1>
                <button onClick={() => setPreviewModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">پیش‌نمایش</button>
            </div>
            
            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">تعریف و مدیریت چارت</h2>
                <div className="p-4 border rounded-lg dark:border-slate-700 mb-6 bg-slate-50 dark:bg-slate-800">
                    <form onSubmit={handleAddRootNode} className="flex flex-col sm:flex-row items-end sm:space-x-4 sm:rtl:space-x-reverse space-y-4 sm:space-y-0">
                        <div className="flex-grow w-full">
                            <FormInput label="عنوان واحد اصلی جدید" id="rootNodeTitle" value={rootNodeTitle} onChange={(e) => setRootNodeTitle(e.target.value)} required />
                        </div>
                        <button type="submit" className="w-full sm:w-auto px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 h-10 flex-shrink-0">افزودن</button>
                    </form>
                </div>

                <div>
                    <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-slate-200">ساختار سازمانی</h3>
                    {nodes.length > 0 ? (
                       <NodeTree nodes={nodes} onAddSubNode={handleOpenSubNodeModal} onEditNode={handleOpenEditModal} onDeleteNode={handleDeleteNode} />
                    ) : (
                        <p className="text-center text-slate-500 py-4">هنوز واحدی تعریف نشده است.</p>
                    )}
                </div>
            </Card>
            
            {parentInfo && (
                <Modal isOpen={isAddModalOpen} onClose={handleCloseAddModal} title={`افزودن زیرمجموعه به "${parentInfo.title}"`}>
                    <form onSubmit={handleAddSubNode} className="space-y-4">
                        <FormInput label="عنوان زیرمجموعه" value={subNodeTitle} onChange={(e) => setSubNodeTitle(e.target.value)} required/>
                         <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                            <button type="button" onClick={handleCloseAddModal} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                            <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                        </div>
                    </form>
                </Modal>
            )}

            {editingNodeInfo && (
                <Modal isOpen={isEditModalOpen} onClose={handleCloseEditModal} title={`ویرایش عنوان واحد "${editingNodeInfo.title}"`}>
                     <form onSubmit={handleUpdateNode} className="space-y-4">
                        <FormInput label="عنوان جدید" value={editedNodeTitle} onChange={(e) => setEditedNodeTitle(e.target.value)} required />
                         <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                            <button type="button" onClick={handleCloseEditModal} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                            <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                        </div>
                    </form>
                </Modal>
            )}

            <OrgChartPreviewModal isOpen={isPreviewModalOpen} onClose={() => setPreviewModalOpen(false)} nodes={nodes} />
        </div>
    );
};

export default OrgChartSetup;
