

import React, { useState, useMemo } from 'react';
import type { Transaction, SalesInvoice, PurchaseInvoice, Product, PurchaseItem, FiscalYear, ProductManufacturing } from '../types';
import Card from './ui/Card';
import MonthlySummaryChart from './MonthlySummaryChart';
import { toJalaali } from '../utils/jalali';
import { getShamsiMonthName } from '../utils/date';

interface DashboardProps {
    transactions: Transaction[];
    metrics: {
        totalIncome: number;
        totalExpense: number;
        netProfit: number;
    };
    salesInvoices: SalesInvoice[];
    purchaseInvoices: PurchaseInvoice[];
    products: Product[];
    purchaseItems: PurchaseItem[];
    fiscalYears: FiscalYear[];
    activeFiscalYearId: number | null;
    exchangeRate: number;
}

const SummaryCard: React.FC<{ title: string; amount: number; color: string }> = ({ title, amount, color }) => (
  <Card className="flex-1">
    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 truncate">{title}</h3>
    <p className={`mt-1 text-3xl font-semibold ${color}`}>
      {new Intl.NumberFormat('en-US').format(amount)}
      <span className="text-lg font-normal"> تومان</span>
    </p>
  </Card>
);

const Dashboard: React.FC<DashboardProps> = ({ 
    transactions, 
    metrics,
    salesInvoices,
    purchaseInvoices,
    products,
    purchaseItems,
    fiscalYears,
    activeFiscalYearId,
    exchangeRate,
 }) => {
  const { totalIncome, totalExpense, netProfit } = metrics;
  const [activeTab, setActiveTab] = useState('accounting');

  const tabLabels: Record<string, string> = {
    accounting: 'مدیریت حسابداری',
    budget: 'مدیریت بودجه',
    sales: 'مدیریت فروش',
    trends: 'مدیریت روندها',
  };
  
    const activeFiscalYear = useMemo(() => fiscalYears.find(fy => fy.id === activeFiscalYearId), [fiscalYears, activeFiscalYearId]);
    const mainCurrency = activeFiscalYear?.mainCurrency || 'IRR';
    const secondaryCurrency = activeFiscalYear?.secondaryCurrency || 'USD';
    
    const salesChartData = useMemo(() => {
        const monthlyData: { [key: string]: number } = {}; // Key: YYYY-MM
        salesInvoices.forEach(inv => {
            const d = new Date(inv.date);
            if (isNaN(d.getTime())) return;
            const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyData[monthKey]) monthlyData[monthKey] = 0;
            const total = inv.items.reduce((sum, item) => {
                const subtotal = item.quantity * item.unitPrice;
                const discount = subtotal * (item.discount / 100);
                return sum + (subtotal - discount);
            }, 0) - inv.tradeDiscount;
            monthlyData[monthKey] += total;
        });
        return Object.keys(monthlyData).map(monthKey => {
            const [year, month] = monthKey.split('-').map(Number);
            const { jy, jm } = toJalaali(year, month, 1);
            const name = `${getShamsiMonthName(jm)} ${jy}`;
            return {
                name,
                sortKey: monthKey,
                main: monthlyData[monthKey],
// FIX: The right-hand side of an arithmetic operation must be of type 'any', 'number', 'bigint' or an enum type.
                secondary: monthlyData[monthKey] / (exchangeRate || 1),
            };
        }).sort((a, b) => a.sortKey.localeCompare(b.sortKey));
    }, [salesInvoices, exchangeRate]);

    const purchaseChartData = useMemo(() => {
        const monthlyData: { [key: string]: number } = {}; // Key: YYYY-MM
        purchaseInvoices.forEach(inv => {
            const d = new Date(inv.date);
            if (isNaN(d.getTime())) return;
            const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyData[monthKey]) monthlyData[monthKey] = 0;
            const total = inv.items.reduce((sum, item) => {
                const subtotal = item.quantity * item.unitPrice;
                const discount = subtotal * (item.discount / 100);
                return sum + (subtotal - discount);
            }, 0) - inv.tradeDiscount;
            monthlyData[monthKey] += total;
        });
        return Object.keys(monthlyData).map(monthKey => {
            const [year, month] = monthKey.split('-').map(Number);
            const { jy, jm } = toJalaali(year, month, 1);
            const name = `${getShamsiMonthName(jm)} ${jy}`;
            return {
                name,
                sortKey: monthKey,
                main: monthlyData[monthKey],
// FIX: The right-hand side of an arithmetic operation must be of type 'any', 'number', 'bigint' or an enum type.
                secondary: monthlyData[monthKey] / (exchangeRate || 1),
            };
        }).sort((a, b) => a.sortKey.localeCompare(b.sortKey));
    }, [purchaseInvoices, exchangeRate]);

    const cogsChartData = useMemo(() => {
        const monthlyData: { [key: string]: number } = {}; // Key: YYYY-MM
        const productCostMap = new Map(products.map(p => [p.id, p.cost]));
        salesInvoices.forEach(inv => {
            const d = new Date(inv.date);
            if (isNaN(d.getTime())) return;
            const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyData[monthKey]) monthlyData[monthKey] = 0;
            const cogs = inv.items.reduce((sum, item) => {
                const cost = productCostMap.get(item.productId) || 0;
                return sum + (item.quantity * cost);
            }, 0);
            monthlyData[monthKey] += cogs;
        });
        return Object.keys(monthlyData).map(monthKey => {
            const [year, month] = monthKey.split('-').map(Number);
            const { jy, jm } = toJalaali(year, month, 1);
            const name = `${getShamsiMonthName(jm)} ${jy}`;
            return {
                name,
                sortKey: monthKey,
                main: monthlyData[monthKey],
// FIX: The right-hand side of an arithmetic operation must be of type 'any', 'number', 'bigint' or an enum type.
                secondary: monthlyData[monthKey] / (exchangeRate || 1),
            };
        }).sort((a, b) => a.sortKey.localeCompare(b.sortKey));
    }, [salesInvoices, products, exchangeRate]);


  const renderTabContent = () => {
    switch (activeTab) {
      case 'accounting':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <SummaryCard title="مجموع درآمد" amount={totalIncome} color="text-custom-blue-primary" />
              <SummaryCard title="مجموع هزینه" amount={totalExpense} color="text-red-500" />
              <SummaryCard title="سود خالص" amount={netProfit} color={netProfit >= 0 ? 'text-custom-blue-primary' : 'text-red-500'} />
            </div>
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <MonthlySummaryChart data={salesChartData} title="فروش ماهانه" mainCurrency={mainCurrency} secondaryCurrency={secondaryCurrency} />
                <MonthlySummaryChart data={purchaseChartData} title="خرید ماهانه" mainCurrency={mainCurrency} secondaryCurrency={secondaryCurrency} />
                <div className="lg:col-span-2">
                    <MonthlySummaryChart data={cogsChartData} title="بهای تمام شده کالای فروش رفته ماهانه" mainCurrency={mainCurrency} secondaryCurrency={secondaryCurrency} />
                </div>
            </div>
          </div>
        );
      case 'budget':
      case 'sales':
      case 'trends':
        return (
          <Card>
            <div className="text-center p-8">
              <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-200">در حال توسعه</h2>
              <p className="mt-2 text-slate-600 dark:text-slate-400">
                این بخش برای {tabLabels[activeTab]} طراحی شده است. قابلیت‌ها به زودی اضافه خواهند شد.
              </p>
            </div>
          </Card>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">داشبورد</h1>
      
      <div className="border-b border-slate-200 dark:border-slate-700">
        <nav className="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
            {Object.keys(tabLabels).map(tabKey => (
                 <button
                    key={tabKey}
                    onClick={() => setActiveTab(tabKey)}
                    className={`${activeTab === tabKey ? 'border-custom-blue-primary text-custom-blue-primary' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:hover:text-slate-200'} whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm transition-colors duration-200 focus:outline-none`}
                    >
                    {tabLabels[tabKey]}
                </button>
            ))}
        </nav>
      </div>

      {renderTabContent()}
    </div>
  );
};

export default Dashboard;