import React, { useState, useMemo, useEffect } from 'react';
import type { AccountHeadGroup, AccountHeadLedger, AccountHeadSubLedger, AccountingDocument, Person } from '../types';
import Card from './ui/Card';
import { toShamsi } from '../utils/date';
import SearchableSelect from './ui/SearchableSelect';

interface AccountReviewProps {
    accountHeads: AccountHeadGroup[];
    accountingDocuments: AccountingDocument[];
    persons: Person[];
}

type AggregatedBalance = {
    debit: number;
    credit: number;
    balance: number;
};

const formatNumber = (num: number) => new Intl.NumberFormat('fa-IR').format(num);

const AccountReview: React.FC<AccountReviewProps> = ({ accountHeads, accountingDocuments, persons }) => {
    const [expanded, setExpanded] = useState<Record<string, boolean>>({});
    const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);
    const [selectedLedgerId, setSelectedLedgerId] = useState<number | null>(null);
    const [selectedSubLedgerId, setSelectedSubLedgerId] = useState<number | null>(null);

    const toggleExpansion = (id: string) => {
        setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
    };

    // Reset lower-level filters when a higher-level filter changes
    useEffect(() => {
        setSelectedLedgerId(null);
        setSelectedSubLedgerId(null);
    }, [selectedGroupId]);

    useEffect(() => {
        setSelectedSubLedgerId(null);
    }, [selectedLedgerId]);

    const balances = useMemo(() => {
        const balanceMap = new Map<number, AggregatedBalance>();
        accountingDocuments.forEach(doc => {
            doc.rows.forEach(row => {
                if (row.subLedgerId) {
                    const current = balanceMap.get(row.subLedgerId) || { debit: 0, credit: 0, balance: 0 };
                    current.debit += row.debit;
                    current.credit += row.credit;
                    balanceMap.set(row.subLedgerId, current);
                }
            });
        });

        balanceMap.forEach((val, key) => {
            balanceMap.set(key, { ...val, balance: val.debit - val.credit });
        });

        return balanceMap;
    }, [accountingDocuments]);

    const getAggregatedBalance = (ids: number[]): AggregatedBalance => {
        return ids.reduce((acc, id) => {
            const balance = balances.get(id) || { debit: 0, credit: 0, balance: 0 };
            acc.debit += balance.debit;
            acc.credit += balance.credit;
            acc.balance += balance.balance;
            return acc;
        }, { debit: 0, credit: 0, balance: 0 });
    };

    const groupOptions = useMemo(() => accountHeads.map(g => ({ value: g.id, label: `${g.code} - ${g.title}`})), [accountHeads]);
    
    const ledgerOptions = useMemo(() => {
        if (!selectedGroupId) return [];
        const selectedGroup = accountHeads.find(g => g.id === selectedGroupId);
        return selectedGroup ? selectedGroup.children.map(l => ({ value: l.id, label: `${l.code} - ${l.title}`})) : [];
    }, [accountHeads, selectedGroupId]);

    const subLedgerOptions = useMemo(() => {
        if (!selectedLedgerId) return [];
        const selectedGroup = accountHeads.find(g => g.id === selectedGroupId);
        const selectedLedger = selectedGroup?.children.find(l => l.id === selectedLedgerId);
        return selectedLedger ? selectedLedger.children.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}`})) : [];
    }, [accountHeads, selectedGroupId, selectedLedgerId]);

    const filteredAccountHeads = useMemo(() => {
        let filtered = accountHeads;

        if (selectedGroupId) {
            filtered = filtered.filter(g => g.id === selectedGroupId);
        }
        if (selectedLedgerId) {
            filtered = filtered.map(g => ({
                ...g,
                children: g.children.filter(l => l.id === selectedLedgerId)
            })).filter(g => g.children.length > 0);
        }
        if (selectedSubLedgerId) {
             filtered = filtered.map(g => ({
                ...g,
                children: g.children.map(l => ({
                    ...l,
                    children: l.children.filter(sl => sl.id === selectedSubLedgerId)
                })).filter(l => l.children.length > 0)
            })).filter(g => g.children.length > 0);
        }

        return filtered;
    }, [accountHeads, selectedGroupId, selectedLedgerId, selectedSubLedgerId]);

    const BalanceRow: React.FC<{ title: string, code: string, balance: AggregatedBalance, level: number, onClick?: () => void, isExpandable?: boolean, isExpanded?: boolean }> = 
    ({ title, code, balance, level, onClick, isExpandable = false, isExpanded = false }) => (
        <tr onClick={onClick} className={`border-b dark:border-slate-700 ${isExpandable ? 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50' : ''}`}>
            <td className="px-4 py-3" style={{ paddingRight: `${level * 24 + 16}px` }}>
                <div className="flex items-center">
                    {isExpandable && (
                         <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ml-2 transition-transform ${isExpanded ? 'rotate-90' : ''}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
                    )}
                    <span className="font-medium">{code} - {title}</span>
                </div>
            </td>
            <td className="px-4 py-3 text-left font-mono">{formatNumber(balance.debit)}</td>
            <td className="px-4 py-3 text-left font-mono">{formatNumber(balance.credit)}</td>
            <td className={`px-4 py-3 text-left font-mono font-semibold ${balance.balance < 0 ? 'text-red-600' : ''}`}>
                {formatNumber(Math.abs(balance.balance))}
                <span className="text-xs text-slate-500 mr-1">{balance.balance < 0 ? 'بس' : 'بد'}</span>
            </td>
        </tr>
    );

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">کنترل سرفصل‌ها</h1>
            <Card>
                <div className="p-4 border dark:border-slate-700 rounded-lg mb-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
                     <div>
                        <label className="block text-sm font-medium mb-1">گروه حساب</label>
                        <SearchableSelect options={groupOptions} value={selectedGroupId} onChange={val => setSelectedGroupId(val as number)} placeholder="همه گروه‌ها..." />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">حساب کل</label>
                        <SearchableSelect options={ledgerOptions} value={selectedLedgerId} onChange={val => setSelectedLedgerId(val as number)} placeholder="همه حساب‌های کل..." disabled={!selectedGroupId} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">حساب معین</label>
                        <SearchableSelect options={subLedgerOptions} value={selectedSubLedgerId} onChange={val => setSelectedSubLedgerId(val as number)} placeholder="همه حساب‌های معین..." disabled={!selectedLedgerId} />
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full w-full text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800">
                            <tr>
                                <th className="px-4 py-3 text-right font-semibold text-slate-600 dark:text-slate-300">عنوان حساب</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600 dark:text-slate-300">گردش بدهکار</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600 dark:text-slate-300">گردش بستانکار</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600 dark:text-slate-300">مانده</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAccountHeads.map(group => {
                                const groupSubLedgerIds = group.children.flatMap(l => l.children.map(sl => sl.id));
                                const groupBalance = getAggregatedBalance(groupSubLedgerIds);
                                const isGroupExpanded = expanded[`g-${group.id}`];
                                return (
                                    <React.Fragment key={group.id}>
                                        <BalanceRow title={group.title} code={group.code} balance={groupBalance} level={0} onClick={() => toggleExpansion(`g-${group.id}`)} isExpandable isExpanded={isGroupExpanded} />
                                        {isGroupExpanded && group.children.map(ledger => {
                                            const ledgerSubLedgerIds = ledger.children.map(sl => sl.id);
                                            const ledgerBalance = getAggregatedBalance(ledgerSubLedgerIds);
                                            const isLedgerExpanded = expanded[`l-${ledger.id}`];
                                            return (
                                                <React.Fragment key={ledger.id}>
                                                    <BalanceRow title={ledger.title} code={ledger.code} balance={ledgerBalance} level={1} onClick={() => toggleExpansion(`l-${ledger.id}`)} isExpandable isExpanded={isLedgerExpanded} />
                                                    {isLedgerExpanded && ledger.children.map(subLedger => {
                                                         const subLedgerBalance = balances.get(subLedger.id) || { debit: 0, credit: 0, balance: 0 };
                                                         const isSubLedgerExpanded = expanded[`sl-${subLedger.id}`];
                                                         const transactions = accountingDocuments.flatMap(doc => doc.rows.filter(r => r.subLedgerId === subLedger.id).map(r => ({ ...r, docDate: doc.date, docNum: doc.docNumber })));
                                                         return (
                                                            <React.Fragment key={subLedger.id}>
                                                                <BalanceRow title={subLedger.title} code={subLedger.code} balance={subLedgerBalance} level={2} onClick={() => toggleExpansion(`sl-${subLedger.id}`)} isExpandable={transactions.length > 0} isExpanded={isSubLedgerExpanded}/>
                                                                {isSubLedgerExpanded && transactions.length > 0 && (
                                                                    <tr>
                                                                        <td colSpan={4} className="p-0">
                                                                            <div className="px-4 py-2" style={{ paddingRight: `${3 * 24 + 16}px` }}>
                                                                                <table className="w-full text-xs bg-slate-50 dark:bg-slate-800/50 rounded">
                                                                                    <thead>
                                                                                        <tr className="border-b dark:border-slate-700">
                                                                                            <th className="p-2 text-right">تاریخ</th>
                                                                                            <th className="p-2 text-right">شماره سند</th>
                                                                                            <th className="p-2 text-right">شرح</th>
                                                                                            <th className="p-2 text-left">بدهکار</th>
                                                                                            <th className="p-2 text-left">بستانکار</th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        {transactions.map(row => (
                                                                                            <tr key={row.id}>
                                                                                                <td className="p-2">{toShamsi(row.docDate)}</td>
                                                                                                <td className="p-2">{row.docNum}</td>
                                                                                                <td className="p-2">{row.description}</td>
                                                                                                <td className="p-2 text-left font-mono">{formatNumber(row.debit)}</td>
                                                                                                <td className="p-2 text-left font-mono">{formatNumber(row.credit)}</td>
                                                                                            </tr>
                                                                                        ))}
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                )}
                                                            </React.Fragment>
                                                         )
                                                    })}
                                                </React.Fragment>
                                            )
                                        })}
                                    </React.Fragment>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AccountReview;
