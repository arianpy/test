import React, { useState, useMemo, useEffect } from 'react';
// FIX: The Auditable type is now correctly exported from types.ts.
// FIX: Imported the 'Auditable' type to resolve 'Cannot find name' error.
import type { TreasuryTransaction, PurchaseInvoice, Person, AccountHeadGroup, TransactionParty, TransactionPartyType, AutoDocSetting, Bank, Cashbox, POSTerminal, PaymentGateway, PettyCash, Auditable } from '../types';
import { TreasuryTransactionType, TreasuryOperationType } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';

// Reusable Input/Select components
const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);
const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }> = ({ label, id, children, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <select id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary disabled:bg-slate-100 dark:disabled:bg-slate-800">
            {children}
        </select>
    </div>
);

// Party Row Component (for Source/Destination)
interface TransactionPartyRowProps {
    title: string;
    partyData: TransactionParty;
    onUpdate: (data: TransactionParty) => void;
    persons: Person[];
    banks: Bank[];
    cashboxes: Cashbox[];
    posTerminals: POSTerminal[];
    paymentGateways: PaymentGateway[];
    pettyCashList: PettyCash[];
    enabledFields: Record<TransactionPartyType, boolean>;
    isDoc: boolean;
}

const TransactionPartyRow: React.FC<TransactionPartyRowProps> = ({ title, partyData, onUpdate, persons, banks, cashboxes, posTerminals, paymentGateways, pettyCashList, enabledFields, isDoc }) => {
    
    const bankOptions = useMemo(() => banks.map(b => ({ value: b.id, label: `${b.mainBankName} - ${b.branchName}` })), [banks]);
    const cashboxOptions = useMemo(() => cashboxes.map(c => ({ value: c.id, label: c.title })), [cashboxes]);
    const posOptions = useMemo(() => posTerminals.map(p => ({ value: p.id, label: p.title })), [posTerminals]);
    const gatewayOptions = useMemo(() => paymentGateways.map(g => ({ value: g.id, label: g.title })), [paymentGateways]);
    const pettyCashOptions = useMemo(() => pettyCashList.map(pc => ({ value: pc.id, label: pc.title })), [pettyCashList]);
    const personOptions = useMemo(() => persons.map(p => ({ value: p.id, label: p.personType === 'natural' ? `${p.firstName} ${p.lastName}` : p.registeredName })), [persons]);
    
    const handleSelectChange = (type: TransactionPartyType, id: number | null) => {
        const resetParty: Omit<TransactionParty, 'type'> = {
            relatedPartyId: null, bankId: null, cashboxId: null, posId: null, gatewayId: null, pettyCashId: null,
            docNumber: partyData.docNumber, dueDate: partyData.dueDate, sayadNumber: partyData.sayadNumber, docBankName: partyData.docBankName,
        };
        
        const keyMap: Record<TransactionPartyType, keyof TransactionParty | null> = {
            party: 'relatedPartyId', bank: 'bankId', cashbox: 'cashboxId', pos: 'posId', gateway: 'gatewayId', pettyCash: 'pettyCashId'
        };
        
        const keyToUpdate = keyMap[type];
        
        if (keyToUpdate) {
            onUpdate({ ...partyData, ...resetParty, type, [keyToUpdate]: id });
        }
    };
    
    const handleInputChange = (field: keyof TransactionParty, value: string) => {
        onUpdate({ ...partyData, [field]: value });
    };

    return (
        <div className="p-4 border dark:border-slate-700 rounded-lg space-y-4">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{title}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <SearchableSelect options={personOptions} value={partyData.relatedPartyId} onChange={v => handleSelectChange('party', v as number)} disabled={!enabledFields.party} placeholder='طرف حساب...' />
                <SearchableSelect options={bankOptions} value={partyData.bankId} onChange={v => handleSelectChange('bank', v as number)} disabled={!enabledFields.bank} placeholder='بانک...' />
                <SearchableSelect options={cashboxOptions} value={partyData.cashboxId} onChange={v => handleSelectChange('cashbox', v as number)} disabled={!enabledFields.cashbox} placeholder='صندوق...' />
                <SearchableSelect options={posOptions} value={partyData.posId} onChange={v => handleSelectChange('pos', v as number)} disabled={!enabledFields.pos} placeholder='کارتخوان...' />
                <SearchableSelect options={gatewayOptions} value={partyData.gatewayId} onChange={v => handleSelectChange('gateway', v as number)} disabled={!enabledFields.gateway} placeholder='درگاه پرداخت...' />
                <SearchableSelect options={pettyCashOptions} value={partyData.pettyCashId} onChange={v => handleSelectChange('pettyCash', v as number)} disabled={!enabledFields.pettyCash} placeholder='تنخواه گردان...' />
            </div>
            {isDoc && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t dark:border-slate-600 mt-4">
                    <FormInput label="شماره سند/چک" value={partyData.docNumber} onChange={e => handleInputChange('docNumber', e.target.value)} />
                    <FormInput label="تاریخ سررسید" type="date" value={partyData.dueDate} onChange={e => handleInputChange('dueDate', e.target.value)} />
                    <FormInput label="شماره صیاد" value={partyData.sayadNumber} onChange={e => handleInputChange('sayadNumber', e.target.value)} />
                    <FormInput label="بانک مرتبط چک" value={partyData.docBankName} onChange={e => handleInputChange('docBankName', e.target.value)} />
                </div>
            )}
        </div>
    );
};

// Main Component
interface TreasuryTransactionProps {
    transactions: TreasuryTransaction[];
    addTransaction: (transaction: Omit<TreasuryTransaction, 'id' | keyof Auditable>) => void;
    deleteTransaction: (id: number) => void;
    purchaseInvoices: PurchaseInvoice[];
    persons: Person[];
    accountHeads: AccountHeadGroup[];
    autoDocSetting?: AutoDocSetting;
    banks: Bank[];
    cashboxes: Cashbox[];
    posTerminals: POSTerminal[];
    paymentGateways: PaymentGateway[];
    pettyCashList: PettyCash[];
}

const TreasuryTransactionComponent: React.FC<TreasuryTransactionProps> = ({ transactions, addTransaction, deleteTransaction, purchaseInvoices, persons, accountHeads, autoDocSetting, banks, cashboxes, posTerminals, paymentGateways, pettyCashList }) => {
    
    const initialPartyState: TransactionParty = {
        type: null, relatedPartyId: null, bankId: null, cashboxId: null,
        posId: null, gatewayId: null, pettyCashId: null, docNumber: '',
        dueDate: '', sayadNumber: '', docBankName: ''
    };
    
    const getInitialState = () => ({
        transactionType: TreasuryTransactionType.Cash,
        operationType: TreasuryOperationType.Payment,
        date: new Date().toISOString().split('T')[0],
        docNumber: '',
        accountingDocNumber: '',
        relatedInvoiceId: null,
        amount: 0,
        feeAmount: 0,
        description: '',
        source: { ...initialPartyState },
        destination: { ...initialPartyState },
        feeSubLedgerId: null,
        debtorSubLedgerId: autoDocSetting?.defaultDebtorSubLedgerId || null,
        creditorSubLedgerId: autoDocSetting?.defaultCreditorSubLedgerId || null,
        hasAccountingDoc: false,
    });

    const [formState, setFormState] = useState(getInitialState());
    const [enabledFields, setEnabledFields] = useState<{ source: Record<TransactionPartyType, boolean>, destination: Record<TransactionPartyType, boolean> }>({ 
        source: { party: false, bank: true, cashbox: true, pos: true, gateway: true, pettyCash: true }, 
        destination: { party: true, bank: false, cashbox: false, pos: false, gateway: false, pettyCash: false } 
    });
    
    const allSubLedgers = useMemo(() => {
        return accountHeads.flatMap(group => group.children.flatMap(ledger => ledger.children));
    }, [accountHeads]);

    useEffect(() => {
        if (autoDocSetting) {
            setFormState(prev => ({
                ...prev,
                debtorSubLedgerId: autoDocSetting.defaultDebtorSubLedgerId,
                creditorSubLedgerId: autoDocSetting.defaultCreditorSubLedgerId,
            }));
        }
    }, [autoDocSetting]);

    useEffect(() => {
        const { operationType } = formState;
        
        const internal: Record<TransactionPartyType, boolean> = { party: false, bank: true, cashbox: true, pos: true, gateway: true, pettyCash: true };
        const external: Record<TransactionPartyType, boolean> = { party: true, bank: false, cashbox: false, pos: false, gateway: false, pettyCash: false };

        let sourceConfig: Record<TransactionPartyType, boolean>;
        let destConfig: Record<TransactionPartyType, boolean>;

        if (operationType === TreasuryOperationType.Payment) {
            sourceConfig = internal;
            destConfig = external;
        } else if (operationType === TreasuryOperationType.Receipt) {
            sourceConfig = external;
            destConfig = internal;
        } else { // Covers TreasuryOperationType.CashManagement
            sourceConfig = internal;
            destConfig = internal;
        }
        
        setEnabledFields({ source: sourceConfig, destination: destConfig });
        
        // Reset selections when config changes
        setFormState(prev => ({
            ...prev,
            source: { ...initialPartyState },
            destination: { ...initialPartyState }
        }));

    }, [formState.operationType]);

    const handleHeaderChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        setFormState({ ...formState, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (transactions.some(t => t.docNumber === formState.docNumber && formState.docNumber.trim() !== '')) {
            alert('شماره سند تکراری است.');
            return;
        }
        // FIX: The `addTransaction` prop expects a `status` property. Adding a default 'active' status.
        const payload = { ...formState, status: 'active' as const };
        addTransaction(payload);
        setFormState(getInitialState());
        alert('تراکنش خزانه با موفقیت ثبت شد.');
    };
    
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت تراکنش خزانه</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Header */}
                    <div className="p-4 border dark:border-slate-700 rounded-lg space-y-4">
                         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                             <FormSelect label="نوع تراکنش" name="transactionType" value={formState.transactionType} onChange={handleHeaderChange}>
                                <option value={TreasuryTransactionType.Cash}>نقد</option>
                                <option value={TreasuryTransactionType.Document}>اسناد</option>
                            </FormSelect>
                             <FormSelect label="نوع عملیات" name="operationType" value={formState.operationType} onChange={handleHeaderChange}>
                                <option value={TreasuryOperationType.Payment}>پرداخت</option>
                                <option value={TreasuryOperationType.Receipt}>دریافت</option>
                                <option value={TreasuryOperationType.CashManagement}>مدیریت وجوه نقد</option>
                            </FormSelect>
                            <FormInput label="تاریخ" name="date" type="date" value={formState.date} onChange={handleHeaderChange} />
                            <FormInput label="شماره سند" name="docNumber" value={formState.docNumber} onChange={handleHeaderChange} />
                            <FormInput label="شماره سند حسابداری" name="accountingDocNumber" value={formState.accountingDocNumber} disabled />
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                             <FormSelect label="فاکتور مربوطه" name="relatedInvoiceId" value={formState.relatedInvoiceId || ''} onChange={handleHeaderChange}>
                                <option value="">بدون فاکتور</option>
                                {purchaseInvoices.map(inv => <option key={inv.id} value={inv.id}>{inv.docNumber}</option>)}
                            </FormSelect>
                            <FormInput label="مبلغ تراکنش" name="amount" type="number" value={formState.amount} onChange={handleHeaderChange} required />
                            <FormInput label="مبلغ کارمزد" name="feeAmount" type="number" value={formState.feeAmount} onChange={handleHeaderChange} />
                             <div className="lg:col-span-2">
                                <FormInput label="توضیحات سند" name="description" value={formState.description} onChange={handleHeaderChange} />
                            </div>
                        </div>
                    </div>
                    
                    {/* Source and Destination */}
                    <TransactionPartyRow
                        title="مبدا تراکنش"
                        partyData={formState.source}
                        onUpdate={(data) => setFormState(prev => ({ ...prev, source: data }))}
                        persons={persons}
                        banks={banks}
                        cashboxes={cashboxes}
                        posTerminals={posTerminals}
                        paymentGateways={paymentGateways}
                        pettyCashList={pettyCashList}
                        enabledFields={enabledFields.source}
                        isDoc={formState.transactionType === TreasuryTransactionType.Document}
                    />
                     <TransactionPartyRow
                        title="مقصد تراکنش"
                        partyData={formState.destination}
                        onUpdate={(data) => setFormState(prev => ({ ...prev, destination: data }))}
                        persons={persons}
                        banks={banks}
                        cashboxes={cashboxes}
                        posTerminals={posTerminals}
                        paymentGateways={paymentGateways}
                        pettyCashList={pettyCashList}
                        enabledFields={enabledFields.destination}
                        isDoc={formState.transactionType === TreasuryTransactionType.Document}
                    />

                    {/* Accounting Footer */}
                    <div className="p-4 border dark:border-slate-700 rounded-lg">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                            <FormSelect label="معین کارمزد" name="feeSubLedgerId" value={formState.feeSubLedgerId || ''} onChange={handleHeaderChange}>
                                <option value="">انتخاب...</option>
                                {allSubLedgers.map(sl => <option key={sl.id} value={sl.id}>{sl.title}</option>)}
                            </FormSelect>
                            <FormSelect label="معین بدهکار" name="debtorSubLedgerId" value={formState.debtorSubLedgerId || ''} onChange={handleHeaderChange} disabled={autoDocSetting ? !autoDocSetting.isDebtorEditable : false}>
                                <option value="">انتخاب...</option>
                                {allSubLedgers.map(sl => <option key={sl.id} value={sl.id}>{sl.title}</option>)}
                            </FormSelect>
                            <FormSelect label="معین بستانکار" name="creditorSubLedgerId" value={formState.creditorSubLedgerId || ''} onChange={handleHeaderChange} disabled={autoDocSetting ? !autoDocSetting.isCreditorEditable : false}>
                                <option value="">انتخاب...</option>
                                {allSubLedgers.map(sl => <option key={sl.id} value={sl.id}>{sl.title}</option>)}
                            </FormSelect>
                        </div>
                    </div>

                    {/* Buttons */}
                    <div className="flex justify-end pt-5 border-t dark:border-slate-700 space-x-2 rtl:space-x-reverse">
                        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">ذخیره</button>
                        <button type="button" disabled className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-green-300">ثبت سند حسابداری</button>
                        <button type="button" disabled className="px-4 py-2 text-sm font-medium text-white bg-amber-500 rounded-md hover:bg-amber-600 disabled:bg-amber-300">حذف سند حسابداری</button>
                    </div>

                </form>
            </Card>
        </div>
    );
};

export default TreasuryTransactionComponent;
