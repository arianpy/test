import React, { useState, useEffect } from 'react';
import type { Workstation } from '../types';
import Card from './ui/Card';

interface DefineWorkstationsProps {
    workstations: Workstation[];
    addWorkstation: (workstation: Omit<Workstation, 'id'>) => void;
    updateWorkstation: (workstation: Workstation) => void;
    deleteWorkstation: (id: number) => void;
}

const DefineWorkstations: React.FC<DefineWorkstationsProps> = ({ workstations, addWorkstation, updateWorkstation, deleteWorkstation }) => {
    const getInitialState = () => ({
        name: '',
        code: '',
        description: '',
    });

    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);

    const handleEditClick = (workstation: Workstation) => {
        setEditingId(workstation.id);
        setFormData({
            name: workstation.name,
            code: workstation.code,
            description: workstation.description,
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleClearForm = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (editingId !== null) {
            updateWorkstation({ id: editingId, ...formData });
        } else {
            addWorkstation(formData);
        }
        handleClearForm();
    };
    
    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این ایستگاه کاری اطمینان دارید؟')) {
            deleteWorkstation(id);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف ایستگاه کاری</h1>
            <Card>
                <form onSubmit={handleSave} className="space-y-4">
                    <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">
                        {editingId ? 'ویرایش ایستگاه کاری' : 'ایجاد ایستگاه کاری جدید'}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="text" placeholder="نام ایستگاه کاری" value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                        <input type="text" placeholder="کد ایستگاه کاری" value={formData.code} onChange={e => setFormData(p => ({ ...p, code: e.target.value }))} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                    </div>
                    <textarea placeholder="توضیحات" value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" rows={3}/>
                    <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                        {editingId && <button type="button" onClick={handleClearForm} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو ویرایش</button>}
                        <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">
                            {editingId ? 'ذخیره تغییرات' : 'ذخیره ایستگاه کاری'}
                        </button>
                    </div>
                </form>
            </Card>
            <Card>
                 <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">ایستگاه‌های کاری تعریف شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">کد</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">توضیحات</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {workstations.map(w => (
                                <tr key={w.id}>
                                    <td className="px-4 py-4 font-medium">{w.name}</td>
                                    <td className="px-4 py-4">{w.code}</td>
                                    <td className="px-4 py-4">{w.description}</td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleEditClick(w)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(w.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DefineWorkstations;
