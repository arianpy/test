

import React, { useState, useMemo } from 'react';
import { sidebarStructure, GroupItem, ModuleItem, SubViewEntry, SubViewGroup, SubViewSimple } from '../data/sidebarStructure';
import type { ActiveView } from '../App';
import Card from './ui/Card';

interface LauncherProps {
    onNavigate: (view: ActiveView) => void;
}

const Launcher: React.FC<LauncherProps> = ({ onNavigate }) => {
    const [activeItem, setActiveItem] = useState<GroupItem | ModuleItem | null>(null);
    const [activeSubGroup, setActiveSubGroup] = useState<SubViewGroup | null>(null);

    const renderSubViewList = (subViews: SubViewEntry[], module: ModuleItem) => (
        <div className="space-y-2">
            {subViews.map(sub => {
                // FIX: Used a type guard with an if/else block to correctly discriminate the SubViewEntry union type.
                if ('type' in sub && sub.type === 'subgroup') {
                    const key = `subgroup-${sub.label}`;
                    return (
                        <div key={key}>
                            <h4 className="font-semibold text-slate-700 dark:text-slate-300 mt-4 mb-2">{sub.label}</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {sub.subViews.map(sv => (
                                    <button key={sv.id} onClick={() => onNavigate({ module: module.id, subView: sv.id })} className="text-right w-full p-3 rounded-md bg-slate-50 hover:bg-custom-blue-light/30 dark:bg-slate-700/50 dark:hover:bg-slate-700 transition-colors">
                                        {sv.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    );
                } else {
                    const simpleSub = sub as SubViewSimple;
                    // After the guard, `sub` is correctly inferred as SubViewSimple
                    return (
                        <button key={simpleSub.id} onClick={() => onNavigate({ module: module.id, subView: simpleSub.id })} className="text-right w-full p-3 rounded-md bg-slate-50 hover:bg-custom-blue-light/30 dark:bg-slate-700/50 dark:hover:bg-slate-700 transition-colors">
                            {simpleSub.label}
                        </button>
                    );
                }
            })}
        </div>
    );
    
    if (activeItem) {
        return (
            <div className="animate-fade-in-down">
                <button onClick={() => setActiveItem(null)} className="flex items-center mb-6 text-sm font-medium text-slate-600 dark:text-slate-400 hover:text-custom-blue-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    بازگشت به منوی اصلی
                </button>
                <h2 className="text-3xl font-bold mb-8 text-slate-800 dark:text-slate-100">{activeItem.label}</h2>
                {activeItem.type === 'group' ? (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {activeItem.modules.map(module => (
                            <Card key={module.id} className="cursor-pointer transition-all transform hover:-translate-y-1 hover:shadow-xl" onClick={() => setActiveItem(module)}>
                                <div className="flex flex-col items-center text-center">
                                    <div className="p-4 bg-custom-blue-light/20 text-custom-blue-primary rounded-full mb-4">
                                        {module.icon}
                                    </div>
                                    <h3 className="font-semibold text-lg">{module.label}</h3>
                                </div>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <Card>
                        {renderSubViewList(activeItem.subViews, activeItem)}
                    </Card>
                )}
            </div>
        );
    }

    return (
        <div className="animate-fade-in-down">
            <h1 className="text-3xl font-bold mb-8 text-slate-800 dark:text-slate-100">منوی اصلی</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sidebarStructure.map(item => (
                    <Card key={item.id} className="cursor-pointer transition-all transform hover:-translate-y-1 hover:shadow-xl" onClick={() => setActiveItem(item)}>
                        <div className="flex flex-col items-center text-center p-4">
                            <div className="p-5 bg-custom-blue-light/20 text-custom-blue-primary rounded-full mb-4">
                                {/* FIX: Cast props to 'any' to resolve className type error with React.cloneElement. */}
                                {React.cloneElement(item.icon, { className: 'h-8 w-8' } as any)}
                            </div>
                            <h3 className="font-semibold text-lg">{item.label}</h3>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};

export default Launcher;
