import React, { useState } from 'react';
import Card from './ui/Card';

interface Font {
    id: string;
    name: string;
    style: React.CSSProperties;
}
interface AppearanceSettingsProps {
    currentFont: string;
    setFont: (font: string) => void;
    customFonts: Font[];
    addCustomFont: (font: Font) => void;
}

const defaultFonts: Font[] = [
    { id: 'vazirmatn', name: 'وزیرمتن', style: { fontFamily: 'Vazirmatn, sans-serif' } },
    { id: 'sahel', name: 'ساحل', style: { fontFamily: 'Sahel, sans-serif' } },
    { id: 'tanha', name: 'تنها', style: { fontFamily: 'Tanha, sans-serif' } },
];

const CustomFontUploader: React.FC<{ addCustomFont: (font: Font) => void }> = ({ addCustomFont }) => {
    const [fontFile, setFontFile] = useState<File | null>(null);
    const [fontName, setFontName] = useState('');
    const [error, setError] = useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const validTypes = ['font/ttf', 'font/woff', 'font/woff2'];
            if (validTypes.includes(file.type)) {
                setFontFile(file);
                setError('');
            } else {
                setError('فرمت فایل نامعتبر است. لطفا از ttf, woff, woff2 استفاده کنید.');
                setFontFile(null);
            }
        }
    };

    const handleUpload = () => {
        if (!fontFile || !fontName.trim()) {
            setError('لطفا نام فونت و فایل آن را انتخاب کنید.');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            const fontUrl = e.target?.result as string;
            const fontId = `custom-${fontName.trim().replace(/\s+/g, '-').toLowerCase()}`;
            
            const newFont: Font = {
                id: fontId,
                name: fontName.trim(),
                style: { fontFamily: `'${fontId}', sans-serif` }
            };
            
            // Inject font-face rule
            const styleEl = document.createElement('style');
            styleEl.innerHTML = `
                @font-face {
                    font-family: '${fontId}';
                    src: url(${fontUrl});
                }
            `;
            document.head.appendChild(styleEl);

            addCustomFont(newFont);
            setFontFile(null);
            setFontName('');
            setError('');
        };
        reader.readAsDataURL(fontFile);
    };

    return (
        <div className="p-4 border rounded-lg dark:border-slate-700 mt-6 space-y-4">
             <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">بارگذاری فونت دلخواه</h3>
             {error && <p className="text-sm text-red-500">{error}</p>}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <input
                    type="text"
                    placeholder="نام نمایشی فونت"
                    value={fontName}
                    onChange={(e) => setFontName(e.target.value)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                />
                 <input 
                    type="file" 
                    accept=".ttf,.woff,.woff2"
                    onChange={handleFileChange} 
                    className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-50 file:text-cyan-700 hover:file:bg-cyan-100"
                />
                 <button onClick={handleUpload} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">نصب فونت</button>
             </div>
        </div>
    );
};


const AppearanceSettings: React.FC<AppearanceSettingsProps> = ({ currentFont, setFont, customFonts, addCustomFont }) => {
    const allFonts = [...defaultFonts, ...customFonts];
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیمات ظاهری</h1>
            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">انتخاب فونت برنامه</h2>
                <p className="text-slate-600 dark:text-slate-400 mb-6">
                    فونت مورد نظر خود را برای نمایش در تمام بخش‌های برنامه انتخاب کنید. تغییرات بلافاصله اعمال خواهند شد.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {allFonts.map((font) => (
                        <div
                            key={font.id}
                            onClick={() => setFont(font.id)}
                            className={`p-6 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                                currentFont === font.id
                                    ? 'border-custom-blue-primary bg-custom-blue-light/20 shadow-lg'
                                    : 'border-slate-300 dark:border-slate-600 hover:border-custom-blue-primary/50 hover:shadow-md'
                            }`}
                        >
                            <h3 className="text-2xl text-center text-slate-800 dark:text-slate-200" style={font.style}>
                                {font.name}
                            </h3>
                            <p className="text-sm text-center text-slate-500 dark:text-slate-400 mt-2" style={font.style}>
                                نمایش نمونه‌ای از متن با این فونت
                            </p>
                        </div>
                    ))}
                </div>

                <CustomFontUploader addCustomFont={addCustomFont} />
            </Card>
        </div>
    );
};

export default AppearanceSettings;