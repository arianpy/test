
import React, { useState, useEffect } from 'react';
import Modal from './ui/Modal';

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ isOpen, onClose }) => {
    const [recoveryMethod, setRecoveryMethod] = useState<'email' | 'phone'>('email');
    const [inputValue, setInputValue] = useState('');
    const [view, setView] = useState<'form' | 'success'>('form');
    
    // Mock user data
    const userEmail = 'testuser@example.com';
    const userPhone = '09123456789';

    useEffect(() => {
        if (isOpen) {
            // Reset state when modal opens
            setView('form');
            setRecoveryMethod('email');
            setInputValue(userEmail);
        }
    }, [isOpen]);

    useEffect(() => {
        // Update input value when recovery method changes
        setInputValue(recoveryMethod === 'email' ? userEmail : userPhone);
    }, [recoveryMethod]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Simulate sending recovery code
        console.log(`Sending recovery code via ${recoveryMethod} to ${inputValue}`);
        setView('success');
    };

    const handleClose = () => {
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} title="بازیابی رمز عبور">
            {view === 'form' ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                        لطفا روش بازیابی رمز عبور خود را انتخاب کنید. کد بازیابی به مقصد انتخابی شما ارسال خواهد شد.
                    </p>
                    <fieldset className="space-y-2">
                        <legend className="block text-sm font-medium text-slate-700 dark:text-slate-300">روش بازیابی</legend>
                        <div className="flex items-center space-x-4 rtl:space-x-reverse">
                            <label className="flex items-center cursor-pointer">
                                <input
                                    type="radio"
                                    name="recoveryMethod"
                                    value="email"
                                    checked={recoveryMethod === 'email'}
                                    onChange={() => setRecoveryMethod('email')}
                                    className="form-radio h-4 w-4 text-custom-blue-primary border-slate-300 focus:ring-custom-blue-primary"
                                />
                                <span className="mr-2 text-sm text-slate-700 dark:text-slate-300">ایمیل</span>
                            </label>
                            <label className="flex items-center cursor-pointer">
                                <input
                                    type="radio"
                                    name="recoveryMethod"
                                    value="phone"
                                    checked={recoveryMethod === 'phone'}
                                    onChange={() => setRecoveryMethod('phone')}
                                    className="form-radio h-4 w-4 text-custom-blue-primary border-slate-300 focus:ring-custom-blue-primary"
                                />
                                <span className="mr-2 text-sm text-slate-700 dark:text-slate-300">شماره موبایل</span>
                            </label>
                        </div>
                    </fieldset>
                    
                     <div>
                        <label htmlFor="recovery-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                           {recoveryMethod === 'email' ? 'آدرس ایمیل' : 'شماره موبایل'}
                        </label>
                        <input
                            id="recovery-input"
                            type={recoveryMethod === 'email' ? 'email' : 'tel'}
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                            required
                        />
                    </div>

                    <div className="w-full flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                        <button type="button" onClick={handleClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                            انصراف
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                            ارسال کد بازیابی
                        </button>
                    </div>
                </form>
            ) : (
                <div className="space-y-4 text-center">
                    <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 dark:bg-green-900">
                        <svg className="h-6 w-6 text-green-600 dark:text-green-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white">ارسال موفق</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                        کد بازیابی با موفقیت به {inputValue} ارسال شد. لطفا صندوق ورودی خود را بررسی کنید.
                    </p>
                    <div className="pt-4">
                         <button onClick={handleClose} className="w-full px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                            باشه
                        </button>
                    </div>
                </div>
            )}
        </Modal>
    );
};

export default ForgotPasswordModal;
