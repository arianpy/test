import React, { useState, useMemo, useEffect } from 'react';
import type { PettyCash, Currency, AccountHeadSubLedger, Personnel } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface DefinePettyCashProps {
    pettyCashList: PettyCash[];
    addPettyCash: (pc: Omit<PettyCash, 'id'>) => void;
    updatePettyCash: (pc: PettyCash) => void;
    deletePettyCash: (pcId: number) => void;
    currencies: Currency[];
    allSubLedgers: AccountHeadSubLedger[];
    personnelList: Personnel[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const EditPettyCashModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    pettyCash: PettyCash | null;
    updatePettyCash: (pc: PettyCash) => void;
    currencies: Currency[];
    allSubLedgers: AccountHeadSubLedger[];
    personnelList: Personnel[];
}> = ({ isOpen, onClose, pettyCash, updatePettyCash, currencies, allSubLedgers, personnelList }) => {
    
    const [formData, setFormData] = useState<PettyCash | null>(pettyCash);

    useEffect(() => {
        setFormData(pettyCash);
    }, [pettyCash]);

    if (!isOpen || !formData) return null;
    
    const currencyOptions = currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`}));
    const subLedgerOptions = allSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}` }));
    const personnelOptions = personnelList.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName}` }));


    const handleChange = (field: keyof Omit<PettyCash, 'id'>, value: any) => {
        setFormData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updatePettyCash(formData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش تنخواه گردان: ${pettyCash?.title}`} size="3xl">
            <form onSubmit={handleSubmit} className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <FormInput label="عنوان تنخواه گردان" value={formData.title} onChange={e => handleChange('title', e.target.value)} required />
                    <CustomFormSelect label="معین مرتبط"><SearchableSelect options={subLedgerOptions} value={formData.relatedSubLedgerId} onChange={val => handleChange('relatedSubLedgerId', val)} /></CustomFormSelect>
                    <CustomFormSelect label="تنخواه دار مرتبط"><SearchableSelect options={personnelOptions} value={formData.relatedPersonId} onChange={val => handleChange('relatedPersonId', val)} /></CustomFormSelect>
                    <div><label className="block text-sm font-medium">سقف تنخواه</label><FormattedNumberInput value={formData.limit} onValueChange={val => handleChange('limit', val)} className="mt-1 w-full p-2 border rounded-md" required /></div>
                    <div><label className="block text-sm font-medium">مانده افتتاحیه</label><FormattedNumberInput value={formData.openingBalance} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full p-2 border rounded-md" /></div>
                    <CustomFormSelect label="ارز"><SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} /></CustomFormSelect>
                </div>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                </div>
            </form>
        </Modal>
    );
};

const DefinePettyCash: React.FC<DefinePettyCashProps> = ({ pettyCashList, addPettyCash, updatePettyCash, deletePettyCash, currencies, allSubLedgers, personnelList }) => {
    const initialState: Omit<PettyCash, 'id'> = {
        title: '',
        relatedSubLedgerId: 0,
        relatedPersonId: 0,
        limit: 0,
        openingBalance: 0,
        currencyCode: currencies[0]?.code || 'IRR',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedPettyCash, setSelectedPettyCash] = useState<PettyCash | null>(null);

    const currencyMap = useMemo(() => new Map(currencies.map(c => [c.code, c.name])), [currencies]);
    const currencyOptions = useMemo(() => currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`})), [currencies]);
    const subLedgerMap = useMemo(() => new Map(allSubLedgers.map(sl => [sl.id, sl.title])), [allSubLedgers]);
    const subLedgerOptions = useMemo(() => allSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}` })), [allSubLedgers]);
    const personnelMap = useMemo(() => new Map(personnelList.map(p => [p.id, `${p.firstName} ${p.lastName}`])), [personnelList]);
    const personnelOptions = useMemo(() => personnelList.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName}` })), [personnelList]);


    const handleChange = (field: keyof Omit<PettyCash, 'id'>, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.relatedSubLedgerId || !formData.relatedPersonId) {
            alert('لطفا معین و تنخواه دار مرتبط را انتخاب کنید.');
            return;
        }
        addPettyCash(formData);
        setFormData(initialState);
        alert('تنخواه گردان جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (pc: PettyCash) => {
        setSelectedPettyCash(pc);
        setEditModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف تنخواه گردان</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-end">
                        <FormInput label="عنوان تنخواه گردان" value={formData.title} onChange={e => handleChange('title', e.target.value)} required placeholder="عنوان تنخواه گردان"/>
                        <CustomFormSelect label="معین مرتبط"><SearchableSelect options={subLedgerOptions} value={formData.relatedSubLedgerId} onChange={val => handleChange('relatedSubLedgerId', val)} placeholder="انتخاب معین مرتبط" /></CustomFormSelect>
                        <CustomFormSelect label="تنخواه دار مرتبط"><SearchableSelect options={personnelOptions} value={formData.relatedPersonId} onChange={val => handleChange('relatedPersonId', val)} placeholder="انتخاب تنخواه دار مرتبط" /></CustomFormSelect>
                        <div><label className="block text-sm font-medium">سقف تنخواه</label><FormattedNumberInput value={formData.limit} onValueChange={val => handleChange('limit', val)} className="mt-1 w-full p-2 border rounded-md" required placeholder="سقف تنخواه"/></div>
                        <div><label className="block text-sm font-medium">مانده افتتاحیه استقرار</label><FormattedNumberInput value={formData.openingBalance} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full p-2 border rounded-md" placeholder="مانده افتتاحیه استقرار را وارد کنید"/></div>
                        <CustomFormSelect label="انتخاب ارز"><SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} /></CustomFormSelect>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">تعریف تنخواه گردان</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">تنخواه گردان‌های تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs uppercase">عنوان</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">معین مرتبط</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">تنخواه دار</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">سقف تنخواه</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">مانده افتتاحیه</th>
                            <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {pettyCashList.length > 0 ? (
                            pettyCashList.map((pc) => (
                                <tr key={pc.id}>
                                    <td className="px-4 py-4 whitespace-nowrap">{pc.title}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{subLedgerMap.get(pc.relatedSubLedgerId) || '-'}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{personnelMap.get(pc.relatedPersonId) || '-'}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono">{pc.limit.toLocaleString()}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono">{pc.openingBalance.toLocaleString()}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center space-x-4 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(pc)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => deletePettyCash(pc.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز تنخواه گردانی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditPettyCashModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                pettyCash={selectedPettyCash}
                updatePettyCash={updatePettyCash}
                currencies={currencies}
                allSubLedgers={allSubLedgers}
                personnelList={personnelList}
            />
        </div>
    );
};

export default DefinePettyCash;
