
import React, { useState, useMemo, useEffect } from 'react';
import type { PurchaseItem, PurchaseItemGroup, MeasurementUnit } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';


// FIX: Add updateItem and deleteItem props to handle editing and removing items.
interface DefinePurchaseItemProps {
    items: PurchaseItem[];
    groups: PurchaseItemGroup[];
    addItem: (item: Omit<PurchaseItem, 'id'>) => void;
    updateItem: (item: PurchaseItem) => void;
    deleteItem: (itemId: number) => void;
    measurementUnits: MeasurementUnit[];
}

// Reusable components
const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const EditItemModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    item: PurchaseItem | null;
    updateItem: (item: PurchaseItem) => void;
    groups: PurchaseItemGroup[];
    measurementUnits: MeasurementUnit[];
}> = ({ isOpen, onClose, item, updateItem, groups, measurementUnits }) => {
    const [formData, setFormData] = useState<PurchaseItem | null>(item);

    useEffect(() => { setFormData(item); }, [item]);

    const groupOptions = useMemo(() => {
        const options: { value: number; label: string }[] = [];
        const buildOptions = (groupNodes: PurchaseItemGroup[], level = 0) => {
            for (const group of groupNodes) {
                options.push({ value: group.id, label: '\u00A0'.repeat(level * 4) + group.title });
                if (group.children) buildOptions(group.children, level + 1);
            }
        };
        buildOptions(groups);
        return options;
    }, [groups]);

    const unitOptions = useMemo(() => measurementUnits.map(u => ({ value: u.title, label: u.title })), [measurementUnits]);

    const handleValueChange = (field: keyof PurchaseItem, value: any) => {
        if (formData) setFormData(prev => ({ ...prev!, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateItem(formData);
        }
        onClose();
    };

    if (!isOpen || !formData) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش قلم: ${item?.title}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <FormInput label="کد کالا" value={formData.code} onChange={e => handleValueChange('code', e.target.value)} required />
                    <div className="md:col-span-2"><FormInput label="عنوان کالا" value={formData.title} onChange={e => handleValueChange('title', e.target.value)} required /></div>
                    <CustomFormSelect label="گروه تامین"><SearchableSelect options={groupOptions} value={formData.supplyGroupId} onChange={val => handleValueChange('supplyGroupId', val)} /></CustomFormSelect>
                    <CustomFormSelect label="واحد اصلی"><SearchableSelect options={unitOptions} value={formData.primaryUnit} onChange={val => handleValueChange('primaryUnit', val)} /></CustomFormSelect>
                    <CustomFormSelect label="واحد فرعی"><SearchableSelect options={unitOptions} value={formData.secondaryUnit} onChange={val => handleValueChange('secondaryUnit', val)} /></CustomFormSelect>
                    <div><label className="block text-sm mb-1">آخرین فی تامین</label><FormattedNumberInput value={formData.lastSupplyPrice} onValueChange={val => handleValueChange('lastSupplyPrice', val)} required className="block w-full p-2 border rounded-md" /></div>
                    <div><label className="block text-sm mb-1">نرخ مالیات (%)</label><FormattedNumberInput value={formData.vatRate} onValueChange={val => handleValueChange('vatRate', val)} required className="block w-full p-2 border rounded-md" /></div>
                </div>
                <div className="flex justify-end pt-4 border-t dark:border-slate-600"><button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600">ذخیره</button></div>
            </form>
        </Modal>
    );
};

const DefinePurchaseItem: React.FC<DefinePurchaseItemProps> = ({ items, groups, addItem, updateItem, deleteItem, measurementUnits }) => {
    const initialState = {
        code: '',
        title: '',
        primaryUnit: '',
        secondaryUnit: '',
        lastSupplyPrice: '' as number | '',
        supplyGroupId: null as number | null,
        vatRate: '' as number | '',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedItem, setSelectedItem] = useState<PurchaseItem | null>(null);

    const groupMap = useMemo(() => {
        const map: { [key: number]: string } = {};
        const traverse = (nodes: PurchaseItemGroup[]) => {
            nodes.forEach(node => {
                map[node.id] = node.title;
                if (node.children) traverse(node.children);
            });
        };
        traverse(groups);
        return map;
    }, [groups]);
    
    const groupOptions = useMemo(() => {
        const options: { value: number; label: string }[] = [];
        const buildOptions = (groupNodes: PurchaseItemGroup[], level = 0) => {
            for (const group of groupNodes) {
                options.push({
                    value: group.id,
                    label: '\u00A0'.repeat(level * 4) + group.title
                });
                if (group.children && group.children.length > 0) {
                    buildOptions(group.children, level + 1);
                }
            }
        };
        buildOptions(groups);
        return options;
    }, [groups]);

    const unitOptions = useMemo(() => measurementUnits.map(u => ({ value: u.title, label: u.title })), [measurementUnits]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };
    
    const handleValueChange = (field: keyof typeof initialState, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.supplyGroupId) {
            alert('لطفا یک گروه تامین انتخاب کنید.');
            return;
        }
        addItem({
            code: formData.code,
            title: formData.title,
            primaryUnit: formData.primaryUnit,
            secondaryUnit: formData.secondaryUnit,
            lastSupplyPrice: Number(formData.lastSupplyPrice),
            supplyGroupId: Number(formData.supplyGroupId),
            vatRate: Number(formData.vatRate || 0),
        });
        setFormData(initialState);
        alert('قلم خریدنی جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (item: PurchaseItem) => {
        setSelectedItem(item);
        setEditModalOpen(true);
    };

    const handleDelete = (itemId: number) => {
        if (window.confirm('آیا از حذف این قلم اطمینان دارید؟')) {
            deleteItem(itemId);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف اقلام خریدنی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-end">
                        <FormInput label="کد کالا" id="code" name="code" type="text" value={formData.code} onChange={handleChange} required />
                        <div className="md:col-span-2">
                            <FormInput label="عنوان کالا" id="title" name="title" type="text" value={formData.title} onChange={handleChange} required />
                        </div>
                        
                        <CustomFormSelect label="گروه تامین">
                           <SearchableSelect options={groupOptions} value={formData.supplyGroupId} onChange={val => handleValueChange('supplyGroupId', val)} placeholder="یک گروه انتخاب کنید..." />
                        </CustomFormSelect>
                        <CustomFormSelect label="واحد اندازه گیری اصلی">
                             <SearchableSelect options={unitOptions} value={formData.primaryUnit} onChange={val => handleValueChange('primaryUnit', val)} placeholder="انتخاب واحد..." />
                        </CustomFormSelect>
                        <CustomFormSelect label="واحد اندازه گیری فرعی">
                             <SearchableSelect options={unitOptions} value={formData.secondaryUnit} onChange={val => handleValueChange('secondaryUnit', val)} placeholder="انتخاب واحد..." />
                        </CustomFormSelect>
                        
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">آخرین فی تامین</label>
                            <FormattedNumberInput value={formData.lastSupplyPrice} onValueChange={val => handleValueChange('lastSupplyPrice', val)} required className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">نرخ مالیات بر ارزش افزوده (%)</label>
                            <FormattedNumberInput value={formData.vatRate} onValueChange={val => handleValueChange('vatRate', val)} required className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
                        </div>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
                            ذخیره کالا
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">اقلام خریدنی تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">کد کالا</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">عنوان کالا</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">گروه تامین</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">واحد اصلی</th>
                             <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">نرخ مالیات بر ارزش افزوده (%)</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">آخرین فی</th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {items.length > 0 ? (
                            items.map((item) => (
                                <tr key={item.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{item.code}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{item.title}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{groupMap[item.supplyGroupId] || '-'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{item.primaryUnit}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">{item.vatRate}%</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">{new Intl.NumberFormat('en-US').format(item.lastSupplyPrice)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(item)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(item.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={7} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز کالایی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
             <EditItemModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                item={selectedItem}
                updateItem={updateItem}
                groups={groups}
                measurementUnits={measurementUnits}
            />
        </div>
    );
};

export default DefinePurchaseItem;
