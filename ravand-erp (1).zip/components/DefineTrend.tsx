

import React, { useState, useMemo, useEffect } from 'react';
import type { TrendForm, TrendStage, TrendBox, TrendField, FormOption, QuestionType, TrendButton, DeploymentNode, OrgChartNode } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';

interface DefineTrendProps {
    onSaveForm: (form: Omit<TrendForm, 'id' | 'published'>) => void;
    trendForms: TrendForm[];
    updateTrendForm: (form: TrendForm) => void;
    deploymentStructure: DeploymentNode[];
    orgChart: OrgChartNode[];
}

const initialField: Omit<TrendField, 'id'> = {
    labelText: '',
    fieldType: 'short-text',
    options: [],
    required: false,
    formula: '',
};

const initialButton: Omit<TrendButton, 'id'> = {
    text: 'دکمه',
    destinationBoxId: null,
    color: '#3399FF',
    requiredFieldIds: [],
};

const initialBox: Omit<TrendBox, 'id'> = {
    name: 'باکس ۱',
    stageId: null,
    position: '',
    relatedTaskId: null,
    fields: [{ ...initialField, id: Date.now() }],
    buttons: [],
};

const initialForm: Omit<TrendForm, 'id' | 'published'> = {
    title: 'فرم بدون عنوان',
    description: '',
    stages: [],
    boxes: [{ ...initialBox, id: Date.now() }],
};

const ToggleSwitch: React.FC<{ checked: boolean; onChange: () => void; }> = ({ checked, onChange }) => {
    return (
      <label className="relative inline-flex items-center cursor-pointer">
        <input type="checkbox" checked={checked} onChange={onChange} className="sr-only peer" />
        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-cyan-600"></div>
      </label>
    );
};


const FieldTypeSelector: React.FC<{ value: QuestionType, onChange: (value: QuestionType) => void }> = ({ value, onChange }) => (
    <select value={value} onChange={e => onChange(e.target.value as QuestionType)} className="p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:ring-custom-blue-primary focus:border-custom-blue-primary">
        <option value="short-text">پاسخ کوتاه</option>
        <option value="paragraph">پاراگراف</option>
        <option value="number">عدد</option>
        <option value="multiple-choice">چند گزینه‌ای</option>
        <option value="checkboxes">چک‌باکس</option>
        <option value="dropdown">لیست کشویی</option>
        <option value="rating">امتیازدهی</option>
        <option value="formula">فرمول</option>
        <option value="location">موقعیت مکانی</option>
        <option value="file-upload">بارگذاری فایل</option>
    </select>
);

const FormPreviewModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    form: Omit<TrendForm, 'id'>
}> = ({ isOpen, onClose, form }) => {
    const [currentBoxId, setCurrentBoxId] = useState<number | null>(null);

    useEffect(() => {
        if (isOpen && form.boxes.length > 0) {
            setCurrentBoxId(form.boxes[0].id);
        } else {
            setCurrentBoxId(null);
        }
    }, [isOpen, form.boxes]);

    const currentBox = useMemo(() => form.boxes.find(b => b.id === currentBoxId), [currentBoxId, form.boxes]);

    const handleNavigate = (destinationBoxId: number | null) => {
        if (destinationBoxId) {
            if (form.boxes.some(b => b.id === destinationBoxId)) {
                setCurrentBoxId(destinationBoxId);
            } else {
                alert("خطا: باکس مقصد یافت نشد.");
            }
        } else {
            alert("این دکمه مقصدی ندارد و روند در همین مرحله به پایان میرسد.");
            onClose();
        }
    };

    const renderFieldPreview = (field: TrendField) => (
        <div key={field.id} className="p-3 bg-white dark:bg-slate-700 rounded-md border dark:border-slate-600">
            <label className="font-semibold text-slate-800 dark:text-slate-200">
                {field.labelText || "فیلد بدون عنوان"}
                {field.required && <span className="text-red-500 mr-1">*</span>}
            </label>
            <div className="mt-2 text-slate-600 dark:text-slate-400">
                {/* Render a read-only representation of the field */}
                {['multiple-choice', 'checkboxes', 'dropdown'].includes(field.fieldType) ? (
                     <div className="space-y-1">
                        {field.options.map((opt: FormOption) => <div key={opt.id}>- {opt.value}</div>)}
                    </div>
                ) : field.fieldType === 'rating' ? (
                     <div className="flex items-center gap-1 text-2xl text-slate-300">
                        <span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
                    </div>
                ) : (
                    <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-md text-sm italic">
                        ورودی برای نوع "{field.fieldType}"
                    </div>
                )}
            </div>
        </div>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`پیش‌نمایش: ${form.title}`}>
            <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg">
                {currentBox ? (
                    <div>
                        <h3 className="text-xl font-bold mb-1 text-slate-900 dark:text-white">{currentBox.name}</h3>
                        <p className="text-sm text-slate-500 mb-4">مرحله: {form.stages.find(s=>s.id === currentBox.stageId)?.name || 'نامشخص'}</p>
                        
                        <div className="space-y-4 mb-6">
                            {currentBox.fields.map(field => renderFieldPreview(field))}
                        </div>
                        
                        <div className="flex flex-wrap gap-2 pt-4 border-t dark:border-slate-600">
                            {currentBox.buttons.map(button => (
                                <button
                                    key={button.id}
                                    style={{ backgroundColor: button.color }}
                                    onClick={() => handleNavigate(button.destinationBoxId)}
                                    className="px-4 py-2 text-white rounded-md text-sm shadow-md hover:opacity-90 transition-opacity"
                                >
                                    {button.text}
                                </button>
                            ))}
                        </div>
                    </div>
                ) : (
                    <p className="text-center py-8">باکسی برای نمایش وجود ندارد.</p>
                )}
            </div>
        </Modal>
    );
};


const FieldEditor: React.FC<{
    field: TrendField;
    updateField: (updatedField: TrendField) => void;
    deleteField: () => void;
}> = ({ field, updateField, deleteField }) => {

    const handleOptionChange = (optionId: number, value: string) => {
        const updatedOptions = field.options.map(opt => opt.id === optionId ? { ...opt, value } : opt);
        updateField({ ...field, options: updatedOptions });
    };

    const addOption = () => {
        const newOption: FormOption = { id: Date.now(), value: `گزینه ${field.options.length + 1}` };
        updateField({ ...field, options: [...field.options, newOption] });
    };

    const removeOption = (optionId: number) => {
        const updatedOptions = field.options.filter(opt => opt.id !== optionId);
        updateField({ ...field, options: updatedOptions });
    };

    const hasOptions = ['multiple-choice', 'checkboxes', 'dropdown'].includes(field.fieldType);
    const isFormula = field.fieldType === 'formula';
    const isRating = field.fieldType === 'rating';
    const isNumber = field.fieldType === 'number';
    const isLocation = field.fieldType === 'location';
    const isFileUpload = field.fieldType === 'file-upload';

    const renderFieldPreview = () => {
        if (hasOptions) {
            return (
                <div className="space-y-2">
                    {field.options.map(opt => (
                        <div key={opt.id} className="flex items-center gap-2">
                            {field.fieldType === 'dropdown' ? <span className="text-slate-500">{field.options.indexOf(opt) + 1}.</span> :
                             field.fieldType === 'multiple-choice' ? <span className="text-slate-400">⚪</span> : <span className="text-slate-400">⬜</span>}
                            <input
                                type="text"
                                value={opt.value}
                                onChange={e => handleOptionChange(opt.id, e.target.value)}
                                className="flex-grow p-2 bg-transparent focus:bg-slate-100 dark:focus:bg-slate-700 rounded-md outline-none"
                            />
                            <button onClick={() => removeOption(opt.id)} className="text-slate-400 hover:text-red-500 p-1">
                                &times;
                            </button>
                        </div>
                    ))}
                    <button onClick={addOption} className="text-sm text-custom-blue-primary hover:underline mt-2">افزودن گزینه</button>
                </div>
            )
        }
        if (isFormula) {
            return (
                <input
                    type="text"
                    value={field.formula}
                    onChange={e => updateField({ ...field, formula: e.target.value })}
                    placeholder="مثال: field_1 + field_2"
                    className="w-full ltr-input p-2 bg-slate-100 dark:bg-slate-700 rounded-md font-mono"
                />
            );
        }
        if(isRating) {
            return (
                <div className="flex items-center gap-1 text-2xl text-slate-300">
                    <span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
                </div>
            )
        }
        if(isNumber) {
            return  <input type="number" disabled placeholder="123" className="w-1/2 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" />
        }
        if(isLocation) {
            return <button type="button" className="px-4 py-2 text-sm rounded-md bg-slate-200 dark:bg-slate-600">انتخاب موقعیت</button>
        }
        if(isFileUpload) {
            return <input type="file" disabled className="text-sm" />
        }
        return <p className="text-sm text-slate-400 border-b-2 border-dotted w-1/2">پاسخ {field.fieldType === 'short-text' ? 'کوتاه' : 'بلند'}</p>
    };

    return (
        <div className="p-4 border-t dark:border-slate-600">
            <div className="flex flex-col md:flex-row gap-4">
                <input
                    type="text"
                    value={field.labelText}
                    onChange={e => updateField({ ...field, labelText: e.target.value })}
                    placeholder="عنوان فیلد"
                    className="flex-grow text-base p-3 bg-slate-100 dark:bg-slate-700 rounded-md focus:bg-white dark:focus:bg-slate-600 outline-none"
                />
                <FieldTypeSelector
                    value={field.fieldType}
                    onChange={type => updateField({ ...field, fieldType: type, options: ['multiple-choice', 'checkboxes', 'dropdown'].includes(type) && field.options.length === 0 ? [{ id: Date.now(), value: 'گزینه ۱' }] : [] })}
                />
            </div>
            <div className="mt-4">
                {renderFieldPreview()}
            </div>
            <div className="mt-6 flex justify-end items-center gap-4 text-slate-500 dark:text-slate-400">
                <button onClick={deleteField} title="حذف فیلد">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                </button>
                <span className="border-l h-6 dark:border-slate-600"></span>
                <div className="flex items-center gap-2">
                    <label htmlFor={`required-${field.id}`} className="text-sm">ضروری</label>
                    <input id={`required-${field.id}`} type="checkbox" checked={field.required} onChange={e => updateField({ ...field, required: e.target.checked })} className="h-5 w-5 rounded text-custom-blue-primary focus:ring-custom-blue-primary/50" />
                </div>
            </div>
        </div>
    );
};


const BoxCard: React.FC<{
    box: TrendBox;
    updateBox: (id: number, updatedBox: Omit<TrendBox, 'id'>) => void;
    deleteBox: (id: number) => void;
    stages: TrendStage[];
    allBoxes: TrendBox[];
    positions: { value: string; label: string }[];
    tasks: { value: number; label: string }[];
}> = ({ box, updateBox, deleteBox, stages, allBoxes, positions, tasks }) => {
    
    // Field Handlers
    const addField = () => {
        const newField: TrendField = { ...initialField, id: Date.now() };
        updateBox(box.id, { ...box, fields: [...box.fields, newField] });
    };

    const updateField = (fieldId: number, updatedField: TrendField) => {
        const updatedFields = box.fields.map(f => f.id === fieldId ? updatedField : f);
        updateBox(box.id, { ...box, fields: updatedFields });
    };

    const deleteField = (fieldId: number) => {
        if (box.fields.length <= 1) {
            alert('هر باکس باید حداقل یک فیلد داشته باشد.'); return;
        }
        updateBox(box.id, { ...box, fields: box.fields.filter(f => f.id !== fieldId) });
    };

    // Button Handlers
    const addButton = () => {
        const newButton: TrendButton = { ...initialButton, id: Date.now() };
        updateBox(box.id, { ...box, buttons: [...box.buttons, newButton] });
    };
    
    const updateButton = (buttonId: number, updatedButton: TrendButton) => {
        updateBox(box.id, { ...box, buttons: box.buttons.map(b => b.id === buttonId ? updatedButton : b) });
    };

    const deleteButton = (buttonId: number) => {
        updateBox(box.id, { ...box, buttons: box.buttons.filter(b => b.id !== buttonId) });
    };

    return (
        <Card className="p-0 border-l-4 border-slate-300 dark:border-slate-600">
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-t-xl">
                 <div className="flex flex-col md:flex-row gap-4 justify-between">
                    <div className="flex flex-wrap items-center gap-4 flex-grow">
                         <input
                            type="text"
                            value={box.name}
                            onChange={e => updateBox(box.id, { ...box, name: e.target.value })}
                            placeholder="نام باکس"
                            className="p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 flex-1 min-w-[150px]"
                        />
                        <select
                            value={box.stageId || ''}
// FIX: Property 'value' does not exist on type 'unknown'.
                            onChange={e => updateBox(box.id, { ...box, stageId: e.currentTarget.value ? Number(e.currentTarget.value) : null })}
                            className="p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 flex-1 min-w-[150px]"
                        >
                            <option value="">-- انتخاب مرحله --</option>
                            {stages.map(stage => <option key={stage.id} value={stage.id}>{stage.name}</option>)}
                        </select>
                        <div className="flex-1 min-w-[160px]">
                           <SearchableSelect options={positions} value={box.position} onChange={val => updateBox(box.id, { ...box, position: val as string })} placeholder="سمت سازمانی..." />
                        </div>
                        <div className="flex-1 min-w-[160px]">
                           <SearchableSelect options={tasks} value={box.relatedTaskId} onChange={val => updateBox(box.id, { ...box, relatedTaskId: val as number | null })} placeholder="انتخاب وظیفه..." />
                        </div>
                    </div>
                    <button onClick={() => deleteBox(box.id)} title="حذف باکس" className="p-2 text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-500 self-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                    </button>
                 </div>
            </div>

            <div className="divide-y dark:divide-slate-700">
                {box.fields.map(field => (
                    <FieldEditor key={field.id} field={field} updateField={(uf) => updateField(field.id, uf)} deleteField={() => deleteField(field.id)} />
                ))}
            </div>
            
            <div className="p-4 border-t dark:border-slate-600 space-y-4">
                <h4 className="text-sm font-semibold text-slate-600 dark:text-slate-300">دکمه‌های عملیاتی</h4>
                {box.buttons.map(button => (
                    <div key={button.id} className="p-3 border rounded-lg dark:border-slate-600 bg-slate-50 dark:bg-slate-800/50 space-y-3">
                        <div className="flex items-center gap-4">
                            <input type="text" value={button.text} onChange={e => updateButton(button.id, {...button, text: e.target.value})} className="p-1 border-b bg-transparent" />
                            <input type="color" value={button.color} onChange={e => updateButton(button.id, {...button, color: e.target.value})} className="w-8 h-8"/>
                            <button onClick={() => deleteButton(button.id)} className="text-red-500 mr-auto">&times;</button>
                        </div>
                        <div>
                             <label className="text-xs">حالت بعدی (مقصد)</label>
                             <select
                                value={button.destinationBoxId || ''}
// FIX: Property 'value' does not exist on type 'unknown'.
                                onChange={e => updateButton(button.id, { ...button, destinationBoxId: e.currentTarget.value ? Number(e.currentTarget.value) : null })}
                                className="w-full p-2 mt-1 text-sm bg-white dark:bg-slate-700 rounded-md border"
                            >
                                <option value="">-- انتخاب باکس مقصد --</option>
                                {allBoxes.filter(b => b.id !== box.id).map(destBox => (
                                    <option key={destBox.id} value={destBox.id}>
                                        {destBox.name || `باکس بدون نام (ID: ${destBox.id})`}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs">فیلدهای ضروری</label>
                            <select multiple value={button.requiredFieldIds.map(String)} onChange={e => { const v = Array.from(e.target.selectedOptions, option => Number(option.value)); updateButton(button.id, {...button, requiredFieldIds: v})}} className="w-full text-xs p-2 mt-1 bg-white dark:bg-slate-700 rounded-md border h-20">
                                {box.fields.map(f => <option key={f.id} value={f.id}>{f.labelText || "فیلد بدون عنوان"}</option>)}
                            </select>
                        </div>
                    </div>
                ))}
                 <button onClick={addButton} className="text-sm text-custom-blue-primary hover:underline">افزودن دکمه</button>
            </div>

            <div className="p-2 text-center border-t dark:border-slate-700">
                 <button onClick={addField} className="text-sm text-custom-blue-primary hover:underline">افزودن فیلد جدید</button>
            </div>
        </Card>
    );
};

const DefineTrend: React.FC<DefineTrendProps> = ({ onSaveForm, trendForms, updateTrendForm, deploymentStructure, orgChart }) => {
    const [form, setForm] = useState<Omit<TrendForm, 'id' | 'published'>>(initialForm);
    const [newStageName, setNewStageName] = useState('');
    const [isPreviewOpen, setPreviewOpen] = useState(false);

    const orgPositions = useMemo(() => {
        const positions: { value: string, label: string }[] = [];
        const traverse = (nodes: OrgChartNode[]) => {
            nodes.forEach(node => {
                positions.push({ value: node.title, label: node.title });
                if (node.children) traverse(node.children);
            });
        };
        traverse(orgChart);
        return positions;
    }, [orgChart]);

    const deploymentTasks = useMemo(() => {
        const tasks: { value: number, label: string }[] = [];
        const findTasks = (nodes: DeploymentNode[]) => {
            nodes.forEach(node => {
                if (node.level === 6) {
                    tasks.push({ value: node.id, label: node.title });
                }
                if (node.children) findTasks(node.children);
            });
        };
        findTasks(deploymentStructure);
        return tasks;
    }, [deploymentStructure]);

    // Stage Handlers
    const addStage = () => {
        if (!newStageName.trim()) return;
        const newStage: TrendStage = { id: Date.now(), name: newStageName.trim(), order: form.stages.length + 1, };
        setForm(prev => ({ ...prev, stages: [...prev.stages, newStage] }));
        setNewStageName('');
    };
    const deleteStage = (id: number) => {
        setForm(prev => ({...prev, stages: prev.stages.filter(s => s.id !== id), boxes: prev.boxes.map(b => b.stageId === id ? { ...b, stageId: null } : b) }));
    };

    // Box Handlers
    const addBox = () => {
        const newBox: TrendBox = { ...initialBox, id: Date.now(), name: `باکس ${form.boxes.length + 1}` };
        setForm(prev => ({ ...prev, boxes: [...prev.boxes, newBox] }));
    };
    const updateBox = (id: number, updatedBox: Omit<TrendBox, 'id'>) => {
        setForm(prev => ({ ...prev, boxes: prev.boxes.map(b => b.id === id ? { id, ...updatedBox } : b) }));
    };
    const deleteBox = (id: number) => {
        if (form.boxes.length <= 1) { alert('فرم باید حداقل یک باکس داشته باشد.'); return; }
        setForm(prev => ({ ...prev, boxes: prev.boxes.filter(b => b.id !== id) }));
    };
    
    const handleSave = () => {
        onSaveForm(form);
        setForm(initialForm);
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div className='flex justify-between items-center'>
                 <h1 className="text-2xl font-bold text-slate-900 dark:text-white">طراحی فرم روند</h1>
                 <div className="flex gap-2">
                    <button onClick={() => setPreviewOpen(true)} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600">
                        پیش‌نمایش فرم
                    </button>
                    <button onClick={handleSave} className="px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                        ذخیره فرم
                    </button>
                 </div>
            </div>
           
            <Card className="border-t-8 border-custom-blue-primary">
                <input type="text" value={form.title} onChange={e => setForm(prev => ({ ...prev, title: e.target.value }))} className="text-3xl font-bold w-full p-2 bg-transparent focus:bg-slate-100 dark:focus:bg-slate-700 rounded-md outline-none" />
                <textarea value={form.description} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} placeholder="توضیحات فرم" className="text-base w-full mt-2 p-2 bg-transparent focus:bg-slate-100 dark:focus:bg-slate-700 rounded-md outline-none resize-none" rows={2} />
            </Card>

            <Card>
                <h2 className="text-lg font-semibold mb-4 text-slate-800 dark:text-slate-200">تعریف مراحل روند</h2>
                <div className="flex flex-col sm:flex-row gap-4">
                    <input type="text" value={newStageName} onChange={e => setNewStageName(e.target.value)} placeholder="نام مرحله جدید" className="flex-grow p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
                    <button onClick={addStage} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">افزودن مرحله</button>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                    {form.stages.map(stage => (
                        <div key={stage.id} className="flex items-center gap-2 bg-slate-200 dark:bg-slate-700 rounded-full px-3 py-1 text-sm">
                            <span>{stage.name}</span>
                            <button onClick={() => deleteStage(stage.id)} className="text-slate-500 hover:text-red-500">&times;</button>
                        </div>
                    ))}
                </div>
            </Card>

            <div className="space-y-4">
                {form.boxes.map(box => (
                    <BoxCard key={box.id} box={box} updateBox={updateBox} deleteBox={deleteBox} stages={form.stages} allBoxes={form.boxes} positions={orgPositions} tasks={deploymentTasks}/>
                ))}
            </div>

            <div className="text-center">
                <button onClick={addBox} className="px-6 py-2 text-sm font-medium text-white bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-md">
                    افزودن باکس جدید
                </button>
            </div>

            <FormPreviewModal isOpen={isPreviewOpen} onClose={() => setPreviewOpen(false)} form={form} />

            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">فهرست فرم‌های ذخیره شده</h2>
                {trendForms.length > 0 ? (
                    <ul className="space-y-3">
                        {trendForms.map(savedForm => (
                            <li key={savedForm.id} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border dark:border-slate-700 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-slate-900 dark:text-white">{savedForm.title}</h3>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{savedForm.description}</p>
                                </div>
                                <div className="flex items-center gap-4">
                                    <span className={`text-xs px-2 py-1 rounded-full ${savedForm.published ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-slate-200 text-slate-600 dark:bg-slate-600 dark:text-slate-300'}`}>{savedForm.published ? 'منتشر شده' : 'پیش‌نویس'}</span>
                                    <ToggleSwitch
                                        checked={savedForm.published}
                                        onChange={() => updateTrendForm({ ...savedForm, published: !savedForm.published })}
                                    />
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-center text-slate-500 dark:text-slate-400 py-4">هنوز فرمی ذخیره نشده است.</p>
                )}
            </Card>
        </div>
    );
};

export default DefineTrend;