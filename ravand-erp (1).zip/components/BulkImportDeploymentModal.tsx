import React, { useState } from 'react';
import Modal from './ui/Modal';
import type { DeploymentNode } from '../../types';

interface BulkImportDeploymentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (nodes: DeploymentNode[]) => void;
}

const BulkImportDeploymentModal: React.FC<BulkImportDeploymentModalProps> = ({ isOpen, onClose, onSave }) => {
    const [file, setFile] = useState<File | null>(null);
    const [feedback, setFeedback] = useState<{ success: string[]; errors: string[] }>({ success: [], errors: [] });
    const [isProcessing, setIsProcessing] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setFeedback({ success: [], errors: [] });
        }
    };

    const handleDownloadTemplate = () => {
        const header = "پروژه,فاز,عملیات,فعالیت,اقدام,وظیفه\n";
        const example1 = "پروژه آلفا,فاز 1 طراحی,تحلیل نیازمندی‌ها,جلسه با مشتریان,جمع‌آوری بازخورد,تنظیم صورت جلسه\n";
        const example2 = ",,,بررسی اسناد موجود,دسته‌بندی اسناد,اسکن مدارک\n";
        const example3 = ",,توسعه و پیاده‌سازی,برنامه‌نویسی ماژول A,کدنویسی بخش ورود,ایجاد فرم لاگین\n";
        const example4 = "پروژه بتا,فاز 1,,,,,\n";
        const content = header + example1 + example2 + example3 + example4;
        
        const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "deployment_structure_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const processFile = () => {
        if (!file) return;

        setIsProcessing(true);
        setFeedback({ success: [], errors: [] });

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1).filter(line => line.trim());
            
            const localErrors: string[] = [];
            const rootNodes: DeploymentNode[] = [];
            const nodeMap = new Map<number, DeploymentNode>();
            
            // This array keeps track of the last valid parent ID for each level (0-indexed).
            const lastParentIds: (number | null)[] = [null, null, null, null, null, null];
            let nodeIdCounter = 1;

            lines.forEach((line, index) => {
                const rowNum = index + 2;
                const columns = line.split(',').map(s => s.trim());

                if (columns.length < 6) {
                    localErrors.push(`Row ${rowNum}: Invalid number of columns. Expected 6.`);
                    return;
                }
                
                let foundValueInRow = false;

                for (let i = 0; i < 6; i++) {
                    const title = columns[i];
                    if (title) {
                        foundValueInRow = true;
                        const parentId = i > 0 ? lastParentIds[i - 1] : null;

                        if (i > 0 && parentId === null) {
                            localErrors.push(`Row ${rowNum}: Cannot define a level ${i+1} item ("${title}") without a parent in the previous level.`);
                            // Invalidate further children in this branch
                            for(let j=i; j<6; j++) { lastParentIds[j] = null; }
                            return; // Stop processing this row
                        }

                        const newNode: DeploymentNode = {
                            id: nodeIdCounter++,
                            title,
                            level: (i + 1) as DeploymentNode['level'],
                            parentId,
                            children: [],
                        };
                        
                        nodeMap.set(newNode.id, newNode);
                        lastParentIds[i] = newNode.id;

                        // Reset parent IDs for subsequent levels in this row
                        for (let j = i + 1; j < 6; j++) {
                            lastParentIds[j] = null;
                        }

                        if (parentId === null) {
                            rootNodes.push(newNode);
                        } else {
                            const parentNode = nodeMap.get(parentId);
                            if (parentNode) {
                                parentNode.children.push(newNode);
                            }
                        }
                    }
                }
                
                if (!foundValueInRow) {
                    localErrors.push(`Row ${rowNum}: Empty row found.`);
                }
            });

            if (localErrors.length === 0 && rootNodes.length > 0) {
                onSave(rootNodes);
                setFeedback({ success: [`ساختار با موفقیت از ${lines.length} ردیف بارگذاری شد.`], errors: [] });
                onClose();
            } else {
                setFeedback({ success: [], errors: localErrors });
            }
            setIsProcessing(false);
        };
        reader.onerror = () => {
             setFeedback({ success: [], errors: ["خطا در خواندن فایل."] });
             setIsProcessing(false);
        };
        reader.readAsText(file);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="بارگذاری ساختار استقرار از اکسل (CSV)">
            <div className="space-y-4">
                <p className="text-sm text-slate-600 dark:text-slate-400">
                    برای بارگذاری ساختار، ابتدا فایل الگو را دانلود کرده و اطلاعات را در 6 ستون مشخص شده وارد کنید. هر ردیف نشان دهنده یک مسیر در درختواره است.
                </p>
                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۱: دانلود الگو</h3>
                    <button onClick={handleDownloadTemplate} className="mt-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                        دانلود فایل الگو (CSV)
                    </button>
                </div>

                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۲: بارگذاری فایل</h3>
                    <input type="file" accept=".csv" onChange={handleFileChange} className="mt-2 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                </div>
                
                {feedback.errors.length > 0 && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 rounded-md max-h-40 overflow-y-auto">
                        <h4 className="font-semibold text-red-800 dark:text-red-200">خطاها:</h4>
                        <ul className="list-disc list-inside text-sm text-red-700 dark:text-red-300">
                            {feedback.errors.map((err, i) => <li key={i}>{err}</li>)}
                        </ul>
                    </div>
                )}
                
                {feedback.success.length > 0 && (
                    <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-md text-center">
                        <p className="font-semibold text-green-800 dark:text-green-200">{feedback.success[0]}</p>
                    </div>
                )}


                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">بستن</button>
                    <button type="button" onClick={processFile} disabled={!file || isProcessing} className="px-4 py-2 text-sm rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300">
                        {isProcessing ? 'در حال پردازش...' : 'پردازش و ذخیره'}
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export default BulkImportDeploymentModal;