import React, { useState } from 'react';
import Modal from './ui/Modal';
import type { Person, NaturalPerson, LegalPerson } from '../types';
import { ContactType } from '../types';

interface BulkImportPersonsModalProps {
    isOpen: boolean;
    onClose: () => void;
    addPersonsBatch: (persons: (Omit<NaturalPerson, 'id'> | Omit<LegalPerson, 'id'>)[]) => void;
}

const BulkImportPersonsModal: React.FC<BulkImportPersonsModalProps> = ({ isOpen, onClose, addPersonsBatch }) => {
    const [file, setFile] = useState<File | null>(null);
    const [feedback, setFeedback] = useState<{ success: string[]; errors: string[] }>({ success: [], errors: [] });
    const [isProcessing, setIsProcessing] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setFeedback({ success: [], errors: [] });
        }
    };
    
    const handleDownloadTemplate = () => {
        const header = "personType(natural|legal),contactType(تامین کننده|مشتری),code,firstName,lastName,registeredName,brandName,nationalId,economicCode,address,mobile,phone\n";
        const example1 = "natural,مشتری,CUS-001,علی,احمدی,,,,1234567890,,Tehran,09123456789,\n";
        const example2 = "legal,تامین کننده,SUP-001,,,شرکت تجارت گستر,تجارت گستر,11122233344,41111111111,Isfahan,09130000000,03133333333\n";
        const content = header + example1 + example2;
        
        const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "persons_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const processFile = () => {
        if (!file) return;
        setIsProcessing(true);
        setFeedback({ success: [], errors: [] });

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1).filter(line => line.trim());
            
            const newPersons: (Omit<NaturalPerson, 'id'> | Omit<LegalPerson, 'id'>)[] = [];
            const localErrors: string[] = [];

            lines.forEach((line, index) => {
                const rowNum = index + 2;
                const [
                    personType, contactType, code, firstName, lastName, 
                    registeredName, brandName, nationalId, economicCode, 
                    address, mobile, phone
                ] = line.split(',').map(s => s.trim());

                if (!personType || !contactType) {
                    localErrors.push(`Row ${rowNum}: personType and contactType are required.`);
                    return;
                }

                const basePersonData = {
                    contactType: contactType as ContactType, code, nationalId, economicCode,
                    workshopCode: '', address, postalCode: '', phone, mobile,
                    accountNumber: '', cardNumber: '', iban: ''
                };

                if (personType.toLowerCase() === 'natural') {
                    if (!firstName || !lastName) {
                        localErrors.push(`Row ${rowNum}: firstName and lastName are required for natural persons.`);
                        return;
                    }
                    newPersons.push({ ...basePersonData, personType: 'natural', firstName, lastName, openingBalance: 0 });
                } else if (personType.toLowerCase() === 'legal') {
                    if (!registeredName) {
                        localErrors.push(`Row ${rowNum}: registeredName is required for legal persons.`);
                        return;
                    }
                    newPersons.push({ ...basePersonData, personType: 'legal', registeredName, brandName });
                } else {
                    localErrors.push(`Row ${rowNum}: Invalid personType "${personType}". Use 'natural' or 'legal'.`);
                }
            });

            if (localErrors.length === 0 && newPersons.length > 0) {
                addPersonsBatch(newPersons);
                setFeedback({ success: [`${newPersons.length} شخص با موفقیت بارگذاری شدند.`], errors: [] });
                setFile(null);
            } else {
                setFeedback({ success: [], errors: localErrors });
            }
            setIsProcessing(false);
        };
        reader.readAsText(file);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="بارگذاری گروهی اشخاص">
            <div className="space-y-4">
                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۱: دانلود الگو</h3>
                    <button onClick={handleDownloadTemplate} className="mt-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                        دانلود فایل الگو
                    </button>
                </div>

                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۲: بارگذاری فایل</h3>
                    <input type="file" accept=".csv" onChange={handleFileChange} className="mt-2 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                </div>
                
                {feedback.errors.length > 0 && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 rounded-md">
                        <h4 className="font-semibold text-red-800 dark:text-red-200">خطاها:</h4>
                        <ul className="list-disc list-inside text-sm text-red-700 dark:text-red-300">
                            {feedback.errors.map((err, i) => <li key={i}>{err}</li>)}
                        </ul>
                    </div>
                )}
                
                {feedback.success.length > 0 && (
                    <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-md text-center">
                        <p className="font-semibold text-green-800 dark:text-green-200">{feedback.success[0]}</p>
                    </div>
                )}


                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">بستن</button>
                    <button type="button" onClick={processFile} disabled={!file || isProcessing} className="px-4 py-2 text-sm rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300">
                        {isProcessing ? 'در حال پردازش...' : 'پردازش فایل'}
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export default BulkImportPersonsModal;
