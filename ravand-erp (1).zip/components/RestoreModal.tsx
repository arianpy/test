import React, { useState, useEffect } from 'react';
import Modal from './ui/Modal';
import type { Backup } from '../types';

interface RestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  backup: Backup | null;
}

// Mock admin credentials
const ADMIN_PASSWORD = 'AdminPassword123';
const ADMIN_MOBILE = '09120000000';
const ADMIN_EMAIL = 'admin@ravand.com';
const MOCK_VERIFICATION_CODE = '123456';

const RestoreModal: React.FC<RestoreModalProps> = ({ isOpen, onClose, backup }) => {
    const [step, setStep] = useState(1);
    const [password, setPassword] = useState('');
    const [mobile, setMobile] = useState('');
    const [error, setError] = useState('');
    const [verificationMethod, setVerificationMethod] = useState<'email' | 'phone'>('email');
    const [verificationCode, setVerificationCode] = useState('');
    const [timer, setTimer] = useState(120);

    // Reset state whenever the modal is opened or closed
    useEffect(() => {
        if (!isOpen) {
            setTimeout(() => { // Delay reset to allow closing animation
                setStep(1);
                setPassword('');
                setMobile('');
                setError('');
                setVerificationMethod('email');
                setVerificationCode('');
                setTimer(120);
            }, 300);
        }
    }, [isOpen]);

    // Timer countdown effect
    useEffect(() => {
        if (step === 3 && timer > 0) {
            const intervalId = setInterval(() => {
                setTimer(prevTimer => prevTimer - 1);
            }, 1000);
            return () => clearInterval(intervalId);
        } else if (timer === 0 && step === 3) {
            setError('زمان شما به پایان رسیده است. لطفا دوباره تلاش کنید.');
        }
    }, [step, timer]);
    
    const handleCredentialSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (password === ADMIN_PASSWORD && mobile === ADMIN_MOBILE) {
            setStep(2);
        } else {
            setError('رمز عبور ثابت یا شماره همراه ادمین نامعتبر است.');
        }
    };

    const handleSendCode = (e: React.FormEvent) => {
        e.preventDefault();
        console.log(`Simulating sending code via ${verificationMethod}`);
        setStep(3);
    };

    const handleVerifyAndRestore = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (timer <= 0) {
            setError('زمان شما به پایان رسیده است. لطفا دوباره تلاش کنید.');
            return;
        }
        if (verificationCode === MOCK_VERIFICATION_CODE) {
            console.log(`Restoring from backup: ${backup?.filename}`);
            // Here you would trigger the actual restore logic
            setStep(4);
        } else {
            setError('کد تایید نامعتبر است.');
        }
    };

    const renderStepContent = () => {
        switch (step) {
            case 1: // Admin credentials
                return (
                    <form onSubmit={handleCredentialSubmit} className="space-y-4">
                        <p className="text-sm text-slate-600 dark:text-slate-400">برای شروع فرآیند بازیابی، لطفا اطلاعات ادمین سیستم را وارد کنید.</p>
                        {error && <div className="p-3 bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 rounded-md text-sm">{error}</div>}
                        <div>
                            <label className="block text-sm font-medium">رمز ثابت ادمین</label>
                            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">شماره همراه ادمین</label>
                            <input type="tel" value={mobile} onChange={e => setMobile(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                        </div>
                        <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                             <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">انصراف</button>
                             <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">ادامه</button>
                        </div>
                    </form>
                );
            case 2: // Verification method
                 return (
                    <form onSubmit={handleSendCode} className="space-y-6">
                        <p className="text-sm text-slate-600 dark:text-slate-400">یک کد تایید برای شما ارسال خواهد شد. روش ارسال را انتخاب کنید.</p>
                         <fieldset className="space-y-2">
                             <div className="flex items-center space-x-4 rtl:space-x-reverse">
                                 <label className="flex items-center cursor-pointer">
                                     <input type="radio" name="method" value="email" checked={verificationMethod === 'email'} onChange={() => setVerificationMethod('email')} className="form-radio text-custom-blue-primary"/>
                                     <span className="mr-2">ارسال به ایمیل ({ADMIN_EMAIL})</span>
                                 </label>
                                 <label className="flex items-center cursor-pointer">
                                     <input type="radio" name="method" value="phone" checked={verificationMethod === 'phone'} onChange={() => setVerificationMethod('phone')} className="form-radio text-custom-blue-primary"/>
                                     <span className="mr-2">ارسال به موبایل ({ADMIN_MOBILE})</span>
                                 </label>
                             </div>
                         </fieldset>
                         <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                            <button type="button" onClick={() => setStep(1)} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">بازگشت</button>
                            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">ارسال کد</button>
                        </div>
                    </form>
                );
            case 3: // Enter code
                return (
                     <form onSubmit={handleVerifyAndRestore} className="space-y-4">
                        <p className="text-sm text-slate-600 dark:text-slate-400">کد ۶ رقمی ارسال شده به {verificationMethod === 'email' ? ADMIN_EMAIL : ADMIN_MOBILE} را وارد کنید.</p>
                        {error && <div className="p-3 bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 rounded-md text-sm">{error}</div>}
                        <div className="text-center">
                             <input 
                                type="text" 
                                value={verificationCode} 
                                onChange={e => setVerificationCode(e.target.value)} 
                                maxLength={6}
                                required 
                                className="w-48 text-center text-2xl tracking-[.5em] font-mono p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" 
                            />
                        </div>
                         <div className="text-center text-lg font-mono text-red-500">
                            {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')}
                        </div>
                        <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                             <button type="button" onClick={() => setStep(2)} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">بازگشت</button>
                             <button type="submit" disabled={timer === 0} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-slate-400">تایید و بازیابی</button>
                        </div>
                    </form>
                );
            case 4: // Success
                return (
                     <div className="space-y-4 text-center">
                        <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 dark:bg-green-900">
                            <svg className="h-6 w-6 text-green-600 dark:text-green-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <h3 className="text-lg font-medium text-slate-900 dark:text-white">بازیابی موفق</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                            فایل <span className="font-mono">{backup?.filename}</span> با موفقیت در سیستم بازیابی شد.
                        </p>
                        <div className="pt-4">
                             <button onClick={onClose} className="w-full px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                                بستن
                            </button>
                        </div>
                    </div>
                );
            default: return null;
        }
    };
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`بازیابی پشتیبان: ${backup?.filename}`}>
            {renderStepContent()}
        </Modal>
    );
};

export default RestoreModal;
