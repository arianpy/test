import React, { useState } from 'react';
import Modal from './ui/Modal';
import type { Personnel } from '../types';

interface BulkImportPersonnelModalProps {
    isOpen: boolean;
    onClose: () => void;
    addPersonnelBatch: (personnel: Omit<Personnel, 'id' | 'contracts'>[]) => void;
}

const BulkImportPersonnelModal: React.FC<BulkImportPersonnelModalProps> = ({ isOpen, onClose, addPersonnelBatch }) => {
    const [file, setFile] = useState<File | null>(null);
    const [feedback, setFeedback] = useState<{ success: string[]; errors: string[] }>({ success: [], errors: [] });
    const [isProcessing, setIsProcessing] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setFeedback({ success: [], errors: [] });
        }
    };
    
    const handleDownloadTemplate = () => {
        const header = "employeeCode,firstName,lastName,gender(male|female),fatherName,birthDate(YYYY-MM-DD),nationalId,mobile,email,position,employmentDate(YYYY-MM-DD)\n";
        const example1 = "EMP-001,رضا,کریمی,male,محمد,1990-05-15,1234567890,09121112233,reza.k@example.com,کارشناس فروش,2020-01-01\n";
        const example2 = "EMP-002,مریم,صادقی,female,علی,1995-10-20,0987654321,09124445566,maryam.s@example.com,حسابدار,2021-06-15\n";
        const content = header + example1 + example2;
        
        const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "personnel_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const processFile = () => {
        if (!file) return;

        setIsProcessing(true);
        setFeedback({ success: [], errors: [] });

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1).filter(line => line.trim());
            
            const newPersonnelList: Omit<Personnel, 'id' | 'contracts'>[] = [];
            const localErrors: string[] = [];

            lines.forEach((line, index) => {
                const rowNum = index + 2;
                const values = line.split(',').map(s => s.trim());
                const [
                    employeeCode, firstName, lastName, gender, fatherName, birthDate,
                    nationalId, mobile, email, position, employmentDate
                ] = values;

                if (!employeeCode || !firstName || !lastName || !gender) {
                    localErrors.push(`Row ${rowNum}: employeeCode, firstName, lastName, and gender are required.`);
                    return;
                }

                newPersonnelList.push({
                    employeeCode, firstName, lastName, gender: gender as 'male' | 'female', fatherName, birthDate, nationalId, mobile, email, position, employmentDate,
                    // Default values for other fields
                    educationLevel: '', fieldOfStudy: '', contractualJobTitle: '', birthCertNumber: '', insuranceNumber: '',
                    accountNumber: '', iban: '', cardNumber: '', address: '', phone: '', serviceEndDate: '', description: '',
                    openingBalance: 0, workLocation: '', costCenterCode: '', costCenterTitle: '',
                });
            });

            if (localErrors.length === 0 && newPersonnelList.length > 0) {
                addPersonnelBatch(newPersonnelList);
                setFeedback({ success: [`${newPersonnelList.length} پرسنل با موفقیت بارگذاری شدند.`], errors: [] });
                setFile(null);
            } else {
                setFeedback({ success: [], errors: localErrors });
            }
            
            setIsProcessing(false);
        };
        reader.readAsText(file);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="بارگذاری گروهی پرسنل">
            <div className="space-y-4">
                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۱: دانلود الگو</h3>
                    <button onClick={handleDownloadTemplate} className="mt-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                        دانلود فایل الگو
                    </button>
                </div>

                <div>
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">مرحله ۲: بارگذاری فایل</h3>
                    <input type="file" accept=".csv" onChange={handleFileChange} className="mt-2 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                </div>
                
                {feedback.errors.length > 0 && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 rounded-md">
                        <h4 className="font-semibold text-red-800 dark:text-red-200">خطاها:</h4>
                        <ul className="list-disc list-inside text-sm text-red-700 dark:text-red-300">
                            {feedback.errors.map((err, i) => <li key={i}>{err}</li>)}
                        </ul>
                    </div>
                )}
                
                {feedback.success.length > 0 && (
                    <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-md text-center">
                        <p className="font-semibold text-green-800 dark:text-green-200">{feedback.success[0]}</p>
                    </div>
                )}


                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">بستن</button>
                    <button type="button" onClick={processFile} disabled={!file || isProcessing} className="px-4 py-2 text-sm rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300">
                        {isProcessing ? 'در حال پردازش...' : 'پردازش فایل'}
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export default BulkImportPersonnelModal;
