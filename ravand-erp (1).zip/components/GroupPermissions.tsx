
import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { UserGroup, PermissionSet, PermissionKey, User } from '../types';
import { sidebarStructure, ModuleItem, SubViewEntry, GroupItem, SubViewGroup, SubViewSimple } from '../data/sidebarStructure';
import Card from './ui/Card';
import Modal from './ui/Modal';

interface GroupPermissionsProps {
    userGroups: UserGroup[];
    addUserGroup: (name: string) => void;
    updateUserGroup: (group: UserGroup) => void;
    deleteUserGroup: (groupId: number) => void;
    users: User[];
}

const GroupPermissionCheckbox: React.FC<{
    state: { checked: boolean, indeterminate: boolean };
    onChange: () => void;
}> = ({ state, onChange }) => {
    const ref = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (ref.current) {
            ref.current.checked = state.checked;
            ref.current.indeterminate = state.indeterminate;
        }
    }, [state.checked, state.indeterminate]);

    return (
        <input
            type="checkbox"
            ref={ref}
            onChange={onChange}
            className="h-4 w-4 rounded text-cyan-600 border-slate-300 focus:ring-cyan-500"
        />
    );
};


const ChevronIcon: React.FC<{ expanded: boolean }> = ({ expanded }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transition-transform duration-200 ${expanded ? 'rotate-90' : ''}`} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
    </svg>
);

const EditGroupModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (newName: string) => void;
    group: UserGroup | null;
}> = ({ isOpen, onClose, onSave, group }) => {
    const [name, setName] = useState('');

    useEffect(() => {
        if (group) {
            setName(group.name);
        }
    }, [group]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            onSave(name.trim());
        }
    };

    if (!isOpen) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش نام گروه: ${group?.name}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="editGroupName" className="block text-sm font-medium mb-1">نام جدید گروه</label>
                    <input
                        id="editGroupName"
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                        required
                    />
                </div>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                </div>
            </form>
        </Modal>
    );
};


const GroupPermissions: React.FC<GroupPermissionsProps> = ({ userGroups, addUserGroup, updateUserGroup, deleteUserGroup, users }) => {
    const [selectedGroupIds, setSelectedGroupIds] = useState<Set<number>>(new Set());
    const [newGroupName, setNewGroupName] = useState('');
    const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [editingGroup, setEditingGroup] = useState<UserGroup | null>(null);

    const selectedGroups = useMemo(() =>
        userGroups.filter(g => selectedGroupIds.has(g.id)),
        [userGroups, selectedGroupIds]
    );

    const prevUserGroupsLength = useRef(userGroups.length);
    useEffect(() => {
        if (userGroups.length > prevUserGroupsLength.current) {
            const newestGroup = userGroups.reduce((a, b) => a.id > b.id ? a : b);
            setSelectedGroupIds(new Set([newestGroup.id]));
        }
        prevUserGroupsLength.current = userGroups.length;
    }, [userGroups]);
    
     useEffect(() => {
        // Clear selection if a selected group is deleted
        setSelectedGroupIds(prev => {
            const existingIds = new Set(userGroups.map(g => g.id));
            const newSelection = new Set<number>();
            prev.forEach(id => {
                if (existingIds.has(id)) {
                    newSelection.add(id);
                }
            });
            return newSelection;
        });
    }, [userGroups]);

    const handleAddGroup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newGroupName.trim()) return;
        addUserGroup(newGroupName.trim());
        setNewGroupName('');
    };
    
    const handleOpenEditModal = (group: UserGroup) => {
        setEditingGroup(group);
        setEditModalOpen(true);
    };

    const handleDeleteSelectedGroups = () => {
        if (selectedGroupIds.size === 0) return;
        if (window.confirm(`آیا از حذف ${selectedGroupIds.size} گروه انتخاب شده اطمینان دارید؟`)) {
            selectedGroupIds.forEach(id => deleteUserGroup(id));
            setSelectedGroupIds(new Set());
        }
    };

    const handleGroupSelectionChange = (groupId: number, checked: boolean) => {
        setSelectedGroupIds(prev => {
            const newSet = new Set(prev);
            if (checked) {
                newSet.add(groupId);
            } else {
                newSet.delete(groupId);
            }
            return newSet;
        });
    };

    const toggleRow = (id: string) => {
        setExpandedRows(prev => ({ ...prev, [id]: !prev[id] }));
    };

    const permissionKeys: PermissionKey[] = useMemo(() => ['viewList', 'viewDetails', 'create', 'edit', 'delete'], []);

    const getAllSubViewIds = useMemo(() => {
        const memo = new Map<string, string[]>();
        const finder = (item: GroupItem | ModuleItem | SubViewEntry): string[] => {
            const id = 'type' in item ? (item.type === 'subgroup' ? `subgroup-${item.label}` : item.id) : item.id;
            if (memo.has(id)) return memo.get(id)!;
            
            let ids: string[] = [];
            if ('subViews' in item) {
                item.subViews.forEach(sv => { ids.push(...finder(sv)); });
            } else if ('modules' in item) {
                item.modules.forEach(mod => { ids.push(...finder(mod)); });
            } else if ('id' in item) {
                ids.push(item.id);
            }
            
            memo.set(id, ids);
            return ids;
        };
        return finder;
    }, []);

    const getPermissionState = (viewId: string, key: PermissionKey) => {
        if (selectedGroups.length === 0) return { checked: false, indeterminate: false };
        const every = selectedGroups.every(g => g.permissions[viewId]?.[key]);
        if (every) return { checked: true, indeterminate: false };
        const some = selectedGroups.some(g => g.permissions[viewId]?.[key]);
        if (some) return { checked: false, indeterminate: true };
        return { checked: false, indeterminate: false };
    };

    const handlePermissionChange = (viewId: string, key: PermissionKey) => {
        if (selectedGroups.length === 0) return;
        const state = getPermissionState(viewId, key);
        const newValue = !state.checked; // If checked, uncheck. If indeterminate or unchecked, check.

        selectedGroups.forEach(group => {
            const newPermissions = JSON.parse(JSON.stringify(group.permissions));
            if (!newPermissions[viewId]) newPermissions[viewId] = {};
            newPermissions[viewId][key] = newValue;
            updateUserGroup({ ...group, permissions: newPermissions });
        });
    };

    const getGroupPermissionState = (item: GroupItem | ModuleItem | SubViewEntry) => {
        if (selectedGroups.length === 0) return { checked: false, indeterminate: false };
        const subViewIds = getAllSubViewIds(item);
        if (subViewIds.length === 0) return { checked: false, indeterminate: false };

        let totalPermissions = 0;
        let checkedPermissions = 0;

        for (const group of selectedGroups) {
            for (const viewId of subViewIds) {
                for (const key of permissionKeys) {
                    totalPermissions++;
                    if (group.permissions[viewId]?.[key]) {
                        checkedPermissions++;
                    }
                }
            }
        }
        if (totalPermissions === 0) return { checked: false, indeterminate: false };

        if (checkedPermissions === 0) return { checked: false, indeterminate: false };
        if (checkedPermissions === totalPermissions) return { checked: true, indeterminate: false };
        return { checked: false, indeterminate: true };
    };
    
    const handleGroupPermissionChange = (item: GroupItem | ModuleItem | SubViewEntry) => {
        if (selectedGroups.length === 0) return;
        const subViewIds = getAllSubViewIds(item);
        if (subViewIds.length === 0) return;

        const state = getGroupPermissionState(item);
        const newValue = !state.checked;

        selectedGroups.forEach(group => {
            const newPermissions = JSON.parse(JSON.stringify(group.permissions));
            subViewIds.forEach(viewId => {
                if (!newPermissions[viewId]) newPermissions[viewId] = {};
                permissionKeys.forEach(key => {
                    newPermissions[viewId][key] = newValue;
                });
            });
            updateUserGroup({ ...group, permissions: newPermissions });
        });
    };
    
    const renderRows = (items: (GroupItem | ModuleItem | SubViewEntry)[], level = 0): React.ReactElement[] => {
        return items.map(item => {
            const id = 'type' in item ? (item.type === 'subgroup' ? `subgroup-${item.label}` : item.id) : item.id;
            const isExpanded = !!expandedRows[id];
            
            const isExpandable = ('modules' in item && item.modules.length > 0) || ('subViews' in item && item.subViews.length > 0);
            
            const children = 'modules' in item ? item.modules : ('subViews' in item ? item.subViews : []);

            return (
                <React.Fragment key={id}>
                    <tr className={`border-b dark:border-slate-700 ${level > 0 ? 'bg-slate-50 dark:bg-slate-800/50' : ''}`}>
                        <td className="px-4 py-2" style={{ paddingRight: `${level * 24 + 16}px` }}>
                            <div className="flex items-center">
                                {isExpandable && (
                                    <button onClick={() => toggleRow(id)} className="ml-2 p-1 text-slate-500">
                                        <ChevronIcon expanded={isExpanded} />
                                    </button>
                                )}
                                <span className={`font-medium ${level === 0 ? 'text-lg text-slate-800 dark:text-slate-100' : 'text-slate-700 dark:text-slate-300'}`}>{item.label}</span>
                            </div>
                        </td>
                        <td className="px-4 py-2 text-center">
                           <GroupPermissionCheckbox state={getGroupPermissionState(item)} onChange={() => handleGroupPermissionChange(item)} />
                        </td>
                         {permissionKeys.map(key => {
                            if (!('type' in item) || (item.type !== 'module' && item.type !== 'group' && item.type !== 'subgroup')) {
                                const viewId = (item as SubViewSimple).id;
                                return (
                                <td key={key} className="px-4 py-2 text-center">
                                    <GroupPermissionCheckbox state={getPermissionState(viewId, key)} onChange={() => handlePermissionChange(viewId, key)} />
                                </td>
                                )
                            }
                            return <td key={key} className="px-4 py-2 text-center"></td>
                        })}
                    </tr>
                    {isExpanded && children.length > 0 && renderRows(children, level + 1)}
                </React.Fragment>
            );
        });
    };


    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گروه کاربران و دسترسی‌ها</h1>
            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">مدیریت گروه‌ها</h2>
                <div className="p-4 border rounded-lg dark:border-slate-700 mb-6 bg-slate-50 dark:bg-slate-800">
                    <form onSubmit={handleAddGroup} className="flex flex-col sm:flex-row items-end sm:space-x-4 sm:rtl:space-x-reverse space-y-4 sm:space-y-0">
                        <div className="flex-grow w-full">
                            <label htmlFor="newGroupName" className="block text-sm font-medium text-slate-700 dark:text-slate-300">نام گروه جدید</label>
                            <input id="newGroupName" type="text" value={newGroupName} onChange={e => setNewGroupName(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                        </div>
                        <button type="submit" className="w-full sm:w-auto px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 h-10 flex-shrink-0">افزودن گروه</button>
                    </form>
                </div>

                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">فهرست گروه‌ها</h3>
                    {selectedGroupIds.size > 0 && (
                        <button onClick={handleDeleteSelectedGroups} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                            حذف {selectedGroupIds.size} گروه
                        </button>
                    )}
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                         <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام گروه</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">تعداد کاربران</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">انتخاب</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {userGroups.map(group => (
                                <tr key={group.id}>
                                    <td className="px-4 py-4 font-medium">{group.name}</td>
                                    <td className="px-4 py-4 text-center">{users.filter(u => u.userGroupId === group.id).length}</td>
                                    <td className="px-4 py-4 text-center"><input type="checkbox" checked={selectedGroupIds.has(group.id)} onChange={e => handleGroupSelectionChange(group.id, e.target.checked)} className="h-4 w-4 rounded text-cyan-600"/></td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(group)} className="text-amber-600 hover:text-amber-800">ویرایش نام</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>

            <Card>
                 <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">
                    تنظیمات دسترسی برای {selectedGroups.length === 0 ? "گروه انتخاب نشده" : selectedGroups.map(g => `"${g.name}"`).join(', ')}
                </h2>
                <div className="overflow-x-auto">
                     <table className="min-w-full w-full text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-10">
                            <tr>
                                <th className="px-4 py-3 text-right font-semibold text-slate-700 dark:text-slate-200 w-1/3">فرم / ماژول</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">دسترسی کامل</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">مشاهده لیست</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">مشاهده جزئیات</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">ایجاد</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">ویرایش</th>
                                <th className="px-4 py-3 text-center font-semibold text-slate-700 dark:text-slate-200">حذف</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white dark:bg-slate-900">
                            {renderRows(sidebarStructure)}
                         </tbody>
                    </table>
                </div>
            </Card>

            <EditGroupModal isOpen={isEditModalOpen} onClose={() => setEditModalOpen(false)} onSave={(newName) => { if(editingGroup) { updateUserGroup({...editingGroup, name: newName }); setEditModalOpen(false); }}} group={editingGroup} />
        </div>
    );
};

export default GroupPermissions;
