import React, { useState, useMemo, useEffect } from 'react';
// FIX: Auditable type is now correctly exported from types.ts.
import type { MonthlyPayrollRun, Personnel, WorklogEntry, PayrollFactor, AccountHeadGroup, FiscalYear } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface MonthlyPayrollProps {
    personnelList: Personnel[];
    worklogData: WorklogEntry[];
    payrollFactors: PayrollFactor[];
    accountHeads: AccountHeadGroup[];
    fiscalYears: FiscalYear[];
    // FIX: Changed prop type to Omit<..., 'id'> to align with App.tsx.
    addMonthlyPayrollRun: (run: Omit<MonthlyPayrollRun, 'id'>) => void;
}

type TableRow = {
    personnel: Personnel;
    worklog: number;
    [key: string]: any; // For dynamic factor values and calculations
};

const MonthlyPayroll: React.FC<MonthlyPayrollProps> = ({
    personnelList,
    worklogData,
    payrollFactors,
    accountHeads,
    fiscalYears,
    addMonthlyPayrollRun,
}) => {
    const [activeFiscalYearId, setActiveFiscalYearId] = useState<number | null>(null);
    const [activeMonth, setActiveMonth] = useState<number | null>(null);
    const [tableData, setTableData] = useState<TableRow[]>([]);
    const [headerData, setHeaderData] = useState({
        docDate: new Date().toISOString().split('T')[0],
        description: '',
        employerInsuranceSubLedgerId: null as number | null,
        insurancePayableSubLedgerId: null as number | null,
        taxPayableSubLedgerId: null as number | null,
        salaryPayableSubLedgerId: null as number | null,
    });

    const allSubLedgers = useMemo(() => accountHeads.flatMap(g => g.children.flatMap(l => l.children)), [accountHeads]);
    
    // Sort factors by display priority
    const sortedFactors = useMemo(() => [...payrollFactors].sort((a, b) => a.displayPriority - b.displayPriority), [payrollFactors]);

    useEffect(() => {
        if (fiscalYears.length > 0 && !activeFiscalYearId) setActiveFiscalYearId(fiscalYears[0].id);
        if (!activeMonth) setActiveMonth(new Date().getMonth() + 1);
    }, [fiscalYears, activeFiscalYearId, activeMonth]);

    const handleFetchData = () => {
        if (!activeFiscalYearId || !activeMonth) return;
        const activePersonnel = personnelList; // Assuming all are active for now
        const newTableData = activePersonnel.map(p => {
            const worklogEntry = worklogData.find(w => w.personnelId === p.id && w.fiscalYearId === activeFiscalYearId && w.month === activeMonth);
            const row: TableRow = {
                personnel: p,
                worklog: worklogEntry?.workingDays || 0,
            };
            // Initialize factor and calculation fields
            sortedFactors.forEach(factor => {
                row[`factor_input_${factor.id}`] = '';
                row[`factor_worklog_${factor.id}`] = '';
                row[`factor_coeff_${factor.id}`] = '';
                row[`factor_calc_${factor.id}`] = 0;
            });
            row['calc_employerInsurance'] = 0;
            row['calc_employeeInsurance'] = 0;
            row['calc_totalInsurance'] = 0;
            row['calc_tax'] = 0;
            row['calc_netSalary'] = 0;
            return row;
        });
        setTableData(newTableData);
    };
    
    const handleValueChange = (personnelId: number, key: string, value: any) => {
        setTableData(prev => prev.map(row => row.personnel.id === personnelId ? { ...row, [key]: value } : row));
    };
    
    const handleCalculate = () => {
        // Placeholder for complex calculation logic
        alert('محاسبه حقوق انجام شد (شبیه‌سازی).');
    };
    
    const handleSave = () => {
         if (!activeFiscalYearId || !activeMonth) return;
         // In a real app, this would save the `tableData` state.
         alert('محاسبات فعلی ذخیره شد.');
    };
    
    const handleCreateDoc = () => {
        alert('سند حسابداری صادر شد (شبیه‌سازی).');
    };
    
    const renderFactorColumns = (factor: PayrollFactor) => {
        switch (factor.calculationBasis) {
            case 'effective_coefficient':
                return [
                    <th key={`h_worklog_${factor.id}`} className="p-2 border-l border-b dark:border-slate-700">کارکرد {factor.title}</th>,
                    <th key={`h_coeff_${factor.id}`} className="p-2 border-l border-b dark:border-slate-700">ضریب موثر</th>,
                    <th key={`h_calc_${factor.id}`} className="p-2 border-l border-b dark:border-slate-700">محاسبه {factor.title}</th>
                ];
            case 'variable_number':
                 return [<th key={`h_input_${factor.id}`} className="p-2 border-l border-b dark:border-slate-700">{factor.title}</th>];
            default:
                return [<th key={`h_calc_${factor.id}`} className="p-2 border-l border-b dark:border-slate-700">{factor.title}</th>];
        }
    };
    
    const renderFactorCells = (row: TableRow, factor: PayrollFactor) => {
         switch (factor.calculationBasis) {
            case 'effective_coefficient':
                return [
                    <td key={`c_worklog_${factor.id}`} className="p-1 border-l border-b dark:border-slate-700"><FormattedNumberInput value={row[`factor_worklog_${factor.id}`]} onValueChange={v => handleValueChange(row.personnel.id, `factor_worklog_${factor.id}`, v)} className="w-24 bg-transparent p-1 text-center"/></td>,
                    <td key={`c_coeff_${factor.id}`} className="p-1 border-l border-b dark:border-slate-700"><FormattedNumberInput value={row[`factor_coeff_${factor.id}`]} onValueChange={v => handleValueChange(row.personnel.id, `factor_coeff_${factor.id}`, v)} className="w-24 bg-transparent p-1 text-center"/></td>,
                    <td key={`c_calc_${factor.id}`} className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-800">{row[`factor_calc_${factor.id}`].toLocaleString()}</td>
                ];
            case 'variable_number':
                 return [<td key={`c_input_${factor.id}`} className="p-1 border-l border-b dark:border-slate-700"><FormattedNumberInput value={row[`factor_input_${factor.id}`]} onValueChange={v => handleValueChange(row.personnel.id, `factor_input_${factor.id}`, v)} className="w-32 bg-transparent p-1 text-center"/></td>];
            default:
                return [<td key={`c_calc_${factor.id}`} className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-800">{row[`factor_calc_${factor.id}`].toLocaleString()}</td>];
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">محاسبه و صدور سند حقوق ماهانه</h1>
            
            <Card>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 border rounded-lg dark:border-slate-700 items-end">
                    <div>
                        <label className="text-sm font-medium">سال مالی</label>
                        <SearchableSelect options={fiscalYears.map(f=>({value: f.id, label:f.title}))} value={activeFiscalYearId} onChange={v => setActiveFiscalYearId(v as number)} />
                    </div>
                    <div>
                         <label className="text-sm font-medium">برج مورد نظر</label>
                        <SearchableSelect options={Array.from({length: 12}, (_, i) => ({value: i+1, label: `ماه ${i+1}`}))} value={activeMonth} onChange={v => setActiveMonth(v as number)} />
                    </div>
                    <div>
                        <label className="text-sm font-medium">تاریخ سند</label>
                        <input type="date" value={headerData.docDate} onChange={e => setHeaderData(p => ({...p, docDate: e.target.value}))} className="w-full mt-1 p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                    </div>
                     <button onClick={handleFetchData} className="px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 h-10">
                        فراخوانی اطلاعات
                    </button>
                    <div className="col-span-full">
                         <label className="text-sm font-medium">شرح سند</label>
                        <input type="text" placeholder="مثال: حقوق و دستمزد مهر ماه ۱۴۰۳" value={headerData.description} onChange={e => setHeaderData(p => ({...p, description: e.target.value}))} className="w-full mt-1 p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                    </div>
                    <div className="col-span-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t dark:border-slate-600">
                         <SearchableSelect options={allSubLedgers.map(s=>({value: s.id, label: s.title}))} value={headerData.employerInsuranceSubLedgerId} onChange={v => setHeaderData(p=>({...p, employerInsuranceSubLedgerId: v as number}))} placeholder="معین بیمه سهم کارفرما..." />
                         <SearchableSelect options={allSubLedgers.map(s=>({value: s.id, label: s.title}))} value={headerData.insurancePayableSubLedgerId} onChange={v => setHeaderData(p=>({...p, insurancePayableSubLedgerId: v as number}))} placeholder="معین بیمه پرداختنی..." />
                         <SearchableSelect options={allSubLedgers.map(s=>({value: s.id, label: s.title}))} value={headerData.taxPayableSubLedgerId} onChange={v => setHeaderData(p=>({...p, taxPayableSubLedgerId: v as number}))} placeholder="معین مالیات پرداختنی..." />
                         <SearchableSelect options={allSubLedgers.map(s=>({value: s.id, label: s.title}))} value={headerData.salaryPayableSubLedgerId} onChange={v => setHeaderData(p=>({...p, salaryPayableSubLedgerId: v as number}))} placeholder="معین حقوق پرداختنی..." />
                    </div>
                </div>
            </Card>

            <div className="overflow-x-auto shadow-lg rounded-lg">
                 <table className="min-w-full w-max border-collapse text-xs whitespace-nowrap">
                    <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-10 text-slate-600 dark:text-slate-300">
                        <tr>
                            <th className="p-2 border-l border-b dark:border-slate-700 sticky right-0 bg-slate-100 dark:bg-slate-800 z-20">نام</th>
                            <th className="p-2 border-l border-b dark:border-slate-700 sticky right-[80px] bg-slate-100 dark:bg-slate-800 z-20">نام خانوادگی</th>
                            <th className="p-2 border-l border-b dark:border-slate-700">کد ملی</th>
                            <th className="p-2 border-l border-b dark:border-slate-700">کد بیمه</th>
                             <th className="p-2 border-l border-b dark:border-slate-700 bg-sky-50 dark:bg-sky-900/50">کارکرد روزانه</th>
                            {sortedFactors.map(f => renderFactorColumns(f))}
                            <th className="p-2 border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">بیمه سهم کارفرما</th>
                            <th className="p-2 border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">بیمه سهم کارمند</th>
                            <th className="p-2 border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">بیمه پرداختنی</th>
                            <th className="p-2 border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">مالیات پرداختنی</th>
                            <th className="p-2 border-b dark:border-slate-700 sticky left-0 bg-emerald-100 dark:bg-emerald-800 z-20">حقوق پرداختنی</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-slate-900">
                       {tableData.map(row => (
                           <tr key={row.personnel.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                               <td className="p-2 border-l border-b dark:border-slate-700 sticky right-0 bg-inherit z-10">{row.personnel.firstName}</td>
                               <td className="p-2 border-l border-b dark:border-slate-700 sticky right-[80px] bg-inherit z-10">{row.personnel.lastName}</td>
                               <td className="p-2 border-l border-b dark:border-slate-700">{row.personnel.nationalId}</td>
                               <td className="p-2 border-l border-b dark:border-slate-700">{row.personnel.insuranceNumber}</td>
                               <td className="p-1 border-l border-b dark:border-slate-700 bg-sky-50 dark:bg-sky-900/50"><FormattedNumberInput value={row.worklog} onValueChange={v => handleValueChange(row.personnel.id, 'worklog', v)} className="w-24 bg-transparent p-1 text-center"/></td>
                               {sortedFactors.map(f => renderFactorCells(row, f))}
                               <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">{row['calc_employerInsurance'].toLocaleString()}</td>
                               <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">{row['calc_employeeInsurance'].toLocaleString()}</td>
                               <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">{row['calc_totalInsurance'].toLocaleString()}</td>
                               <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700 bg-emerald-50 dark:bg-emerald-900/50">{row['calc_tax'].toLocaleString()}</td>
                               <td className="p-2 font-mono font-bold text-center border-b dark:border-slate-700 sticky left-0 bg-emerald-100 dark:bg-emerald-800 z-10">{row['calc_netSalary'].toLocaleString()}</td>
                           </tr>
                       ))}
                    </tbody>
                 </table>
            </div>
             <Card>
                <div className="flex justify-end items-center space-x-2 rtl:space-x-reverse">
                    <button onClick={handleCalculate} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">محاسبه</button>
                    <button onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره محاسبه</button>
                    <button className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">حذف محاسبه</button>
                    <button onClick={handleCreateDoc} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">صدور سند</button>
                </div>
            </Card>
        </div>
    );
};

export default MonthlyPayroll;
