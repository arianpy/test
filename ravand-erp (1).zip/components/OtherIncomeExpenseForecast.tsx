
import React, { useMemo, useState } from 'react';
import type { OtherForecastRow, AccountHeadGroup, FiscalYear } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

interface OtherIncomeExpenseForecastProps {
    accountHeads: AccountHeadGroup[];
    fiscalYears: FiscalYear[];
    data: OtherForecastRow[];
    setData: React.Dispatch<React.SetStateAction<OtherForecastRow[]>>;
}

const OtherIncomeExpenseForecast: React.FC<OtherIncomeExpenseForecastProps> = ({ accountHeads, fiscalYears, data, setData }) => {

    const allSubLedgers = useMemo(() => accountHeads.flatMap(g => g.children.flatMap(l => l.children)), [accountHeads]);
    const subLedgerMap = useMemo(() => new Map(allSubLedgers.map(sl => [sl.id, sl.title])), [allSubLedgers]);
    
    const [selectedSubLedger, setSelectedSubLedger] = useState<number | null>(null);

    const fiscalYear = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0] : null, [fiscalYears]);
    const mainCurrency = fiscalYear?.mainCurrency || 'IRR';
    
    const handleAddRow = () => {
        if (selectedSubLedger && !data.some(d => d.subLedgerId === selectedSubLedger)) {
            const newRow: OtherForecastRow = {
                id: Date.now(),
                subLedgerId: selectedSubLedger,
                monthlyValues: Array.from({ length: 12 }, (_, i) => ({ month: i + 1, value: 0 })),
            };
            setData(prev => [...prev, newRow]);
            setSelectedSubLedger(null);
        }
    };
    
    const handleRemoveRow = (rowId: number) => {
        setData(prev => prev.filter(row => row.id !== rowId));
    };

    const handleValueChange = (rowId: number, month: number, value: number) => {
        setData(prevData => prevData.map(row => {
            if (row.id === rowId) {
                const newValues = row.monthlyValues.map(mv => 
                    mv.month === month ? { ...mv, value } : mv
                );
                return { ...row, monthlyValues: newValues };
            }
            return row;
        }));
    };
    
    const availableSubLedgers = useMemo(() => {
        const usedIds = new Set(data.map(r => r.subLedgerId));
        return allSubLedgers.filter(sl => !usedIds.has(sl.id));
    }, [allSubLedgers, data]);

    const handleExport = () => {
        const headers = [
            "حساب معین",
            ...Array.from({length: 12}, (_, i) => `ماه ${i+1}`),
            `جمع کل (${mainCurrency})`,
        ];

        const rows = data.map(row => {
            const totalValue = row.monthlyValues.reduce((sum, mv) => sum + (Number(mv.value) || 0), 0);
            const monthlyValues = row.monthlyValues.map(mv => mv.value || 0);
            return [
                subLedgerMap.get(row.subLedgerId) || '',
                ...monthlyValues,
                totalValue
            ];
        });

        exportToCsv("پیشبینی-سایر-درآمدها-هزینه‌ها.csv", [headers, ...rows as (string|number)[][]]);
    };


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">پیش‌بینی سایر درآمدها و هزینه‌ها</h1>
                <button onClick={handleExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">خروجی اکسل</button>
            </div>
             <Card>
                <div className="flex flex-col sm:flex-row items-end sm:space-x-4 sm:rtl:space-x-reverse space-y-4 sm:space-y-0 p-4 border rounded-lg dark:border-slate-700 mb-6">
                     <div className="flex-grow w-full">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">انتخاب سرفصل حساب (معین)</label>
                         <SearchableSelect 
                            options={availableSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}`}))}
                            value={selectedSubLedger}
                            onChange={(val) => setSelectedSubLedger(val as number | null)}
                            placeholder="یک حساب معین برای افزودن انتخاب کنید..."
                         />
                    </div>
                     <button onClick={handleAddRow} disabled={!selectedSubLedger} className="w-full sm:w-auto px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 disabled:bg-slate-400">
                        افزودن ردیف
                    </button>
                </div>
                 <div className="overflow-auto border rounded-lg dark:border-slate-700" style={{ maxHeight: 'calc(100vh - 350px)' }}>
                    <table className="min-w-full w-max border-collapse text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-20 shadow-sm">
                            <tr>
                                <th className="px-3 py-3 text-right font-semibold sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30 whitespace-nowrap">حساب معین</th>
                                {Array.from({ length: 12 }).map((_, i) => <th key={i} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">{i + 1}</th>)}
                                <th className="px-3 py-3 text-center font-semibold border-l border-b dark:border-slate-700 whitespace-nowrap">جمع کل ({mainCurrency})</th>
                                <th className="w-16 border-b dark:border-slate-700">عملیات</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white dark:bg-slate-900">
                             {data.map(row => {
                                const totalValue = row.monthlyValues.reduce((sum, mv) => sum + (Number(mv.value) || 0), 0);
                                return (
                                <tr key={row.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td className="px-3 py-2 font-semibold whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50 border-l border-b dark:border-slate-700 z-10">{subLedgerMap.get(row.subLedgerId)}</td>
                                    {row.monthlyValues.map(mv => (
                                        <td key={mv.month} className="border-l border-b dark:border-slate-700 w-32">
                                            <FormattedNumberInput 
                                                value={mv.value} 
                                                onValueChange={(val) => handleValueChange(row.id, mv.month, val)} 
                                                className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700"
                                            />
                                        </td>
                                    ))}
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-l border-b dark:border-slate-700">{totalValue.toLocaleString('en-US')}</td>
                                    <td className="px-3 py-2 text-center border-b dark:border-slate-700">
                                         <button onClick={() => handleRemoveRow(row.id)} className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-900">&times;</button>
                                    </td>
                                </tr>
                                )
                             })}
                             {data.length === 0 && (
                                <tr><td colSpan={15} className="text-center py-6 text-slate-500 dark:text-slate-400">هیچ ردیفی اضافه نشده است.</td></tr>
                             )}
                         </tbody>
                    </table>
                 </div>
            </Card>
        </div>
    );
};

export default OtherIncomeExpenseForecast;
