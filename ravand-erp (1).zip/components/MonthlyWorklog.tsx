



import React, { useState, useMemo, useEffect } from 'react';
import type { WorklogEntry, Personnel, FiscalYear } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface MonthlyWorklogProps {
    worklog: Record<number, WorklogEntry[]>; // Changed to receive all years data
    saveWorklog: (fiscalYearId: number, month: number, entries: Omit<WorklogEntry, 'id' | 'fiscalYearId' | 'month'>[]) => void;
    personnelList: Personnel[];
    fiscalYears: FiscalYear[];
}

interface TableRowData {
    personnelId: number;
    workingDays: number | '';
    overtimeHours: number | '';
    absenceDays: number | '';
    missionDays: number | '';
}

const MonthlyWorklog: React.FC<MonthlyWorklogProps> = ({ worklog, saveWorklog, personnelList, fiscalYears }) => {
    const [activeFiscalYearId, setActiveFiscalYearId] = useState<number | null>(null);
    const [activeMonth, setActiveMonth] = useState<number | null>(null);
    const [tableData, setTableData] = useState<TableRowData[]>([]);

    useEffect(() => {
        if (fiscalYears.length > 0 && !activeFiscalYearId) {
            setActiveFiscalYearId(fiscalYears[0].id);
        }
        if (!activeMonth) {
            setActiveMonth(new Date().getMonth() + 1); // Default to current month
        }
    }, [fiscalYears, activeFiscalYearId, activeMonth]);

    useEffect(() => {
        const currentYearWorklog = (activeFiscalYearId && worklog[activeFiscalYearId]) || [];
        // Populate table when personnel list or period changes
        const initialData = personnelList.map((p): TableRowData => {
            const existingEntry = currentYearWorklog.find(w => w.personnelId === p.id && w.month === activeMonth);
            return {
                personnelId: p.id,
                workingDays: existingEntry?.workingDays ?? '',
                overtimeHours: existingEntry?.overtimeHours ?? '',
                absenceDays: existingEntry?.absenceDays ?? '',
                missionDays: existingEntry?.missionDays ?? '',
            };
        });
        setTableData(initialData);
    }, [personnelList, activeFiscalYearId, activeMonth, worklog]);


    const handleDataChange = (personnelId: number, field: keyof Omit<TableRowData, 'personnelId'>, value: number) => {
        setTableData(prev => prev.map(row => 
            row.personnelId === personnelId ? { ...row, [field]: value } : row
        ));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!activeFiscalYearId || !activeMonth) {
            alert('لطفا سال مالی و ماه را انتخاب کنید.');
            return;
        }

        const entriesToSave = tableData.map(row => ({
            personnelId: row.personnelId,
            workingDays: Number(row.workingDays) || 0,
            overtimeHours: Number(row.overtimeHours) || 0,
            absenceDays: Number(row.absenceDays) || 0,
            missionDays: Number(row.missionDays) || 0,
        }));

        saveWorklog(activeFiscalYearId, activeMonth, entriesToSave);
        alert(`کارکرد ماه ${activeMonth} با موفقیت ذخیره شد.`);
    };

    const monthOptions = useMemo(() => Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: `ماه ${i + 1}` })), []);
    const fiscalYearOptions = useMemo(() => fiscalYears.map(fy => ({ value: fy.id, label: fy.title })), [fiscalYears]);
    const personnelMap = useMemo(() => new Map(personnelList.map(p => [p.id, `${p.firstName} ${p.lastName}`])), [personnelList]);

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت کارکرد ماهیانه پرسنل</h1>
            <Card>
                <form onSubmit={handleSubmit}>
                    <div className="p-4 border dark:border-slate-700 rounded-lg mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">سال مالی</label>
                            <SearchableSelect options={fiscalYearOptions} value={activeFiscalYearId} onChange={val => setActiveFiscalYearId(val as number)} />
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">ماه</label>
                            <SearchableSelect options={monthOptions} value={activeMonth} onChange={val => setActiveMonth(val as number)} />
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                            <thead className="bg-slate-50 dark:bg-slate-700">
                                <tr>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">نام پرسنل</th>
                                    <th className="px-4 py-3 text-center text-xs font-medium uppercase">روزهای کارکرد</th>
                                    <th className="px-4 py-3 text-center text-xs font-medium uppercase">ساعات اضافه‌کاری</th>
                                    <th className="px-4 py-3 text-center text-xs font-medium uppercase">روزهای غیبت</th>
                                    <th className="px-4 py-3 text-center text-xs font-medium uppercase">روزهای ماموریت</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                {tableData.map(row => (
                                    <tr key={row.personnelId}>
                                        <td className="px-4 py-2 whitespace-nowrap font-medium">{personnelMap.get(row.personnelId)}</td>
                                        <td className="p-1"><FormattedNumberInput value={row.workingDays} onValueChange={val => handleDataChange(row.personnelId, 'workingDays', val)} className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                        <td className="p-1"><FormattedNumberInput value={row.overtimeHours} onValueChange={val => handleDataChange(row.personnelId, 'overtimeHours', val)} className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                        <td className="p-1"><FormattedNumberInput value={row.absenceDays} onValueChange={val => handleDataChange(row.personnelId, 'absenceDays', val)} className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                        <td className="p-1"><FormattedNumberInput value={row.missionDays} onValueChange={val => handleDataChange(row.personnelId, 'missionDays', val)} className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                     <div className="flex justify-end pt-5 mt-6 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            ذخیره کارکرد
                        </button>
                    </div>
                </form>
            </Card>
        </div>
    );
};

export default MonthlyWorklog;