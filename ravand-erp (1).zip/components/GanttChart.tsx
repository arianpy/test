
import React, { useMemo } from 'react';
import { sidebarStructure, SubViewSimple, SubViewEntry, GroupItem, ModuleItem } from '../data/sidebarStructure';
import type { SubView } from '../App';

type FormFieldMap = Partial<Record<SubView, string[]>>;
type FormTypeMap = Partial<Record<SubView, 'Data Entry' | 'Data Analysis'>>;


// Task generation logic
const getFeatures = (): SubViewSimple[] => {
    const features: SubViewSimple[] = [];
    const traverse = (items: (GroupItem | ModuleItem | SubViewEntry)[]) => {
        items.forEach(item => {
            if ('type' in item) {
                if (item.type === 'group') {
                    traverse(item.modules);
                } else if (item.type === 'module' || item.type === 'subgroup') {
                    traverse(item.subViews);
                }
            } else { // It's a SubViewSimple
                if (item.id !== 'operations' && item.id !== 'reports' && item.id !== 'definitions' && item.id !== 'personalSettings') {
                   features.push(item as SubViewSimple);
                }
            }
        });
    };
    traverse(sidebarStructure);
    // Remove duplicates that might arise from shared subviews
    const uniqueFeatures = Array.from(new Map(features.map(f => [f.id, f])).values());
    return uniqueFeatures;
};

interface GanttTask {
    id: string;
    name: string;
    start: number; // in hours
    duration: number; // in hours
    team: 'Frontend' | 'Backend';
    fieldCount: number;
    subViewId: SubView;
}

export const generateGanttData = ({ formFields, formTypes }: {
    formFields: FormFieldMap;
    formTypes: FormTypeMap;
}): { tasks: GanttTask[], totalHours: number } => {
    const features = getFeatures();
    const tasks: GanttTask[] = [];

    let frontendCurrentHour = 0;
    let backendCurrentHour = 0;

    features.forEach(feature => {
        const fields = formFields[feature.id as SubView] || [];
        const fieldCount = fields.length;

        if (fieldCount > 0) {
            const formType = formTypes[feature.id as SubView];
            
            if (formType === 'Data Entry') {
                const feDuration = fieldCount * 0.08;
                if (feDuration > 0) {
                    tasks.push({
                        id: `fe-${feature.id}`,
                        name: feature.label,
                        start: frontendCurrentHour,
                        duration: feDuration,
                        team: 'Frontend',
                        fieldCount: fieldCount,
                        subViewId: feature.id
                    });
                    frontendCurrentHour += feDuration;
                }
            }
            
            const beDuration = fieldCount * 0.2;
             if (beDuration > 0) {
                tasks.push({
                    id: `be-${feature.id}`,
                    name: feature.label,
                    start: backendCurrentHour,
                    duration: beDuration,
                    team: 'Backend',
                    fieldCount: fieldCount,
                    subViewId: feature.id
                });
                backendCurrentHour += beDuration;
            }
        }
    });

    const totalFeHours = frontendCurrentHour;
    const totalBeHours = backendCurrentHour;

    const TARGET_PROJECT_DAYS = 165;
    const TARGET_PROJECT_HOURS = TARGET_PROJECT_DAYS * 8;

    const feScalingFactor = totalFeHours > 0 ? TARGET_PROJECT_HOURS / totalFeHours : 0;
    const beScalingFactor = totalBeHours > 0 ? TARGET_PROJECT_HOURS / totalBeHours : 0;
    
    const scaledTasks = tasks.map(task => {
        if (task.team === 'Frontend') {
            return {
                ...task,
                start: task.start * feScalingFactor,
                duration: task.duration * feScalingFactor,
            };
        } else { // Backend
            return {
                ...task,
                start: task.start * beScalingFactor,
                duration: task.duration * beScalingFactor,
            };
        }
    });

    return { tasks: scaledTasks, totalHours: TARGET_PROJECT_HOURS };
};

const GanttChart: React.FC<{ formFields: FormFieldMap, formTypes: FormTypeMap }> = ({ formFields, formTypes }) => {
    const { tasks, totalHours } = useMemo(() => generateGanttData({ formFields, formTypes }), [formFields, formTypes]);
    
    if (totalHours === 0) {
        return <div className="p-4 text-center">داده‌ای برای نمایش گانت چارت وجود ندارد.</div>;
    }

    const frontendTasks = tasks.filter(t => t.team === 'Frontend');
    const backendTasks = tasks.filter(t => t.team === 'Backend');

    const renderTaskBar = (task: GanttTask) => {
        const left = (task.start / totalHours) * 100;
        const width = (task.duration / totalHours) * 100;
        const bgColor = task.team === 'Frontend' ? 'bg-sky-500' : 'bg-indigo-500';

        return (
            <div
                key={task.id}
                className={`absolute h-6 ${bgColor} rounded-md flex items-center justify-center text-white text-xs whitespace-nowrap overflow-hidden group border border-white/20`}
                style={{ left: `${left}%`, width: `${width}%`, top: '50%', transform: 'translateY(-50%)' }}
                title={`${task.name} (${task.duration.toFixed(1)} ساعت)`}
            >
                <span className="px-2 truncate group-hover:hidden">{task.name}</span>
                 <span className="px-2 truncate hidden group-hover:block">{`${task.name} (${task.duration.toFixed(1)} ساعت)`}</span>
            </div>
        );
    };

    const totalDays = Math.ceil(totalHours / 8);
    const dayMarkers = Array.from({ length: totalDays }, (_, i) => i);

    return (
        <div className="w-full overflow-x-auto p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200 mb-4">گانت چارت عملیاتی کدنویسی پروژه ({totalDays} روز کاری)</h3>
            <div className="relative" style={{ minWidth: `${totalDays * 50}px` }}>
                {/* Timeline Header */}
                <div className="relative h-12 flex border-b-2 dark:border-slate-700">
                    {dayMarkers.map(day => (
                        <div key={`marker-${day}`} className="absolute top-0 h-full text-xs text-slate-400" style={{ left: `${(day * 8 / totalHours) * 100}%` }}>
                            <span className="absolute top-0 -translate-x-1/2">روز {day + 1}</span>
                            <div className="h-full w-px bg-slate-200 dark:bg-slate-700 mt-5"></div>
                        </div>
                    ))}
                </div>
                
                {/* Chart Rows */}
                <div className="relative">
                    {/* Frontend Row */}
                    <div className="flex items-center h-20 border-b dark:border-slate-700">
                        <div className="w-32 text-center font-semibold text-sky-600 dark:text-sky-400">فرانت اند</div>
                        <div className="flex-1 h-full relative bg-slate-100 dark:bg-slate-800 rounded-md">
                            {frontendTasks.map(renderTaskBar)}
                        </div>
                    </div>
                    {/* Backend Row */}
                    <div className="flex items-center h-20">
                        <div className="w-32 text-center font-semibold text-indigo-600 dark:text-indigo-400">بک اند</div>
                        <div className="flex-1 h-full relative bg-slate-100 dark:bg-slate-800 rounded-md">
                            {backendTasks.map(renderTaskBar)}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GanttChart;
