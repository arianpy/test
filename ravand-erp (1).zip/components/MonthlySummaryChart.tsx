import React from 'react';
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar } from 'recharts';
import Card from './ui/Card';

interface MonthlySummaryChartProps {
    data: { name: string; main: number; secondary: number }[];
    title: string;
    mainCurrency: string;
    secondaryCurrency: string;
}

const MonthlySummaryChart: React.FC<MonthlySummaryChartProps> = ({ data, title, mainCurrency, secondaryCurrency }) => {
    return (
        <Card>
            <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-slate-200">{title}</h3>
            <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128, 128, 128, 0.2)" />
                        <XAxis dataKey="name" tick={{ fill: '#64748b' }} />
                        <YAxis tickFormatter={(value) => new Intl.NumberFormat('en-US').format(value as number)} tick={{ fill: '#64748b' }} />
                        <Tooltip
                            contentStyle={{
                                backgroundColor: 'rgba(30, 41, 59, 0.8)',
                                borderColor: '#475569',
                                borderRadius: '0.5rem',
                                direction: 'rtl',
                                fontFamily: 'Vazirmatn'
                            }}
                            labelStyle={{ color: '#f9fafb' }}
                            formatter={(value) => `${new Intl.NumberFormat('en-US').format(value as number)}`}
                        />
                        <Legend wrapperStyle={{direction: 'rtl'}} />
                        <Bar dataKey="main" name={`مبلغ (${mainCurrency})`} fill="#3399FF" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="secondary" name={`مبلغ (${secondaryCurrency})`} fill="#99CCFF" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </Card>
    );
};

export default MonthlySummaryChart;
