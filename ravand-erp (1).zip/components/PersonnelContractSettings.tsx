import React, { useState, useMemo } from 'react';
import type { Personnel, Contract, PayrollFactor } from '../types';
import Card from './ui/Card';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import FormattedNumberInput from './ui/FormattedNumberInput';
import { toShamsi } from '../utils/date';
import SearchableSelect from './ui/SearchableSelect';

// Reusable file input component
const FileInput: React.FC<{ label: string; onFileSelect: (file: File | null) => void; }> = ({ label, onFileSelect }) => (
    <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input type="file" onChange={e => onFileSelect(e.target.files?.[0] || null)} className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-50 file:text-cyan-700 hover:file:bg-cyan-100 dark:file:bg-cyan-700 dark:file:text-cyan-200 dark:hover:file:bg-cyan-600" />
    </div>
);

// Main Component
interface PersonnelContractSettingsProps {
    personnel: Personnel[];
    addContract: (personnelId: number, contract: Omit<Contract, 'id' | 'personnelId'>) => void;
    updatePersonnel: (personnel: Personnel) => void; // For future use (editing contracts)
    payrollFactors: PayrollFactor[];
}

const PersonnelContractSettings: React.FC<PersonnelContractSettingsProps> = ({ personnel, addContract, payrollFactors }) => {
    const getInitialState = () => ({
        personnelId: null as number | null,
        regulationDate: new Date().toISOString().split('T')[0],
        startDate: '',
        endDate: '',
        status: 'active' as 'active' | 'inactive',
        hourlyWage: '' as number | '',
        payrollFactorIds: [] as number[],
    });

    const [formData, setFormData] = useState(getInitialState());
    const [contractFile, setContractFile] = useState<File | null>(null);

    const personnelOptions = useMemo(() => personnel.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName} (${p.employeeCode})` })), [personnel]);
    const payrollFactorOptions = useMemo(() => payrollFactors.map(f => ({ value: f.id, label: f.title })), [payrollFactors]);

    const handleFactorToggle = (factorId: number) => {
        setFormData(prev => {
            const newFactorIds = prev.payrollFactorIds.includes(factorId)
                ? prev.payrollFactorIds.filter(id => id !== factorId)
                : [...prev.payrollFactorIds, factorId];
            return { ...prev, payrollFactorIds: newFactorIds };
        });
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.personnelId || !formData.startDate || !formData.endDate || formData.hourlyWage === '') {
            alert('لطفا تمامی فیلدهای الزامی را پر کنید.');
            return;
        }
        
        const newContract: Omit<Contract, 'id' | 'personnelId'> = {
            regulationDate: formData.regulationDate,
            startDate: formData.startDate,
            endDate: formData.endDate,
            status: formData.status,
            hourlyWage: Number(formData.hourlyWage),
            payrollFactorIds: formData.payrollFactorIds,
            contractImageUrl: contractFile ? URL.createObjectURL(contractFile) : undefined,
        };
        addContract(formData.personnelId, newContract);
        alert('قرارداد جدید با موفقیت ثبت شد.');
        setFormData(getInitialState());
        setContractFile(null);
    };

    const allContracts = useMemo(() => {
        return personnel.flatMap(p => p.contracts.map(c => ({ ...c, personnelName: `${p.firstName} ${p.lastName}` })));
    }, [personnel]);
    
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیم قرارداد پرسنلی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">
                        ایجاد قرارداد جدید
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                         <div>
                            <label className="block text-sm font-medium mb-1">انتخاب پرسنل *</label>
                            <SearchableSelect options={personnelOptions} value={formData.personnelId} onChange={val => setFormData(p => ({ ...p, personnelId: val as number | null }))} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">تاریخ تنظیم قرارداد *</label>
                            <ShamsiDatePicker value={formData.regulationDate} onChange={date => setFormData(p => ({ ...p, regulationDate: date }))} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">تاریخ شروع قرارداد *</label>
                            <ShamsiDatePicker value={formData.startDate} onChange={date => setFormData(p => ({ ...p, startDate: date }))} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">تاریخ اتمام قرارداد *</label>
                            <ShamsiDatePicker value={formData.endDate} onChange={date => setFormData(p => ({ ...p, endDate: date }))} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">دستمزد ساعتی *</label>
                            <FormattedNumberInput value={formData.hourlyWage} onValueChange={val => setFormData(p => ({ ...p, hourlyWage: val }))} required className="w-full mt-1 block px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">وضعیت</label>
                            <select value={formData.status} onChange={e => setFormData(p => ({ ...p, status: e.target.value as any }))} className="w-full mt-1 block px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md">
                                <option value="active">فعال</option>
                                <option value="inactive">غیرفعال</option>
                            </select>
                        </div>
                         <div className="lg:col-span-3">
                            <label className="block text-sm font-medium mb-1">عوامل حقوق و دستمزد</label>
                            <div className="p-2 border rounded-md bg-white dark:bg-slate-700 h-32 overflow-y-auto">
                                {payrollFactorOptions.length > 0 ? (
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                        {payrollFactorOptions.map(opt => (
                                            <div key={opt.value} className="flex items-center">
                                                <input
                                                    type="checkbox"
                                                    id={`factor-psc-${opt.value}`}
                                                    checked={formData.payrollFactorIds.includes(opt.value)}
                                                    onChange={() => handleFactorToggle(opt.value)}
                                                    className="h-4 w-4 rounded text-cyan-600 border-slate-300 focus:ring-cyan-500"
                                                />
                                                <label htmlFor={`factor-psc-${opt.value}`} className="mr-2 text-sm">{opt.label}</label>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="flex items-center justify-center h-full text-slate-500 text-sm">
                                        هیچ عاملی تعریف نشده است.
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="lg:col-span-3">
                            <FileInput label="تصویر قرارداد" onFileSelect={setContractFile} />
                        </div>
                    </div>
                     <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره قرارداد</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فهرست قراردادها</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">پرسنل</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">تاریخ شروع</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">تاریخ اتمام</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">دستمزد ساعتی</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">وضعیت</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">تعداد عوامل</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {allContracts.length > 0 ? (
                            allContracts.sort((a,b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime()).map((contract) => (
                                <tr key={contract.id}>
                                    <td className="px-6 py-4 whitespace-nowrap font-medium">{contract.personnelName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{toShamsi(contract.startDate)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{toShamsi(contract.endDate)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap font-mono">{contract.hourlyWage.toLocaleString()}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-center">
                                         <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${contract.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {contract.status === 'active' ? 'فعال' : 'غیرفعال'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-center font-mono">{contract.payrollFactorIds.length}</td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500">
                                    هیچ قراردادی ثبت نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default PersonnelContractSettings;