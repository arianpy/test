
import React, { useState } from 'react';
import Modal from './ui/Modal';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  setForgotPasswordModalOpen: (isOpen: boolean) => void;
}

const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ isOpen, onClose, setForgotPasswordModalOpen }) => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (newPassword !== confirmPassword) {
            setError('رمز عبور جدید و تکرار آن مطابقت ندارند.');
            return;
        }
        if (newPassword.length < 6) {
             setError('رمز عبور جدید باید حداقل ۶ کاراکتر باشد.');
            return;
        }
        // In a real app, you would make an API call here.
        console.log({
            currentPassword,
            newPassword,
        });
        alert('رمز عبور با موفقیت تغییر کرد.');
        onClose();
    };

    const handleClose = () => {
        // Reset state on close
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setError('');
        onClose();
    };

    const handleForgotPasswordClick = () => {
        handleClose(); // Close this modal
        setForgotPasswordModalOpen(true); // Open the forgot password modal
    };


  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="تغییر رمز عبور">
        <form onSubmit={handleSave} className="space-y-4">
            {error && <div className="p-3 bg-red-100 text-red-700 rounded-md text-sm">{error}</div>}
             <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">رمز عبور فعلی</label>
                <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                required
                />
                <div className="text-left mt-2">
                    <button 
                        type="button" 
                        onClick={handleForgotPasswordClick} 
                        className="text-sm text-custom-blue-primary hover:underline focus:outline-none"
                    >
                        رمز عبور خود را فراموش کرده‌اید؟
                    </button>
                </div>
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">رمز عبور جدید</label>
                <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                required
                />
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">تکرار رمز عبور جدید</label>
                <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                required
                />
            </div>

            <div className="w-full flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                <button type="button" onClick={handleClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                لغو
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                ذخیره تغییرات
                </button>
            </div>
        </form>
    </Modal>
  );
};

export default ChangePasswordModal;
