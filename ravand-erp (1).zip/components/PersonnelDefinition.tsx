import React, { useState, useEffect, useMemo } from 'react';
import type { Personnel, Contract, PayrollFactor } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';

// Contract Modal Component
const AddContractModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    personnel: Personnel | null;
    addContract: (personnelId: number, contract: Omit<Contract, 'id' | 'personnelId'>) => void;
    payrollFactors: PayrollFactor[];
}> = ({ isOpen, onClose, personnel, addContract, payrollFactors }) => {
    
    const initialState = {
        regulationDate: new Date().toISOString().split('T')[0],
        startDate: '',
        endDate: '',
        status: 'active' as 'active' | 'inactive',
        hourlyWage: '' as number | '',
        payrollFactorIds: [] as number[],
    };

    const [formData, setFormData] = useState(initialState);
    const [contractFile, setContractFile] = useState<File | null>(null);
    const contractFilePreview = contractFile ? URL.createObjectURL(contractFile) : null;

    useEffect(() => {
        if (isOpen) {
            setFormData(initialState);
            setContractFile(null);
        }
    }, [isOpen, personnel]);
    
    useEffect(() => {
        return () => {
            if (contractFilePreview) URL.revokeObjectURL(contractFilePreview);
        };
    }, [contractFilePreview]);

    const payrollFactorOptions = useMemo(() => payrollFactors.map(f => ({ value: f.id, label: f.title })), [payrollFactors]);

    const handleFactorToggle = (factorId: number) => {
        setFormData(prev => {
            const newFactorIds = prev.payrollFactorIds.includes(factorId)
                ? prev.payrollFactorIds.filter(id => id !== factorId)
                : [...prev.payrollFactorIds, factorId];
            return { ...prev, payrollFactorIds: newFactorIds };
        });
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!personnel || !formData.startDate || !formData.endDate || !formData.hourlyWage) return;
        
        const newContract: Omit<Contract, 'id' | 'personnelId'> = {
            ...formData,
            hourlyWage: Number(formData.hourlyWage),
            contractImageUrl: contractFilePreview || undefined,
        };
        addContract(personnel.id, newContract);
        alert(`قرارداد جدید برای ${personnel.firstName} ${personnel.lastName} ذخیره شد.`);
        onClose();
    };

    if (!personnel) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`افزودن قرارداد برای ${personnel.firstName} ${personnel.lastName}`} size="3xl">
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium mb-1">تاریخ تنظیم قرارداد *</label>
                        <ShamsiDatePicker value={formData.regulationDate} onChange={date => setFormData(p => ({ ...p, regulationDate: date }))} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">تاریخ شروع قرارداد *</label>
                        <ShamsiDatePicker value={formData.startDate} onChange={date => setFormData(p => ({ ...p, startDate: date }))} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">تاریخ اتمام قرارداد *</label>
                        <ShamsiDatePicker value={formData.endDate} onChange={date => setFormData(p => ({ ...p, endDate: date }))} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">دستمزد ساعتی *</label>
                        <FormattedNumberInput value={formData.hourlyWage} onValueChange={val => setFormData(p => ({ ...p, hourlyWage: val }))} required className="w-full mt-1 block px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">وضعیت</label>
                        <select value={formData.status} onChange={e => setFormData(p => ({ ...p, status: e.target.value as any }))} className="w-full mt-1 block px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md">
                            <option value="active">فعال</option>
                            <option value="inactive">غیرفعال</option>
                        </select>
                    </div>
                </div>
                 <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">عوامل حقوق و دستمزد</label>
                    <div className="p-2 border rounded-md bg-white dark:bg-slate-700 h-32 overflow-y-auto">
                        {payrollFactorOptions.length > 0 ? (
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                {payrollFactorOptions.map(opt => (
                                    <div key={opt.value} className="flex items-center">
                                        <input
                                            type="checkbox"
                                            id={`factor-pd-${opt.value}`}
                                            checked={formData.payrollFactorIds.includes(opt.value)}
                                            onChange={() => handleFactorToggle(opt.value)}
                                            className="h-4 w-4 rounded text-cyan-600 border-slate-300 focus:ring-cyan-500"
                                        />
                                        <label htmlFor={`factor-pd-${opt.value}`} className="mr-2 text-sm">{opt.label}</label>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex items-center justify-center h-full text-slate-500 text-sm">
                                هیچ عاملی تعریف نشده است.
                            </div>
                        )}
                    </div>
                </div>
                 <div>
                    <FileInput id="contract-upload" label="تصویر قرارداد" onFileSelect={setContractFile} previewUrl={contractFilePreview} />
                </div>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                        لغو
                    </button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                        ذخیره قرارداد
                    </button>
                </div>
            </form>
        </Modal>
    );
};


// FIX: Add updatePersonnel and deletePersonnel props to handle editing and removing personnel.
interface PersonnelDefinitionProps {
    personnel: Personnel[];
    addPersonnel: (person: Omit<Personnel, 'id' | 'contracts'>) => void;
    updatePersonnel: (personnel: Personnel) => void;
    deletePersonnel: (personnelId: number) => void;
    addContract: (personnelId: number, contract: Omit<Contract, 'id' | 'personnelId'>) => void;
    payrollFactors: PayrollFactor[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }> = ({ label, id, children, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <select id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500">
            {children}
        </select>
    </div>
);

const FileInput: React.FC<{
    id: string;
    label: string;
    onFileSelect: (file: File | null) => void;
    previewUrl: string | null;
}> = ({ id, label, onFileSelect, previewUrl }) => {
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onFileSelect(e.target.files && e.target.files[0] ? e.target.files[0] : null);
    };
    return (
         <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
            <div className="mt-2 flex items-center space-x-4 rtl:space-x-reverse">
                <div className="flex-shrink-0 h-24 w-24 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                    {previewUrl ? (
                        <img src={previewUrl} alt="پیش‌نمایش" className="h-full w-full object-cover" />
                    ) : (
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-slate-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                        </svg>
                    )}
                </div>
                <label htmlFor={id} className="cursor-pointer bg-white dark:bg-slate-700 py-2 px-3 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600">
                    <span>انتخاب فایل</span>
                    <input id={id} name={id} type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg" />
                </label>
            </div>
        </div>
    );
};


const PersonnelDefinition: React.FC<PersonnelDefinitionProps> = ({ personnel, addPersonnel, updatePersonnel, deletePersonnel, addContract, payrollFactors }) => {
    const initialState = {
        employeeCode: '', gender: 'male' as 'male' | 'female', firstName: '', lastName: '',
        fatherName: '', birthDate: '', educationLevel: '', fieldOfStudy: '',
        contractualJobTitle: '', position: '', birthCertNumber: '', nationalId: '',
        insuranceNumber: '', accountNumber: '', iban: '', cardNumber: '', address: '',
        phone: '', mobile: '', employmentDate: '', serviceEndDate: '', email: '',
        description: '', openingBalance: '', workLocation: '', costCenterCode: '',
        costCenterTitle: '',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [photoFile, setPhotoFile] = useState<File | null>(null);
    const photoPreview = photoFile ? URL.createObjectURL(photoFile) : null;

    const [isContractModalOpen, setContractModalOpen] = useState(false);
    const [selectedPersonnel, setSelectedPersonnel] = useState<Personnel | null>(null);

    useEffect(() => {
        return () => {
            if (photoPreview) URL.revokeObjectURL(photoPreview);
        };
    }, [photoPreview]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleOpenContractModal = (person: Personnel) => {
        setSelectedPersonnel(person);
        setContractModalOpen(true);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newPersonnel: Omit<Personnel, 'id' | 'contracts'> = {
            ...formData,
            openingBalance: Number(formData.openingBalance) || 0,
            photoUrl: photoPreview || undefined,
        };
        addPersonnel(newPersonnel);
        setFormData(initialState);
        setPhotoFile(null);
        alert('پرسنل جدید با موفقیت ذخیره شد.');
    };
    
    const handleDelete = (personnelId: number) => {
        if(window.confirm('آیا از حذف این پرسنل اطمینان دارید؟')) {
            deletePersonnel(personnelId);
        }
    }

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف پرسنل سازمانی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8 divide-y divide-slate-200 dark:divide-slate-700">
                    {/* Personal Info */}
                    <div className="space-y-6 pt-2">
                        <div>
                            <h3 className="text-lg font-medium text-slate-900 dark:text-white">اطلاعات شناسایی</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">اطلاعات فردی و شناسایی پرسنل را وارد کنید.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <FormInput label="کد کارمند" id="employeeCode" name="employeeCode" value={formData.employeeCode} onChange={handleChange} required />
                            <FormInput label="نام" id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} required />
                            <FormInput label="نام خانوادگی" id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} required />
                            <FormInput label="نام پدر" id="fatherName" name="fatherName" value={formData.fatherName} onChange={handleChange} />
                            <FormInput label="کد ملی" id="nationalId" name="nationalId" value={formData.nationalId} onChange={handleChange} />
                            <FormInput label="شماره شناسنامه" id="birthCertNumber" name="birthCertNumber" value={formData.birthCertNumber} onChange={handleChange} />
                            <FormInput label="تاریخ تولد" id="birthDate" name="birthDate" type="date" value={formData.birthDate} onChange={handleChange} />
                            <div>
                               <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">جنسیت</label>
                                <div className="mt-2 flex items-center space-x-4 rtl:space-x-reverse">
                                     <label className="flex items-center">
                                        <input type="radio" name="gender" value="male" checked={formData.gender === 'male'} onChange={handleChange} className="form-radio text-cyan-600 focus:ring-cyan-500"/>
                                        <span className="mr-2">مرد</span>
                                    </label>
                                     <label className="flex items-center">
                                        <input type="radio" name="gender" value="female" checked={formData.gender === 'female'} onChange={handleChange} className="form-radio text-cyan-600 focus:ring-cyan-500"/>
                                        <span className="mr-2">زن</span>
                                    </label>
                                </div>
                            </div>
                            <div className="lg:col-span-4">
                               <FileInput id="photo-upload" label="تصویر پرسنل" onFileSelect={setPhotoFile} previewUrl={photoPreview} />
                            </div>
                        </div>
                    </div>

                    {/* Job Info */}
                    <div className="space-y-6 pt-8">
                         <div>
                            <h3 className="text-lg font-medium text-slate-900 dark:text-white">اطلاعات شغلی و تحصیلی</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                           <FormInput label="مدرک تحصیلی" id="educationLevel" name="educationLevel" value={formData.educationLevel} onChange={handleChange} />
                           <FormInput label="رشته تحصیلی" id="fieldOfStudy" name="fieldOfStudy" value={formData.fieldOfStudy} onChange={handleChange} />
                           <FormInput label="عنوان قراردادی شغل" id="contractualJobTitle" name="contractualJobTitle" value={formData.contractualJobTitle} onChange={handleChange} />
                           <FormInput label="سمت" id="position" name="position" value={formData.position} onChange={handleChange} />
                           <FormInput label="تاریخ استخدام" id="employmentDate" name="employmentDate" type="date" value={formData.employmentDate} onChange={handleChange} />
                           <FormInput label="تاریخ پایان خدمت" id="serviceEndDate" name="serviceEndDate" type="date" value={formData.serviceEndDate} onChange={handleChange} />
                        </div>
                    </div>

                    {/* Financial Info */}
                    <div className="space-y-6 pt-8">
                         <div>
                            <h3 className="text-lg font-medium text-slate-900 dark:text-white">اطلاعات مالی و بیمه</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                           <FormInput label="شماره بیمه" id="insuranceNumber" name="insuranceNumber" value={formData.insuranceNumber} onChange={handleChange} />
                           <FormInput label="شماره حساب" id="accountNumber" name="accountNumber" value={formData.accountNumber} onChange={handleChange} />
                           <FormInput label="شماره شبا" id="iban" name="iban" value={formData.iban} onChange={handleChange} />
                           <FormInput label="شماره کارت" id="cardNumber" name="cardNumber" value={formData.cardNumber} onChange={handleChange} />
                        </div>
                    </div>
                    
                    {/* Other Info */}
                     <div className="space-y-6 pt-8">
                         <div>
                            <h3 className="text-lg font-medium text-slate-900 dark:text-white">اطلاعات سازمانی و تماس</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <FormInput label="عنوان محل خدمت" id="workLocation" name="workLocation" value={formData.workLocation} onChange={handleChange} />
                            <FormInput label="کد محل هزینه" id="costCenterCode" name="costCenterCode" value={formData.costCenterCode} onChange={handleChange} />
                            <FormInput label="عنوان مرکز هزینه" id="costCenterTitle" name="costCenterTitle" value={formData.costCenterTitle} onChange={handleChange} />
                            <FormInput label="شماره تلفن" id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} />
                            <FormInput label="شماره همراه" id="mobile" name="mobile" type="tel" value={formData.mobile} onChange={handleChange} />
                            <FormInput label="ایمیل" id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
                            <div className="md:col-span-2 lg:col-span-3">
                                 <label htmlFor="address" className="block text-sm font-medium">آدرس</label>
                                 <textarea id="address" name="address" value={formData.address} onChange={handleChange} rows={2} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"></textarea>
                            </div>
                            <FormInput label="مانده افتتاحیه استقرار" id="openingBalance" name="openingBalance" type="number" value={formData.openingBalance} onChange={handleChange} />
                            <div className="md:col-span-2 lg:col-span-2">
                                <label htmlFor="description" className="block text-sm font-medium">توضیحات</label>
                                <textarea id="description" name="description" value={formData.description} onChange={handleChange} rows={2} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"></textarea>
                            </div>
                        </div>
                    </div>


                    <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            ذخیره پرسنل
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فهرست پرسنل</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">کد</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">نام و نام خانوادگی</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">سمت</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">شماره همراه</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">قراردادها</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {personnel.length > 0 ? (
                            personnel.map((p) => (
                                <tr key={p.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{p.employeeCode}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{`${p.firstName} ${p.lastName}`}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{p.position}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{p.mobile}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center">{p.contracts.length}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2 rtl:space-x-reverse">
                                        <button className="text-amber-600 hover:text-amber-800 text-xs py-1 px-2 rounded bg-amber-100 dark:bg-amber-900 dark:text-amber-300 dark:hover:bg-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800 text-xs py-1 px-2 rounded bg-red-100 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800">حذف</button>
                                        <button onClick={() => handleOpenContractModal(p)} className="text-cyan-600 hover:text-cyan-800 text-xs py-1 px-2 rounded bg-cyan-100 dark:bg-cyan-900 dark:text-cyan-300 dark:hover:bg-cyan-800">افزودن قرارداد</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500">
                                    هنوز پرسنلی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <AddContractModal
                isOpen={isContractModalOpen}
                onClose={() => setContractModalOpen(false)}
                personnel={selectedPersonnel}
                addContract={addContract}
                payrollFactors={payrollFactors}
            />
        </div>
    );
};

export default PersonnelDefinition;