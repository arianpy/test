

import React, { useMemo, useEffect } from 'react';
import type { PurchaseForecastRow, PurchaseItem, FiscalYear } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

interface DirectMaterialPurchaseForecastProps {
    purchaseItems: PurchaseItem[];
    fiscalYears: FiscalYear[];
    data: PurchaseForecastRow[];
    setData: React.Dispatch<React.SetStateAction<PurchaseForecastRow[]>>;
    // FIX: Added missing property
    predictedInflationRate: number;
}

const DirectMaterialPurchaseForecast: React.FC<DirectMaterialPurchaseForecastProps> = ({ purchaseItems, fiscalYears, data, setData, predictedInflationRate }) => {

    useEffect(() => {
        if (data.length === 0 && purchaseItems.length > 0) {
            const initialData: PurchaseForecastRow[] = purchaseItems.map(item => ({
                purchaseItemId: item.id,
                inflationRate: '',
                monthlyQuantities: Array.from({ length: 12 }, (_, i) => ({ month: i + 1, value: 0 })),
            }));
            setData(initialData);
        }
    }, [data, purchaseItems, setData]);
    
    const fiscalYear = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0] : null, [fiscalYears]);
    const exchangeRate = 1; // This should come from a new state if needed. Using 1 for now.
    const mainCurrency = fiscalYear?.mainCurrency || 'IRR';
    const secondaryCurrency = fiscalYear?.secondaryCurrency || 'USD';

    const handleDataChange = (itemId: number, field: 'inflationRate' | 'quantity', value: number, month?: number) => {
        const newData = data.map(row => {
            if (row.purchaseItemId === itemId) {
                if (field === 'quantity' && month) {
                    const newQuantities = row.monthlyQuantities.map(mq => 
                        mq.month === month ? { ...mq, value } : mq
                    );
                    return { ...row, monthlyQuantities: newQuantities };
                }
                if (field === 'inflationRate') {
                    return { ...row, inflationRate: value };
                }
            }
            return row;
        });
        setData(newData);
    };

    const handleExport = () => {
        const headers = [
            "قلم خریدنی", "آخرین قیمت خرید", "نرخ تورم پیش‌بینی شده (%)", "قیمت تامین پیش‌بینی شده",
            ...Array.from({length: 12}, (_, i) => `تعداد ماه ${i+1}`),
            `جمع کل (${mainCurrency})`,
            `جمع کل (${secondaryCurrency})`,
        ];

        const rows = data.map(row => {
            const item = purchaseItems.find(i => i.id === row.purchaseItemId);
            if (!item) return null;

            const inflation = Number(row.inflationRate) || predictedInflationRate;
            const predictedPrice = item.lastSupplyPrice * (1 + inflation / 100);
            const totalQty = row.monthlyQuantities.reduce((sum, mq) => sum + (Number(mq.value) || 0), 0);
            const totalValueMain = totalQty * predictedPrice;
            const totalValueSecondary = totalValueMain / exchangeRate;
            
            const monthlyQuantities = row.monthlyQuantities.map(mq => mq.value || 0);

            return [
                item.title,
                item.lastSupplyPrice,
                inflation,
                predictedPrice,
                ...monthlyQuantities,
                totalValueMain,
                totalValueSecondary,
            ].map(v => typeof v === 'number' ? v.toFixed(2) : v);
        }).filter(Boolean);

        exportToCsv("پیشبینی-خرید-مواد.csv", [headers, ...rows as (string|number)[][]]);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">پیش‌بینی خرید مواد مستقیم</h1>
                <button onClick={handleExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">خروجی اکسل</button>
            </div>
             <Card className="p-0 overflow-hidden">
                 <div className="overflow-auto border-b dark:border-slate-700" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                    <table className="min-w-full w-max border-collapse text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-20 shadow-sm">
                            <tr>
                                <th className="px-3 py-3 text-right font-semibold sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30 whitespace-nowrap">قلم خریدنی</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">آخرین قیمت خرید</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">نرخ تورم پیش‌بینی شده (%)</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">قیمت تامین پیش‌بینی شده</th>
                                {Array.from({ length: 12 }).map((_, i) => <th key={i} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">{i + 1}</th>)}
                                <th className="px-3 py-3 text-center font-semibold border-l border-b dark:border-slate-700 whitespace-nowrap">جمع کل ({mainCurrency})</th>
                                <th className="px-3 py-3 text-center font-semibold border-b dark:border-slate-700 whitespace-nowrap">جمع کل ({secondaryCurrency})</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white dark:bg-slate-900">
                             {data.map(row => {
                                const item = purchaseItems.find(i => i.id === row.purchaseItemId);
                                if (!item) return null;

                                const inflation = Number(row.inflationRate) || predictedInflationRate;
                                const predictedPrice = item.lastSupplyPrice * (1 + inflation / 100);
                                const totalQty = row.monthlyQuantities.reduce((sum, mq) => sum + (Number(mq.value) || 0), 0);
                                const totalValueMain = totalQty * predictedPrice;
                                const totalValueSecondary = totalValueMain / exchangeRate;

                                return (
                                <tr key={item.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td className="px-3 py-2 font-semibold whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50 border-l border-b dark:border-slate-700 z-10">{item.title}</td>
                                    <td className="px-3 py-2 font-mono text-center border-l border-b dark:border-slate-700">{item.lastSupplyPrice.toLocaleString('en-US')}</td>
                                    <td className="border-l border-b dark:border-slate-700 w-32"><FormattedNumberInput value={row.inflationRate} onValueChange={val => handleDataChange(item.id, 'inflationRate', val)} className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700" placeholder={String(predictedInflationRate)} /></td>
                                    <td className="px-3 py-2 font-mono font-semibold text-center border-l border-b dark:border-slate-700">{predictedPrice.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    {row.monthlyQuantities.map(mq => (
                                        <td key={mq.month} className="border-l border-b dark:border-slate-700 w-24">
                                            <FormattedNumberInput 
                                                value={mq.value} 
                                                onValueChange={(val) => handleDataChange(item.id, 'quantity', val, mq.month)} 
                                                className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700"
                                            />
                                        </td>
                                    ))}
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-l border-b dark:border-slate-700 w-36">{totalValueMain.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-b dark:border-slate-700 w-36">{totalValueSecondary.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                </tr>
                                )
                             })}
                         </tbody>
                    </table>
                 </div>
            </Card>
        </div>
    );
};

export default DirectMaterialPurchaseForecast;