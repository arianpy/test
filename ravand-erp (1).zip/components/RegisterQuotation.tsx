import React, { useState, useMemo, useEffect } from 'react';
import type { Quotation, QuotationItem, Person, Product, Auditable } from '../types';
import { QuotationStatus } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface RegisterQuotationProps {
    quotations: Quotation[];
    addQuotation: (quotation: Omit<Quotation, 'id' | keyof Auditable>) => void;
    updateQuotation: (quotation: Quotation) => void;
    deleteQuotation: (id: number) => void;
    customers: Person[];
    products: Product[];
}

const QuotationModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    // FIX: Corrected the onSave prop type to align with the data passed from the form, which may or may not include an ID and auditable fields.
    onSave: (quotation: Quotation | Omit<Quotation, 'id' | keyof Auditable>) => void;
    initialData: Quotation | null;
    customers: Person[];
    products: Product[];
}> = ({ isOpen, onClose, onSave, initialData, customers, products }) => {
    
    const getInitialState = (): Omit<Quotation, 'id' | keyof Auditable> => ({
        date: new Date().toISOString().split('T')[0],
        quotationNumber: `QT-${Date.now().toString().slice(-6)}`,
        customerId: 0,
        status: QuotationStatus.Draft,
        items: [],
        totalAmount: 0,
        description: '',
    });

    const [formData, setFormData] = useState<Omit<Quotation, 'id' | keyof Auditable> | Quotation>(getInitialState());

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        } else {
            setFormData(getInitialState());
        }
    }, [initialData, isOpen]);
    
    useEffect(() => {
        const total = formData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
        setFormData(prev => ({ ...prev, totalAmount: total }));
    }, [formData.items]);

    const customerOptions = useMemo(() => customers.map(c => ({ value: c.id, label: c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName })), [customers]);
    const productOptions = useMemo(() => products.map(p => ({ value: p.id, label: `${p.code} - ${p.title}`})), [products]);

    const handleAddItem = () => {
        const newItem: QuotationItem = { id: Date.now(), productId: 0, quantity: 1, unitPrice: 0 };
        setFormData(prev => ({ ...prev, items: [...prev.items, newItem] }));
    };

    const handleItemChange = (itemId: number, field: keyof Omit<QuotationItem, 'id'>, value: any) => {
        const newItems = formData.items.map(item => {
            if (item.id === itemId) {
                const updatedItem = { ...item, [field]: value };
                if (field === 'productId') {
                    const product = products.find(p => p.id === Number(value));
                    updatedItem.unitPrice = product?.cost || 0;
                }
                return updatedItem;
            }
            return item;
        });
        setFormData(prev => ({ ...prev, items: newItems }));
    };

    const handleRemoveItem = (itemId: number) => {
        setFormData(prev => ({ ...prev, items: prev.items.filter(item => item.id !== itemId) }));
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.customerId) { alert("لطفا مشتری را انتخاب کنید."); return; }
        onSave(formData);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={initialData ? 'ویرایش پیش فاکتور' : 'ایجاد پیش فاکتور جدید'}>
            <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormInput label="شماره پیش فاکتور" value={formData.quotationNumber} onChange={e => setFormData(p => ({ ...p, quotationNumber: e.target.value }))} required />
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تاریخ</label>
                        <ShamsiDatePicker value={formData.date} onChange={date => setFormData(p => ({ ...p, date }))} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">مشتری</label>
                        <SearchableSelect options={customerOptions} value={formData.customerId} onChange={val => setFormData(p => ({ ...p, customerId: val as number }))} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">وضعیت</label>
                        <SearchableSelect options={Object.values(QuotationStatus).map(s => ({ value: s, label: s }))} value={formData.status} onChange={val => setFormData(p => ({ ...p, status: val as QuotationStatus }))} />
                    </div>
                </div>
                
                <div className="pt-4 border-t dark:border-slate-600">
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="text-md font-semibold">اقلام</h3>
                        <button type="button" onClick={handleAddItem} className="px-3 py-1 text-xs text-white bg-custom-blue-primary rounded-md">+</button>
                    </div>
                    {formData.items.map(item => (
                        <div key={item.id} className="grid grid-cols-12 gap-2 items-center mb-2 p-2 bg-slate-50 dark:bg-slate-700/50 rounded-md">
                            <div className="col-span-5"><SearchableSelect options={productOptions} value={item.productId} onChange={val => handleItemChange(item.id, 'productId', val)} /></div>
                            <div className="col-span-3"><FormattedNumberInput value={item.quantity} onValueChange={val => handleItemChange(item.id, 'quantity', val)} className="w-full bg-transparent p-1 text-center" /></div>
                            <div className="col-span-3"><FormattedNumberInput value={item.unitPrice} onValueChange={val => handleItemChange(item.id, 'unitPrice', val)} className="w-full bg-transparent p-1 text-center" /></div>
                            <div className="col-span-1 text-center"><button type="button" onClick={() => handleRemoveItem(item.id)} className="text-red-500">&times;</button></div>
                        </div>
                    ))}
                    <div className="text-right font-bold mt-4">جمع کل: {formData.totalAmount.toLocaleString()}</div>
                </div>
                
                <FormInput as="textarea" label="توضیحات" value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} />

                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                </div>
            </form>
        </Modal>
    );
};

const RegisterQuotation: React.FC<RegisterQuotationProps> = ({ quotations, addQuotation, updateQuotation, deleteQuotation, customers, products }) => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [editingQuotation, setEditingQuotation] = useState<Quotation | null>(null);

    const customerMap = useMemo(() => new Map(customers.map(c => [c.id, c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName])), [customers]);

    const handleOpenModal = (quotation: Quotation | null = null) => {
        setEditingQuotation(quotation);
        setModalOpen(true);
    };

    const handleSave = (data: Quotation | Omit<Quotation, 'id' | keyof Auditable>) => {
        if ('id' in data) {
            updateQuotation(data);
        } else {
            addQuotation(data);
        }
        setModalOpen(false);
    };

    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این پیش فاکتور اطمینان دارید؟')) {
            deleteQuotation(id);
        }
    };
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">مدیریت پیش فاکتورها</h1>
                <button
                    onClick={() => handleOpenModal()}
                    className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700"
                >
                    ایجاد پیش فاکتور جدید
                </button>
            </div>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">شماره</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">مشتری</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                                <th className="px-4 py-3 text-left text-xs uppercase">مبلغ کل</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">اطلاعات ثبت</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">آخرین ویرایش</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {quotations.length > 0 ? quotations.map(q => (
                                <tr key={q.id}>
                                    <td className="px-4 py-4 font-medium">{q.quotationNumber}</td>
                                    <td className="px-4 py-4">{toShamsi(q.date)}</td>
                                    <td className="px-4 py-4">{customerMap.get(q.customerId) || '-'}</td>
                                    <td className="px-4 py-4">{q.status}</td>
                                    <td className="px-4 py-4 text-left font-mono">{q.totalAmount.toLocaleString()}</td>
                                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400">
                                        <div>{toShamsi(q.createdAt.split('T')[0])}</div>
                                        <div className="text-xs">{q.createdBy}</div>
                                    </td>
                                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400">
                                        <div>{toShamsi(q.updatedAt.split('T')[0])}</div>
                                        <div className="text-xs">{q.updatedBy}</div>
                                    </td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenModal(q)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(q.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={8} className="text-center py-6">هیچ پیش فاکتوری یافت نشد.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
            <QuotationModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} initialData={editingQuotation} customers={customers} products={products} />
        </div>
    );
};

const FormInput: React.FC<(React.InputHTMLAttributes<HTMLInputElement> | React.TextareaHTMLAttributes<HTMLTextAreaElement>) & { label: string, as?: 'input' | 'textarea' }> = ({ label, id, as = 'input', ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {as === 'textarea' ?
            <textarea id={id} {...props as React.TextareaHTMLAttributes<HTMLTextAreaElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" /> :
            <input id={id} {...props as React.InputHTMLAttributes<HTMLInputElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
        }
    </div>
);


export default RegisterQuotation;