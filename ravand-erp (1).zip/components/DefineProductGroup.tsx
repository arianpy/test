
import React, { useState, useEffect } from 'react';
import type { ProductGroup, Product } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';

// FIX: Add deleteGroup and products props to align with App.tsx.
interface DefineProductGroupProps {
    groups: ProductGroup[];
    addGroup: (group: Omit<ProductGroup, 'id' | 'children'>) => void;
    updateGroup: (groupId: number, newTitle: string) => void;
    deleteGroup: (groupId: number) => void;
    products: Product[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const GroupTree: React.FC<{ 
    groups: ProductGroup[]; 
    onAddSubgroup: (parentId: number, parentTitle: string) => void;
    onEditGroup: (groupId: number, currentTitle: string) => void;
    // FIX: Add onDeleteGroup prop for handling deletions.
    onDeleteGroup: (groupId: number, groupTitle: string) => void;
    level?: number;
}> = ({ groups, onAddSubgroup, onEditGroup, onDeleteGroup, level = 0 }) => {
    
    const renderNode = (group: ProductGroup) => (
        <li key={group.id}>
            <div className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg flex justify-between items-center">
                <span className="font-medium text-slate-800 dark:text-slate-200">{group.title}</span>
                <div className="flex space-x-2 rtl:space-x-reverse">
                    <button 
                        onClick={() => onDeleteGroup(group.id, group.title)}
                        className="text-xs px-3 py-1 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 rounded-full hover:bg-red-200 dark:hover:bg-red-800 transition-colors"
                    >
                        حذف
                    </button>
                    <button 
                        onClick={() => onEditGroup(group.id, group.title)}
                        className="text-xs px-3 py-1 bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300 rounded-full hover:bg-amber-200 dark:hover:bg-amber-800 transition-colors"
                    >
                        ویرایش
                    </button>
                    <button 
                        onClick={() => onAddSubgroup(group.id, group.title)}
                        className="text-xs px-3 py-1 bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300 rounded-full hover:bg-cyan-200 dark:hover:bg-cyan-800 transition-colors"
                    >
                        افزودن زیرگروه
                    </button>
                </div>
            </div>
            {group.children && group.children.length > 0 && (
                <ul className="mt-2 mr-6 pr-6 border-r-2 border-slate-200 dark:border-slate-600 space-y-2">
                    {group.children.map(child => renderNode(child))}
                </ul>
            )}
        </li>
    );

    return (
        <ul className="space-y-2">
            {groups.map(group => renderNode(group))}
        </ul>
    );
};


const DefineProductGroup: React.FC<DefineProductGroupProps> = ({ groups, addGroup, updateGroup, deleteGroup, products }) => {
    const [rootGroupTitle, setRootGroupTitle] = useState('');
    
    const [isAddModalOpen, setAddModalOpen] = useState(false);
    const [subgroupTitle, setSubgroupTitle] = useState('');
    const [parentInfo, setParentInfo] = useState<{ id: number; title: string } | null>(null);

    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [editedGroupTitle, setEditedGroupTitle] = useState('');
    const [editingGroupInfo, setEditingGroupInfo] = useState<{ id: number; title: string } | null>(null);

    useEffect(() => {
        if (editingGroupInfo) {
            setEditedGroupTitle(editingGroupInfo.title);
        }
    }, [editingGroupInfo]);

    const handleAddRootGroup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!rootGroupTitle.trim()) return;
        addGroup({ title: rootGroupTitle, parentId: null });
        setRootGroupTitle('');
    };

    const handleOpenSubgroupModal = (parentId: number, parentTitle: string) => {
        setParentInfo({ id: parentId, title: parentTitle });
        setAddModalOpen(true);
    };

    const handleCloseAddModal = () => {
        setAddModalOpen(false);
        setSubgroupTitle('');
        setParentInfo(null);
    };

    const handleAddSubgroup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!subgroupTitle.trim() || !parentInfo) return;
        addGroup({ title: subgroupTitle, parentId: parentInfo.id });
        handleCloseAddModal();
    };

    const handleOpenEditModal = (groupId: number, currentTitle: string) => {
        setEditingGroupInfo({ id: groupId, title: currentTitle });
        setEditModalOpen(true);
    };
    
    const handleCloseEditModal = () => {
        setEditModalOpen(false);
        setEditedGroupTitle('');
        setEditingGroupInfo(null);
    };

    const handleUpdateGroup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!editedGroupTitle.trim() || !editingGroupInfo) return;
        updateGroup(editingGroupInfo.id, editedGroupTitle);
        handleCloseEditModal();
    };

    const handleDeleteGroup = (groupId: number, groupTitle: string) => {
        const isGroupUsed = products.some(p => p.productGroupId === groupId);
        if (isGroupUsed) {
            alert(`امکان حذف گروه "${groupTitle}" وجود ندارد زیرا محصولاتی به آن اختصاص داده شده‌اند.`);
            return;
        }
        if (window.confirm(`آیا از حذف گروه "${groupTitle}" و تمام زیرگروه‌های آن اطمینان دارید؟`)) {
            deleteGroup(groupId);
        }
    };


    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف گروه محصولات</h1>
            
            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">تعریف و مدیریت گروه‌ها</h2>
                
                <div className="p-4 border rounded-lg dark:border-slate-700 mb-6 bg-slate-50 dark:bg-slate-800">
                    <form onSubmit={handleAddRootGroup} className="flex flex-col sm:flex-row items-end sm:space-x-4 sm:rtl:space-x-reverse space-y-4 sm:space-y-0">
                        <div className="flex-grow w-full">
                            <FormInput 
                                label="عنوان گروه اصلی جدید" 
                                id="rootGroupTitle" 
                                value={rootGroupTitle} 
                                onChange={(e) => setRootGroupTitle(e.target.value)} 
                                required 
                            />
                        </div>
                        <button type="submit" className="w-full sm:w-auto px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 h-10 flex-shrink-0">
                            افزودن گروه
                        </button>
                    </form>
                </div>

                <div>
                    <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-slate-200">درختواره گروه‌ها</h3>
                    {groups.length > 0 ? (
                       <GroupTree groups={groups} onAddSubgroup={handleOpenSubgroupModal} onEditGroup={handleOpenEditModal} onDeleteGroup={handleDeleteGroup} />
                    ) : (
                        <p className="text-center text-slate-500 dark:text-slate-400 py-4">هنوز گروهی تعریف نشده است. برای شروع، یک گروه اصلی از فرم بالا اضافه کنید.</p>
                    )}
                </div>
            </Card>
            
            {/* Add Subgroup Modal */}
            {parentInfo && (
                <Modal 
                    isOpen={isAddModalOpen} 
                    onClose={handleCloseAddModal} 
                    title={`افزودن زیرگروه به "${parentInfo.title}"`}
                >
                    <form onSubmit={handleAddSubgroup} className="space-y-4">
                        <FormInput 
                            label="عنوان زیرگروه"
                            id="subgroupTitle"
                            value={subgroupTitle}
                            onChange={(e) => setSubgroupTitle(e.target.value)}
                            required
                        />
                         <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                            <button type="button" onClick={handleCloseAddModal} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                            لغو
                            </button>
                            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            ذخیره زیرگروه
                            </button>
                        </div>
                    </form>
                </Modal>
            )}

            {/* Edit Group Modal */}
            {editingGroupInfo && (
                <Modal
                    isOpen={isEditModalOpen}
                    onClose={handleCloseEditModal}
                    title={`ویرایش عنوان گروه "${editingGroupInfo.title}"`}
                >
                     <form onSubmit={handleUpdateGroup} className="space-y-4">
                        <FormInput 
                            label="عنوان جدید گروه"
                            id="editedGroupTitle"
                            value={editedGroupTitle}
                            onChange={(e) => setEditedGroupTitle(e.target.value)}
                            required
                        />
                         <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                            <button type="button" onClick={handleCloseEditModal} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                                لغو
                            </button>
                            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                                ذخیره تغییرات
                            </button>
                        </div>
                    </form>
                </Modal>
            )}
        </div>
    );
};

export default DefineProductGroup;
