import React, { useState, useMemo, useEffect } from 'react';
// FIX: Added Auditable to the import to correctly type the addInvoice prop.
import type { PurchaseInvoice, PurchaseInvoiceItem, Person, PurchaseItem, AutoDocSetting, AccountHeadGroup, Currency, FiscalYear } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface RegisterAssetPurchaseReturnInvoiceProps {
    title: string;
    // FIX: Updated prop type to match what App.tsx provides, which is an object without Auditable fields.
    addInvoice: (invoice: Omit<PurchaseInvoice, 'id'>) => void;
    selectableInvoices: PurchaseInvoice[]; 
    allInvoices: PurchaseInvoice[];
    suppliers: Person[];
    items: PurchaseItem[];
    autoDocSetting?: AutoDocSetting;
    accountHeads: AccountHeadGroup[];
    currencies: Currency[];
    fiscalYears: FiscalYear[];
}

const formatNumber = (num: number | undefined | null): string => {
    if (num === null || num === undefined) return '0';
    return new Intl.NumberFormat('en-US').format(num);
};

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        <input id={id} {...props} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);


const RegisterAssetPurchaseReturnInvoice: React.FC<RegisterAssetPurchaseReturnInvoiceProps> = ({
    title,
    addInvoice,
    selectableInvoices,
    allInvoices,
    suppliers,
    items,
    autoDocSetting,
}) => {
    const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null);
    const [returnItems, setReturnItems] = useState<(PurchaseInvoiceItem & { originalQuantity: number })[]>([]);
    const [headerData, setHeaderData] = useState({
        docNumber: '',
        date: new Date().toISOString().split('T')[0],
        description: '',
    });

    const selectedInvoice = useMemo(() => 
        selectableInvoices.find(inv => inv.id === selectedInvoiceId),
        [selectedInvoiceId, selectableInvoices]
    );

    const supplierMap = useMemo(() => 
        suppliers.reduce((map, s) => {
            map[s.id] = s.personType === 'natural' ? `${s.firstName} ${s.lastName}` : s.registeredName;
            return map;
        }, {} as Record<number, string>),
    [suppliers]);

    const itemMap = useMemo(() => 
        items.reduce((map, item) => {
            map[item.id] = item;
            return map;
        }, {} as Record<number, PurchaseItem>),
    [items]);
    
    const returnInvoices = useMemo(() => 
        allInvoices.filter(inv => inv.items.some(i => i.quantity < 0) && inv.invoiceType === 'asset'),
    [allInvoices]);


    useEffect(() => {
        if (selectedInvoice) {
            setHeaderData(prev => ({ ...prev, description: `برگشت از فاکتور دارایی شماره ${selectedInvoice.docNumber}` }));
            setReturnItems(selectedInvoice.items.map(item => ({
                ...item,
                quantity: 0, // Return quantity starts at 0
                originalQuantity: item.quantity,
            })));
        } else {
            setHeaderData({
                docNumber: '',
                date: new Date().toISOString().split('T')[0],
                description: '',
            });
            setReturnItems([]);
        }
    }, [selectedInvoice]);

    const handleQuantityChange = (itemId: number, newQuantity: number) => {
        setReturnItems(prevItems => prevItems.map(item => {
            if (item.itemId === itemId) {
                if (newQuantity > item.originalQuantity) {
                    alert(`مقدار برگشتی نمی‌تواند از مقدار خریداری شده (${item.originalQuantity}) بیشتر باشد.`);
                    return { ...item, quantity: item.originalQuantity };
                }
                return { ...item, quantity: newQuantity < 0 ? 0 : newQuantity };
            }
            return item;
        }));
    };
    
    const totals = useMemo(() => {
        let subtotal = 0;
        returnItems.forEach(item => {
            const rowSubtotal = item.quantity * item.unitPrice;
            const discountAmount = rowSubtotal * (item.discount / 100);
            subtotal += rowSubtotal - discountAmount;
        });
        return { total: subtotal };
    }, [returnItems]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (allInvoices.some(inv => inv.docNumber === headerData.docNumber && headerData.docNumber.trim() !== '')) {
            alert('شماره فاکتور برگشتی تکراری است. لطفا شماره دیگری وارد کنید.');
            return;
        }
        
        if (!selectedInvoice) {
            alert('لطفا ابتدا یک فاکتور خرید دارایی را انتخاب کنید.');
            return;
        }
        
        const itemsToSubmit = returnItems
            .filter(item => item.quantity > 0)
            .map(({ originalQuantity, ...rest }) => ({
                ...rest,
                id: Date.now() + Math.random(),
                quantity: -rest.quantity, // Make quantity negative for return
            }));

        if (itemsToSubmit.length === 0) {
            alert('هیچ دارایی برای برگشت انتخاب نشده است (تعداد 0).');
            return;
        }

// FIX: Added auditable properties to satisfy the PurchaseInvoice type.
        const newReturnInvoice: Omit<PurchaseInvoice, 'id'> = {
            invoiceType: 'asset',
            orderNumber: selectedInvoice.orderNumber,
            docNumber: headerData.docNumber,
            date: headerData.date,
            supplierId: selectedInvoice.supplierId,
            items: itemsToSubmit,
            description: headerData.description,
            debtorSubLedgerId: autoDocSetting?.defaultDebtorSubLedgerId ?? null,
            creditorSubLedgerId: autoDocSetting?.defaultCreditorSubLedgerId ?? null,
            currencyCode: selectedInvoice.currencyCode,
            exchangeRate: selectedInvoice.exchangeRate,
            tradeDiscount: 0,
            createdAt: new Date().toISOString(),
            createdBy: 'کاربر تست',
            updatedAt: new Date().toISOString(),
            updatedBy: 'کاربر تست',
        };
        
        addInvoice(newReturnInvoice);
        alert('فاکتور برگشت از خرید دارایی با موفقیت ثبت شد.');
        
        setSelectedInvoiceId(null);
    };


    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>

            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="p-4 border dark:border-slate-700 rounded-lg space-y-4">
                        <h2 className="text-lg font-semibold">انتخاب فاکتور خرید دارایی اصلی</h2>
                        <SearchableSelect
                            options={selectableInvoices.map(inv => ({ value: inv.id, label: `${inv.docNumber} - ${supplierMap[inv.supplierId] || 'نامشخص'} - ${toShamsi(inv.date)}` }))}
                            value={selectedInvoiceId}
                            onChange={(val) => setSelectedInvoiceId(val as number | null)}
                            placeholder="یک فاکتور خرید دارایی برای مرجوعی انتخاب کنید..."
                        />
                    </div>

                    {selectedInvoice && (
                        <>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تامین کننده</label>
                                    <input type="text" value={supplierMap[selectedInvoice.supplierId] || ''} disabled className="w-full p-2 bg-slate-100 dark:bg-slate-800 rounded-md border dark:border-slate-600"/>
                                </div>
                                <FormInput label="شماره فاکتور برگشتی" name="docNumber" value={headerData.docNumber} onChange={(e) => setHeaderData(p => ({...p, docNumber: e.target.value}))} required />
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تاریخ برگشت</label>
                                    <ShamsiDatePicker value={headerData.date} onChange={date => setHeaderData(p => ({...p, date}))} required />
                                </div>
                                <div className="md:col-span-3">
                                     <FormInput label="توضیحات" name="description" value={headerData.description} onChange={(e) => setHeaderData(p => ({...p, description: e.target.value}))} />
                                </div>
                            </div>

                            <div className="space-y-4 pt-4 border-t dark:border-slate-700">
                                <h3 className="text-lg font-semibold">اقلام فاکتور برگشتی</h3>
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                                        <thead className="bg-slate-50 dark:bg-slate-700">
                                            <tr>
                                                <th className="px-4 py-3 text-right text-xs uppercase">دارایی</th>
                                                <th className="px-4 py-3 text-center text-xs uppercase">تعداد خریداری شده</th>
                                                <th className="px-4 py-3 text-center text-xs uppercase">تعداد برگشتی</th>
                                                <th className="px-4 py-3 text-center text-xs uppercase">فی واحد</th>
                                                <th className="px-4 py-3 text-center text-xs uppercase">تخفیف (%)</th>
                                                <th className="px-4 py-3 text-left text-xs uppercase">جمع مبلغ برگشتی</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                            {returnItems.map(item => {
                                                const rowTotal = (item.quantity * item.unitPrice) * (1 - (item.discount / 100));
                                                return (
                                                <tr key={item.itemId}>
                                                    <td className="px-4 py-2">{itemMap[item.itemId]?.title}</td>
                                                    <td className="px-4 py-2 text-center">{item.originalQuantity}</td>
                                                    <td className="px-4 py-2 w-32">
                                                        <FormattedNumberInput
                                                            value={item.quantity}
                                                            onValueChange={(val) => handleQuantityChange(item.itemId, val)}
                                                            className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600"
                                                        />
                                                    </td>
                                                    <td className="px-4 py-2 text-center font-mono">{formatNumber(item.unitPrice)}</td>
                                                    <td className="px-4 py-2 text-center font-mono">{item.discount}</td>
                                                    <td className="px-4 py-2 text-left font-mono">{formatNumber(rowTotal)}</td>
                                                </tr>
                                            )})}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="flex justify-end pt-4">
                                <div className="w-full md:w-1/2 space-y-2">
                                    <div className="flex justify-between p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-lg">
                                        <span className="font-bold">جمع کل مبلغ برگشتی</span>
                                        <span className="font-bold font-mono">{formatNumber(totals.total)}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                                <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ثبت فاکتور برگشتی</button>
                            </div>
                        </>
                    )}
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فاکتورهای برگشت دارایی ثبت شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">شماره فاکتور</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">تاریخ</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">تامین کننده</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">مبلغ کل</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {returnInvoices.length > 0 ? (
                                returnInvoices.map(invoice => {
                                    const total = invoice.items.reduce((sum, item) => {
                                        const rowSubtotal = Math.abs(item.quantity) * item.unitPrice;
                                        const discountAmount = rowSubtotal * (item.discount / 100);
                                        return sum + (rowSubtotal - discountAmount);
                                    }, 0);
                                    return (
                                    <tr key={invoice.id}>
                                        <td className="px-6 py-4 whitespace-nowrap">{invoice.docNumber}</td>
                                        <td className="px-6 py-4 whitespace-nowrap">{toShamsi(invoice.date)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap">{supplierMap[invoice.supplierId] || 'نامشخص'}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-left font-mono">{formatNumber(total)}</td>
                                    </tr>
                                )})
                            ) : (
                                <tr><td colSpan={4} className="text-center py-4 text-slate-500 dark:text-slate-400">فاکتور برگشتی ثبت نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default RegisterAssetPurchaseReturnInvoice;
