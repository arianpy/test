import React, { useState, useMemo, useEffect } from 'react';
import type { AssetDeployment as AssetDeploymentType, Asset, Warehouse, PurchaseItem, FormGroup, AssetLocation, DepreciationMethod, AccountHeadSubLedger } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import FormattedNumberInput from './ui/FormattedNumberInput';
import { toShamsi } from '../utils/date';

interface AssetDeploymentProps {
    deployments: AssetDeploymentType[];
    addDeployment: (deployment: Omit<AssetDeploymentType, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>) => void;
    assets: Asset[];
    warehouses: Warehouse[];
    purchaseItems: PurchaseItem[];
    formGroups: FormGroup[];
    assetLocations: AssetLocation[];
    depreciationMethods: DepreciationMethod[];
    allSubLedgers: AccountHeadSubLedger[];
}

const AssetDeployment: React.FC<AssetDeploymentProps> = ({
    deployments,
    addDeployment,
    assets,
    warehouses,
    purchaseItems,
    formGroups,
    assetLocations,
    depreciationMethods,
    allSubLedgers
}) => {
    const getInitialState = () => ({
        date: new Date().toISOString().split('T')[0],
        docNumber: '',
        accountingDocNumber: '', // Auto-filled
        groupId: null as number | null,
        assetId: null as number | null,
        debtorSubLedgerId: null as number | null, // Auto-filled from asset
        warehouseId: null as number | null,
        relatedPurchaseItemId: null as number | null,
        creditorSubLedgerId: null as number | null,
        deploymentDate: new Date().toISOString().split('T')[0],
        locationId: null as number | null, // Auto-filled from asset
        costCenterSubLedgerId: null as number | null,
        cost: '' as number | '',
        usefulLifeYears: null as number | null,
        salvageValue: null as number | null,
        decliningBalanceRate: null as number | null,
        depreciationMethodId: null as number | null, // Auto-filled from asset
    });

    const [formData, setFormData] = useState(getInitialState());

    const assetOptions = useMemo(() => assets.map(a => ({ value: a.id, label: `${a.code} - ${a.title}` })), [assets]);
    const groupOptions = useMemo(() => formGroups.map(g => ({ value: g.id, label: g.title })), [formGroups]);
    const warehouseOptions = useMemo(() => warehouses.map(w => ({ value: w.id, label: w.name })), [warehouses]);
    const purchaseItemOptions = useMemo(() => purchaseItems.map(pi => ({ value: pi.id, label: pi.title })), [purchaseItems]);
    const locationOptions = useMemo(() => assetLocations.map(al => ({ value: al.id, label: al.name })), [assetLocations]);
    const depreciationMethodOptions = useMemo(() => depreciationMethods.map(dm => ({ value: dm.id, label: dm.name })), [depreciationMethods]);
    const subLedgerOptions = useMemo(() => allSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}`})), [allSubLedgers]);

    // Auto-populate fields when asset is selected
    useEffect(() => {
        if (formData.assetId) {
            const selectedAsset = assets.find(a => a.id === formData.assetId);
            if (selectedAsset) {
                setFormData(prev => ({
                    ...prev,
                    debtorSubLedgerId: selectedAsset.assetSubLedgerId,
                    locationId: selectedAsset.locationId,
                    depreciationMethodId: selectedAsset.depreciationMethodId,
                }));
            }
        } else {
             setFormData(prev => ({ ...prev, debtorSubLedgerId: null, locationId: null, depreciationMethodId: null }));
        }
    }, [formData.assetId, assets]);
    
    // Auto-populate cost when related purchase item is selected
    useEffect(() => {
        if (formData.relatedPurchaseItemId) {
            const item = purchaseItems.find(pi => pi.id === formData.relatedPurchaseItemId);
            if (item) {
                setFormData(prev => ({ ...prev, cost: item.lastSupplyPrice }));
            }
        }
    }, [formData.relatedPurchaseItemId, purchaseItems]);
    
    const selectedDepreciationMethod = useMemo(() => 
        depreciationMethods.find(dm => dm.id === formData.depreciationMethodId),
    [formData.depreciationMethodId, depreciationMethods]);
    
    const isDecliningBalance = selectedDepreciationMethod?.name.includes('نزولی');

    const handleChange = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!formData.assetId || !formData.locationId || !formData.depreciationMethodId || !formData.debtorSubLedgerId || !formData.cost) {
            alert('لطفا تمام فیلدهای الزامی (* دار) را تکمیل کنید.');
            return;
        }

        const payload = {
            ...formData,
            // Ensure numeric values are numbers, not strings
            assetId: Number(formData.assetId),
            debtorSubLedgerId: Number(formData.debtorSubLedgerId),
            locationId: Number(formData.locationId),
            depreciationMethodId: Number(formData.depreciationMethodId),
            cost: Number(formData.cost) || 0,
            usefulLifeYears: formData.usefulLifeYears ? Number(formData.usefulLifeYears) : null,
            salvageValue: formData.salvageValue ? Number(formData.salvageValue) : null,
            decliningBalanceRate: formData.decliningBalanceRate ? Number(formData.decliningBalanceRate) : null,
        };

        addDeployment(payload);
        setFormData(getInitialState());
        alert('سند استقرار دارایی با موفقیت ثبت شد.');
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت اسناد استقرار دارایی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Section 1: Doc Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 border rounded-lg dark:border-slate-700">
                        <div>
                            <label className="block text-sm font-medium mb-1">تاریخ *</label>
                            <ShamsiDatePicker value={formData.date} onChange={val => handleChange('date', val)} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">شماره سند *</label>
                            <input type="text" value={formData.docNumber} onChange={e => handleChange('docNumber', e.target.value)} required className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">شماره سند حسابداری</label>
                            <input type="text" value={formData.accountingDocNumber} readOnly disabled className="w-full p-2 bg-slate-100 dark:bg-slate-800 border rounded-md" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">انتخاب گروه بندی</label>
                            <SearchableSelect options={groupOptions} value={formData.groupId} onChange={val => handleChange('groupId', val)} />
                        </div>
                    </div>

                    {/* Section 2: Asset and Accounts */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 border rounded-lg dark:border-slate-700">
                        <div className="lg:col-span-2">
                             <label className="block text-sm font-medium mb-1">انتخاب دارایی مورد نظر *</label>
                             <SearchableSelect options={assetOptions} value={formData.assetId} onChange={val => handleChange('assetId', val)} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">معین بدهکار *</label>
                            <input type="text" value={allSubLedgers.find(sl => sl.id === formData.debtorSubLedgerId)?.title || ''} readOnly disabled className="w-full p-2 bg-slate-100 dark:bg-slate-800 border rounded-md"/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">انتخاب انبار</label>
                            <SearchableSelect options={warehouseOptions} value={formData.warehouseId} onChange={val => handleChange('warehouseId', val)} />
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">انتخاب کالای مرتبط</label>
                            <SearchableSelect options={purchaseItemOptions} value={formData.relatedPurchaseItemId} onChange={val => handleChange('relatedPurchaseItemId', val)} />
                        </div>
                        <div className="lg:col-span-2">
                             <label className="block text-sm font-medium mb-1">معین بستانکار</label>
                             <SearchableSelect options={subLedgerOptions} value={formData.creditorSubLedgerId} onChange={val => handleChange('creditorSubLedgerId', val)} />
                        </div>
                    </div>

                    {/* Section 3: Depreciation Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 border rounded-lg dark:border-slate-700">
                         <div>
                            <label className="block text-sm font-medium mb-1">تاریخ استقرار *</label>
                            <ShamsiDatePicker value={formData.deploymentDate} onChange={val => handleChange('deploymentDate', val)} required />
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">محل استقرار *</label>
                            <SearchableSelect options={locationOptions} value={formData.locationId} onChange={val => handleChange('locationId', val)} disabled={!!formData.assetId} />
                        </div>
                         <div className="lg:col-span-2">
                            <label className="block text-sm font-medium mb-1">مرکز هزینه</label>
                            <SearchableSelect options={subLedgerOptions} value={formData.costCenterSubLedgerId} onChange={val => handleChange('costCenterSubLedgerId', val)} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">بهای تمام شده (ریالی) *</label>
                            <FormattedNumberInput value={formData.cost || ''} onValueChange={val => handleChange('cost', val)} required className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">روش استهلاک *</label>
                            <SearchableSelect options={depreciationMethodOptions} value={formData.depreciationMethodId} onChange={val => handleChange('depreciationMethodId', val)} disabled={!!formData.assetId}/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">عمر مفید (سال)</label>
                            <FormattedNumberInput value={formData.usefulLifeYears || ''} onValueChange={val => handleChange('usefulLifeYears', val)} disabled={isDecliningBalance} className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">ارزش اسقاط</label>
                            <FormattedNumberInput value={formData.salvageValue || ''} onValueChange={val => handleChange('salvageValue', val)} disabled={isDecliningBalance} className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium mb-1">نرخ ثابت نزولی (%)</label>
                            <FormattedNumberInput value={formData.decliningBalanceRate || ''} onValueChange={val => handleChange('decliningBalanceRate', val)} disabled={!isDecliningBalance} className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md"/>
                        </div>
                    </div>

                    <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">اسناد استقرار ثبت شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">شماره سند</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">دارایی</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">محل استقرار</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {deployments.length > 0 ? deployments.map(doc => (
                                <tr key={doc.id}>
                                    <td className="px-4 py-4">{toShamsi(doc.date)}</td>
                                    <td className="px-4 py-4">{doc.docNumber}</td>
                                    <td className="px-4 py-4">{assets.find(a => a.id === doc.assetId)?.title || '-'}</td>
                                    <td className="px-4 py-4">{assetLocations.find(al => al.id === doc.locationId)?.name || '-'}</td>
                                </tr>
                            )) : (
                                <tr><td colSpan={4} className="text-center py-6 text-slate-500">سندی ثبت نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AssetDeployment;