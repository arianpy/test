import React, { useState, useMemo, useEffect } from 'react';
import type { AssetDepreciationDocument, AssetDeployment, Asset, AssetDepreciationDocumentRow } from '../types';
import Card from './ui/Card';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import FormattedNumberInput from './ui/FormattedNumberInput';
import { toShamsi } from '../utils/date';

interface AssetDepreciationProps {
    depreciations: AssetDepreciationDocument[];
    addDepreciation: (depreciation: Omit<AssetDepreciationDocument, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>) => void;
    assetDeployments: AssetDeployment[];
    assets: Asset[];
}

interface CalculatedRow {
    assetId: number;
    assetCode: string;
    assetTitle: string;
    deploymentDate: string;
    cost: number;
    accumulatedDepreciation: number;
    currentPeriodDepreciation: number | '';
    bookValue: number;
}

const AssetDepreciationComponent: React.FC<AssetDepreciationProps> = ({
    depreciations,
    addDepreciation,
    assetDeployments,
    assets
}) => {
    const getInitialState = () => ({
        docDate: new Date().toISOString().split('T')[0],
        calculationDate: new Date().toISOString().split('T')[0],
        docNumber: '',
        accountingDocNumber: '',
    });

    const [header, setHeader] = useState(getInitialState());
    const [calculatedRows, setCalculatedRows] = useState<CalculatedRow[]>([]);
    const [filters, setFilters] = useState({ assetCode: '', assetTitle: '' });

    const assetMap = useMemo(() => new Map(assets.map(a => [a.id, a])), [assets]);

    const handleCalculate = () => {
        const accumulatedDepreciationMap = new Map<number, number>();
        depreciations.forEach(doc => {
            doc.rows.forEach(row => {
                const current = accumulatedDepreciationMap.get(row.assetId) || 0;
                accumulatedDepreciationMap.set(row.assetId, current + row.currentPeriodDepreciation);
            });
        });

        const rows: CalculatedRow[] = assetDeployments
            .filter(d => new Date(d.deploymentDate) <= new Date(header.calculationDate))
            .map(deployment => {
                const asset = assetMap.get(deployment.assetId);
                if (!asset) return null;

                const cost = deployment.cost;
                const accumulatedDepreciation = accumulatedDepreciationMap.get(deployment.assetId) || 0;
                
                // Simplified straight-line depreciation for one year.
                // A real implementation would consider the calculation date range.
                const yearlyDepreciation = (deployment.usefulLifeYears && deployment.usefulLifeYears > 0)
                    ? (cost - (deployment.salvageValue || 0)) / deployment.usefulLifeYears
                    : 0;

                const bookValue = cost - accumulatedDepreciation;

                return {
                    assetId: deployment.assetId,
                    assetCode: asset.code,
                    assetTitle: asset.title,
                    deploymentDate: deployment.deploymentDate,
                    cost: cost,
                    accumulatedDepreciation: accumulatedDepreciation,
                    currentPeriodDepreciation: yearlyDepreciation,
                    bookValue: bookValue,
                };
            }).filter((row): row is CalculatedRow => row !== null);
        
        setCalculatedRows(rows);
        alert('لیست دارایی‌های آماده برای محاسبه استهلاک فراخوانی شد.');
    };
    
    const handleRowChange = (assetId: number, value: number) => {
        setCalculatedRows(prev => prev.map(row => 
            row.assetId === assetId ? { ...row, currentPeriodDepreciation: value } : row
        ));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        const finalRows: AssetDepreciationDocumentRow[] = calculatedRows
            .filter(row => Number(row.currentPeriodDepreciation) > 0)
            .map(row => ({
                id: Date.now() + Math.random(),
                assetId: row.assetId,
                cost: row.cost,
                accumulatedDepreciation: row.accumulatedDepreciation,
                currentPeriodDepreciation: Number(row.currentPeriodDepreciation) || 0,
                bookValue: row.bookValue - (Number(row.currentPeriodDepreciation) || 0),
        }));

        if (finalRows.length === 0) {
            alert('هیچ هزینه‌ی استهلاکی برای ثبت وجود ندارد.');
            return;
        }

        const payload = { ...header, rows: finalRows };
        addDepreciation(payload);
        setCalculatedRows([]);
        setHeader(getInitialState());
        alert('سند استهلاک با موفقیت ثبت شد.');
    };

    const filteredRows = useMemo(() => {
        return calculatedRows.filter(row =>
            row.assetCode.toLowerCase().includes(filters.assetCode.toLowerCase()) &&
            row.assetTitle.toLowerCase().includes(filters.assetTitle.toLowerCase())
        );
    }, [calculatedRows, filters]);

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت اسناد استهلاک دارایی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 p-4 border rounded-lg dark:border-slate-700 items-end">
                        <div className="lg:col-span-1">
                            <label className="block text-sm font-medium mb-1">تاریخ سند</label>
                            <ShamsiDatePicker value={header.docDate} onChange={val => setHeader(p => ({...p, docDate: val}))} required />
                        </div>
                        <div className="lg:col-span-1">
                            <label className="block text-sm font-medium mb-1">تاریخ محاسبه</label>
                            <ShamsiDatePicker value={header.calculationDate} onChange={val => setHeader(p => ({...p, calculationDate: val}))} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">شماره سند</label>
                            <input type="text" value={header.docNumber} onChange={e => setHeader(p => ({...p, docNumber: e.target.value}))} required className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">شماره سند حسابداری</label>
                            <input type="text" value={header.accountingDocNumber} readOnly disabled className="w-full p-2 bg-slate-100 dark:bg-slate-800 border rounded-md" />
                        </div>
                        <button type="button" onClick={handleCalculate} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 h-10">فراخوانی و محاسبه استهلاک</button>
                    </div>

                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold">فیلدهای اختصاصی</h3>
                        <div className="overflow-x-auto">
                            <table className="min-w-full w-max text-sm">
                                <thead className="bg-slate-50 dark:bg-slate-700">
                                    <tr>
                                        <th className="p-2 text-right">کد دارایی</th>
                                        <th className="p-2 text-right">عنوان دارایی</th>
                                        <th className="p-2 text-right">تاریخ استقرار</th>
                                        <th className="p-2 text-left">بهای تمام شده</th>
                                        <th className="p-2 text-left">استهلاک انباشته</th>
                                        <th className="p-2 text-left">هزینه استهلاک دوره جاری</th>
                                        <th className="p-2 text-left">ارزش دفتری</th>
                                    </tr>
                                    <tr>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." value={filters.assetCode} onChange={e => setFilters(p => ({...p, assetCode: e.target.value}))} className="w-full text-xs p-1 border rounded" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." value={filters.assetTitle} onChange={e => setFilters(p => ({...p, assetTitle: e.target.value}))} className="w-full text-xs p-1 border rounded" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." disabled className="w-full text-xs p-1 border rounded bg-slate-100" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." disabled className="w-full text-xs p-1 border rounded bg-slate-100" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." disabled className="w-full text-xs p-1 border rounded bg-slate-100" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." disabled className="w-full text-xs p-1 border rounded bg-slate-100" /></th>
                                        <th className="p-1"><input type="text" placeholder="جستجو..." disabled className="w-full text-xs p-1 border rounded bg-slate-100" /></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredRows.map(row => (
                                        <tr key={row.assetId} className="border-b dark:border-slate-700">
                                            <td className="p-2">{row.assetCode}</td>
                                            <td className="p-2">{row.assetTitle}</td>
                                            <td className="p-2">{toShamsi(row.deploymentDate)}</td>
                                            <td className="p-2 text-left font-mono">{row.cost.toLocaleString()}</td>
                                            <td className="p-2 text-left font-mono">{row.accumulatedDepreciation.toLocaleString()}</td>
                                            <td className="p-1 w-40"><FormattedNumberInput value={row.currentPeriodDepreciation} onValueChange={val => handleRowChange(row.assetId, val)} className="w-full bg-transparent p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600"/></td>
                                            <td className="p-2 text-left font-mono">{(row.bookValue - (Number(row.currentPeriodDepreciation) || 0)).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div className="flex justify-end pt-5 border-t dark:border-slate-700 space-x-2 rtl:space-x-reverse">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ثبت سند استهلاک</button>
                        <button type="button" disabled className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md disabled:bg-green-300">ثبت سند حسابداری</button>
                    </div>
                </form>
            </Card>

             <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">اسناد استهلاک ثبت شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ سند</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">شماره سند</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ محاسبه</th>
                                <th className="px-4 py-3 text-left text-xs uppercase">جمع هزینه استهلاک</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                           {depreciations.length > 0 ? depreciations.map(doc => {
                                const totalDepreciation = doc.rows.reduce((sum, row) => sum + row.currentPeriodDepreciation, 0);
                                return (
                                <tr key={doc.id}>
                                    <td className="px-4 py-4">{toShamsi(doc.docDate)}</td>
                                    <td className="px-4 py-4">{doc.docNumber}</td>
                                    <td className="px-4 py-4">{toShamsi(doc.calculationDate)}</td>
                                    <td className="px-4 py-4 text-left font-mono">{totalDepreciation.toLocaleString()}</td>
                                </tr>
                            )}) : (
                                <tr><td colSpan={4} className="text-center py-6 text-slate-500">سندی ثبت نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AssetDepreciationComponent;