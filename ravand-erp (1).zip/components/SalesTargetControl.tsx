

import React, { useMemo } from 'react';
import type { SalesForecastRow, ProductGroup, Product, SalesInvoice, FiscalYear } from '../types';
import Card from './ui/Card';

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

interface SalesTargetControlProps {
    salesForecastData: SalesForecastRow[];
    salesInvoices: SalesInvoice[];
    productGroups: ProductGroup[];
    products: Product[];
    fiscalYears: FiscalYear[];
    predictedExchangeRate: number;
}

const formatNumber = (num: number) => {
    if (isNaN(num) || !isFinite(num)) return '-';
    return num.toLocaleString('en-US', { maximumFractionDigits: 0 });
};

const SalesTargetControl: React.FC<SalesTargetControlProps> = ({ salesForecastData, salesInvoices, productGroups, products, fiscalYears, predictedExchangeRate }) => {
    
    const fiscalYear = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0] : null, [fiscalYears]);
    // FIX: Use the predictedExchangeRate prop instead of trying to access it from the fiscalYear object.
    const exchangeRate = predictedExchangeRate || 1;
    const mainCurrency = fiscalYear?.mainCurrency || 'IRR';
    const secondaryCurrency = fiscalYear?.secondaryCurrency || 'USD';
    
    const productGroupMap = useMemo(() => new Map(productGroups.map(g => [g.id, g.title])), [productGroups]);
    const productToGroupMap = useMemo(() => new Map(products.map(p => [p.id, p.productGroupId])), [products]);

    const avgGroupPrices = useMemo(() => {
        const priceData = new Map<number, { totalValue: number; totalQty: number }>();
        salesInvoices.forEach(invoice => {
            invoice.items.forEach(item => {
                const current = priceData.get(item.productId) || { totalValue: 0, totalQty: 0 };
                current.totalQty += item.quantity;
                current.totalValue += item.unitPrice * item.quantity * (1 - item.discount / 100);
                priceData.set(item.productId, current);
            });
        });
        const avgPrices = new Map<number, number>();
        priceData.forEach((data, productId) => {
            if (data.totalQty > 0) avgPrices.set(productId, data.totalValue / data.totalQty);
        });
        products.forEach(p => { if (!avgPrices.has(p.id)) avgPrices.set(p.id, p.cost); });

        const groupPrices = new Map<number, number>();
        const productsByGroup = new Map<number, number[]>();
        products.forEach(p => {
            const groupProducts = productsByGroup.get(p.productGroupId) || [];
            productsByGroup.set(p.productGroupId, [...groupProducts, p.id]);
        });
        productsByGroup.forEach((prodIds, groupId) => {
            const prices = prodIds.map(id => avgPrices.get(id) || 0).filter(p => p > 0);
            const avgPrice = prices.length > 0 ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
            groupPrices.set(groupId, avgPrice);
        });
        return groupPrices;
    }, [salesInvoices, products]);

    const actualSalesByGroupAndMonth = useMemo(() => {
        const salesMap = new Map<string, number>(); // Key: "groupId-month"
        salesInvoices.forEach(invoice => {
            const month = new Date(invoice.date).getMonth() + 1;
            invoice.items.forEach(item => {
                const groupId = productToGroupMap.get(item.productId);
                if (groupId) {
                    const key = `${groupId}-${month}`;
                    const value = item.quantity * item.unitPrice * (1 - item.discount / 100);
                    salesMap.set(key, (salesMap.get(key) || 0) + value);
                }
            });
        });
        return salesMap;
    }, [salesInvoices, productToGroupMap]);

    const reportData = useMemo(() => {
        return productGroups.map(group => {
            const forecastRow = salesForecastData.find(fr => fr.productGroupId === group.id);
            const avgPrice = avgGroupPrices.get(group.id) || 0;
            
            const monthlyData = Array.from({ length: 12 }, (_, i) => {
                const month = i + 1;
                const targetQty = forecastRow?.monthlyQuantities.find(mq => mq.month === month)?.value || 0;
                const target = Number(targetQty) * avgPrice;
                const actual = actualSalesByGroupAndMonth.get(`${group.id}-${month}`) || 0;
                const deviation = actual - target;
                const deviationPercent = target !== 0 ? (deviation / target) * 100 : (actual > 0 ? Infinity : 0);
                return { month, target, actual, deviation, deviationPercent };
            });

            const annual = monthlyData.reduce((acc, monthData) => {
                acc.target += monthData.target;
                acc.actual += monthData.actual;
                return acc;
            }, { target: 0, actual: 0 });

            const annualDeviation = annual.actual - annual.target;
            const annualDeviationPercent = annual.target !== 0 ? (annualDeviation / annual.target) * 100 : (annual.actual > 0 ? Infinity : 0);

            return {
                groupId: group.id,
                groupName: group.title,
                monthlyData,
                annual: { ...annual, deviation: annualDeviation, deviationPercent: annualDeviationPercent },
            };
        });
    }, [productGroups, salesForecastData, avgGroupPrices, actualSalesByGroupAndMonth]);
    
    const grandTotals = useMemo(() => {
        const totals = reportData.reduce((acc, row) => {
            acc.annual.target += row.annual.target;
            acc.annual.actual += row.annual.actual;
            row.monthlyData.forEach(md => {
                acc.monthly[md.month-1].target += md.target;
                acc.monthly[md.month-1].actual += md.actual;
            });
            return acc;
        }, {
            annual: { target: 0, actual: 0 },
            monthly: Array.from({ length: 12 }, () => ({ target: 0, actual: 0 }))
        });

        const annualDeviation = totals.annual.actual - totals.annual.target;
        const annualDeviationPercent = totals.annual.target !== 0 ? (annualDeviation / totals.annual.target) * 100 : (totals.annual.actual > 0 ? Infinity : 0);

        return {
            annual: { ...totals.annual, deviation: annualDeviation, deviationPercent: annualDeviationPercent },
            monthly: totals.monthly.map(md => {
                const deviation = md.actual - md.target;
                const deviationPercent = md.target !== 0 ? (deviation / md.target) * 100 : (md.actual > 0 ? Infinity : 0);
                return { ...md, deviation, deviationPercent };
            })
        };
    }, [reportData]);
    
    const DeviationCell: React.FC<{ value: number, percent: number }> = ({ value, percent }) => {
        const colorClass = value > 0 ? 'text-green-600 dark:text-green-400' : value < 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-500 dark:text-slate-400';
        const percentText = isFinite(percent) ? `(${percent.toFixed(1)}%)` : '(∞)';
        return (
            <div className={`font-mono text-center ${colorClass}`}>
                <div>{formatNumber(value)}</div>
                <div className="text-xs">{percentText}</div>
            </div>
        );
    };

    const handleExport = () => {
        const headers = [
            "گروه محصول",
            ...Array.from({ length: 12 }, (_, i) => `هدف ماه ${i + 1}`),
            ...Array.from({ length: 12 }, (_, i) => `عملکرد ماه ${i + 1}`),
            ...Array.from({ length: 12 }, (_, i) => `انحراف ماه ${i + 1}`),
            ...Array.from({ length: 12 }, (_, i) => `درصد انحراف ماه ${i + 1}`),
            `هدف سالانه (${mainCurrency})`,
            `عملکرد سالانه (${mainCurrency})`,
            `انحراف سالانه (${mainCurrency})`,
            `درصد انحراف سالانه`,
            `هدف سالانه (${secondaryCurrency})`,
            `عملکرد سالانه (${secondaryCurrency})`,
        ];

        const dataRows = [...reportData, {
             groupId: -1,
             groupName: 'جمع کل',
             monthlyData: grandTotals.monthly,
             annual: grandTotals.annual
        }].map(row => {
            return [
                row.groupName,
                ...row.monthlyData.map(md => md.target.toFixed(0)),
                ...row.monthlyData.map(md => md.actual.toFixed(0)),
                ...row.monthlyData.map(md => md.deviation.toFixed(0)),
                ...row.monthlyData.map(md => isFinite(md.deviationPercent) ? md.deviationPercent.toFixed(2) : 'N/A'),
                row.annual.target.toFixed(0),
                row.annual.actual.toFixed(0),
                row.annual.deviation.toFixed(0),
                isFinite(row.annual.deviationPercent) ? row.annual.deviationPercent.toFixed(2) : 'N/A',
                (row.annual.target / exchangeRate).toFixed(0),
                (row.annual.actual / exchangeRate).toFixed(0),
            ];
        });
        
        exportToCsv('کنترل-اهداف-فروش.csv', [headers, ...dataRows]);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">کنترل اهداف فروش</h1>
                <button onClick={handleExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">خروجی اکسل</button>
            </div>
            <Card className="p-0 overflow-hidden">
                 <div className="overflow-auto border-b dark:border-slate-700" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                    <table className="min-w-full w-max border-collapse text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-20 shadow-sm">
                            <tr>
                                <th rowSpan={2} className="px-3 py-3 text-right font-semibold align-middle sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30 whitespace-nowrap">گروه محصول</th>
                                {Array.from({ length: 12 }).map((_, i) => <th key={i} colSpan={3} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">{i + 1}</th>)}
                                <th colSpan={5} className="px-3 py-3 text-center font-semibold border-l border-b dark:border-slate-700 whitespace-nowrap">جمع کل سالانه</th>
                            </tr>
                             <tr>
                                {Array.from({length: 12}).map((_, i) => (
                                    <React.Fragment key={i}>
                                        <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">هدف</th>
                                        <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">عملکرد</th>
                                        <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">انحراف</th>
                                    </React.Fragment>
                                ))}
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">هدف ({mainCurrency})</th>
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">عملکرد ({mainCurrency})</th>
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">انحراف ({mainCurrency})</th>
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">هدف ({secondaryCurrency})</th>
                                <th className="px-2 py-2 font-normal border-b dark:border-slate-700 whitespace-nowrap">عملکرد ({secondaryCurrency})</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-900">
                           {reportData.map(row => (
                               <tr key={row.groupId} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                   <td className="px-3 py-2 font-semibold whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50 border-l border-b dark:border-slate-700 z-10">{row.groupName}</td>
                                   {row.monthlyData.map(md => (
                                       <React.Fragment key={md.month}>
                                           <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(md.target)}</td>
                                           <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(md.actual)}</td>
                                           <td className="p-1 border-l border-b dark:border-slate-700"><DeviationCell value={md.deviation} percent={md.deviationPercent} /></td>
                                       </React.Fragment>
                                   ))}
                                   <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(row.annual.target)}</td>
                                   <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(row.annual.actual)}</td>
                                   <td className="p-1 border-l border-b dark:border-slate-700"><DeviationCell value={row.annual.deviation} percent={row.annual.deviationPercent} /></td>
                                   <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(row.annual.target / exchangeRate)}</td>
                                   <td className="p-2 font-mono text-center border-b dark:border-slate-700">{formatNumber(row.annual.actual / exchangeRate)}</td>
                               </tr>
                           ))}
                        </tbody>
                        <tfoot className="bg-slate-100 dark:bg-slate-800 font-bold sticky bottom-0 z-20">
                             <tr className="border-t-2 border-slate-300 dark:border-slate-600">
                                <td className="px-3 py-3 sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30">جمع کل</td>
                                {grandTotals.monthly.map((md, i) => (
                                    <React.Fragment key={i}>
                                        <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(md.target)}</td>
                                        <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(md.actual)}</td>
                                        <td className="p-1 border-l border-b dark:border-slate-700"><DeviationCell value={md.deviation} percent={md.deviationPercent} /></td>
                                    </React.Fragment>
                                ))}
                                <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(grandTotals.annual.target)}</td>
                                <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(grandTotals.annual.actual)}</td>
                                <td className="p-1 border-l border-b dark:border-slate-700"><DeviationCell value={grandTotals.annual.deviation} percent={grandTotals.annual.deviationPercent} /></td>
                                <td className="p-2 font-mono text-center border-l border-b dark:border-slate-700">{formatNumber(grandTotals.annual.target / exchangeRate)}</td>
                                <td className="p-2 font-mono text-center border-b dark:border-slate-700">{formatNumber(grandTotals.annual.actual / exchangeRate)}</td>
                             </tr>
                        </tfoot>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default SalesTargetControl;