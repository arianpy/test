
import React, { useState, useMemo, useEffect } from 'react';
import type { Checkbook, Bank } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface DefineCheckbooksProps {
    checkbooks: Checkbook[];
    addCheckbook: (checkbook: Omit<Checkbook, 'id'>) => void;
    updateCheckbook: (checkbook: Checkbook) => void;
    deleteCheckbook: (checkbookId: number) => void;
    banks: Bank[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);


const EditCheckbookModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    checkbook: Checkbook | null;
    updateCheckbook: (checkbook: Checkbook) => void;
    banks: Bank[];
}> = ({ isOpen, onClose, checkbook, updateCheckbook, banks }) => {
    
    const [formData, setFormData] = useState<Checkbook | null>(checkbook);

    useEffect(() => {
        setFormData(checkbook);
    }, [checkbook]);

    if (!isOpen || !formData) return null;
    
    const bankOptions = banks.map(b => ({ value: b.id, label: `${b.mainBankName} - ${b.branchName} (${b.accountNumber})`}));

    const handleChange = (field: keyof Omit<Checkbook, 'id'>, value: any) => {
        setFormData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateCheckbook({
                ...formData,
                sheetCount: Number(formData.sheetCount)
            });
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش دسته چک`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <CustomFormSelect label="عنوان بانک">
                        <SearchableSelect options={bankOptions} value={formData.bankId} onChange={val => handleChange('bankId', val)} />
                    </CustomFormSelect>
                    <FormInput label="سریال شروع" value={formData.startSerial} onChange={e => handleChange('startSerial', e.target.value)} required />
                    <div>
                        <label className="block text-sm font-medium">تعداد برگه</label>
                        <FormattedNumberInput value={formData.sheetCount} onValueChange={val => handleChange('sheetCount', val)} className="mt-1 w-full p-2 border rounded-md" required />
                    </div>
                </div>

                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};

const DefineCheckbooks: React.FC<DefineCheckbooksProps> = ({ checkbooks, addCheckbook, updateCheckbook, deleteCheckbook, banks }) => {
    const initialState = {
        bankId: banks.length > 0 ? banks[0].id : 0,
        startSerial: '',
        sheetCount: '' as number | '',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedCheckbook, setSelectedCheckbook] = useState<Checkbook | null>(null);

    const bankMap = useMemo(() => 
        banks.reduce((map, bank) => {
            map[bank.id] = `${bank.mainBankName} - ${bank.branchName}`;
            return map;
        }, {} as Record<number, string>),
    [banks]);

    const bankOptions = useMemo(() => banks.map(b => ({ value: b.id, label: `${b.mainBankName} - ${b.branchName} (${b.accountNumber})`})), [banks]);

    const handleChange = (field: keyof typeof initialState, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!formData.bankId || !formData.startSerial || !formData.sheetCount) {
            alert('لطفا تمامی فیلدها را پر کنید.');
            return;
        }
        addCheckbook({
            bankId: Number(formData.bankId),
            startSerial: formData.startSerial,
            sheetCount: Number(formData.sheetCount),
        });
        setFormData(initialState);
        alert('دسته چک جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (checkbook: Checkbook) => {
        setSelectedCheckbook(checkbook);
        setEditModalOpen(true);
    };

    const getEndSerial = (startSerial: string, count: number): string => {
        const start = BigInt(startSerial);
        const end = start + BigInt(count - 1);
        return end.toString();
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف دسته چک‌ها</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <div className="lg:col-span-2">
                            <CustomFormSelect label="عنوان بانک">
                                <SearchableSelect options={bankOptions} value={formData.bankId} onChange={val => handleChange('bankId', val)} />
                            </CustomFormSelect>
                        </div>
                        <FormInput label="سریال شروع" value={formData.startSerial} onChange={e => handleChange('startSerial', e.target.value)} required placeholder="سریال شروع"/>
                        <div>
                           <label className="block text-sm font-medium">تعداد برگه</label>
                           <FormattedNumberInput value={formData.sheetCount} onValueChange={val => handleChange('sheetCount', val)} className="mt-1 w-full p-2 border rounded-md" required placeholder="تعداد برگه"/>
                        </div>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                           تعریف دسته چک
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">دسته چک‌های تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs uppercase">عنوان بانک</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">سریال شروع</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">سریال پایان</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">تعداد برگه</th>
                            <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {checkbooks.length > 0 ? (
                            checkbooks.map((checkbook) => (
                                <tr key={checkbook.id}>
                                    <td className="px-4 py-4 whitespace-nowrap">{bankMap[checkbook.bankId]}</td>
                                    <td className="px-4 py-4 whitespace-nowrap font-mono">{checkbook.startSerial}</td>
                                    <td className="px-4 py-4 whitespace-nowrap font-mono">{getEndSerial(checkbook.startSerial, checkbook.sheetCount)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap font-mono">{checkbook.sheetCount}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center space-x-4 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(checkbook)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => deleteCheckbook(checkbook.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={5} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز دسته چکی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditCheckbookModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                checkbook={selectedCheckbook}
                updateCheckbook={updateCheckbook}
                banks={banks}
            />
        </div>
    );
};

export default DefineCheckbooks;
