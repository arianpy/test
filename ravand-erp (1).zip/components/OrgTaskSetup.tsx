import React, { useState, useMemo, useEffect } from 'react';
import type { OrgChartNode, DeploymentNode, AssignedTask, TaskFrequency } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';

interface OrgTaskSetupProps {
    orgChart: OrgChartNode[];
    deploymentStructure: DeploymentNode[];
    assignedTasks: AssignedTask[];
    onSaveAssignedTasks: (orgChartNodeId: number, tasks: Omit<AssignedTask, 'id' | 'orgChartNodeId'>[]) => void;
}

const getTasksFromDeployment = (nodes: DeploymentNode[]): { value: number; label: string }[] => {
    const tasks: { value: number; label: string }[] = [];
    const traverse = (node: DeploymentNode) => {
        if (node.level === 6) {
            tasks.push({ value: node.id, label: node.title });
        }
        if (node.children) {
            node.children.forEach(traverse);
        }
    };
    nodes.forEach(traverse);
    return tasks;
};

const OrgTaskSetup: React.FC<OrgTaskSetupProps> = ({ orgChart, deploymentStructure, assignedTasks, onSaveAssignedTasks }) => {
    const [selectedOrgNodeId, setSelectedOrgNodeId] = useState<number | null>(null);
    const [currentTasks, setCurrentTasks] = useState<Omit<AssignedTask, 'id' | 'orgChartNodeId'>[]>([]);
    const [isDirty, setIsDirty] = useState(false);

    const deploymentTasks = useMemo(() => getTasksFromDeployment(deploymentStructure), [deploymentStructure]);
    const deploymentTaskMap = useMemo(() => new Map(deploymentTasks.map(t => [t.value, t.label])), [deploymentTasks]);

    const frequencyOptions: { value: TaskFrequency, label: string }[] = [
        { value: 'روزانه', label: 'روزانه' },
        { value: 'هفتگی', label: 'هفتگی' },
        { value: 'ماهیانه', label: 'ماهیانه' },
        { value: 'فصلی', label: 'فصلی' },
        { value: 'سالانه', label: 'سالانه' },
        { value: 'وظیفه مستقل', label: 'وظیفه مستقل' },
    ];

    useEffect(() => {
        if (selectedOrgNodeId !== null) {
            const tasks = assignedTasks
                .filter(t => t.orgChartNodeId === selectedOrgNodeId)
                .map(({ id, orgChartNodeId, ...rest }) => rest);
            setCurrentTasks(tasks);
            setIsDirty(false); // Reset dirty state on node change
        } else {
            setCurrentTasks([]);
            setIsDirty(false);
        }
    }, [selectedOrgNodeId, assignedTasks]);

    const handleAddTask = (task: Omit<AssignedTask, 'id' | 'orgChartNodeId'>) => {
        setCurrentTasks(prev => [...prev, task]);
        setIsDirty(true);
    };

    const handleRemoveTask = (index: number) => {
        setCurrentTasks(prev => prev.filter((_, i) => i !== index));
        setIsDirty(true);
    };

    const handleSaveChanges = () => {
        if (selectedOrgNodeId !== null) {
            onSaveAssignedTasks(selectedOrgNodeId, currentTasks);
            setIsDirty(false);
            alert('تغییرات با موفقیت ذخیره شد.');
        }
    };

    const renderOrgNode = (node: OrgChartNode, level = 0) => (
        <React.Fragment key={node.id}>
            <div
                onClick={() => setSelectedOrgNodeId(node.id)}
                className={`p-2 rounded-md cursor-pointer transition-colors ${selectedOrgNodeId === node.id ? 'bg-custom-blue-primary text-white font-semibold' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                style={{ paddingRight: `${level * 20 + 8}px` }}
            >
                {node.title}
            </div>
            {node.children && node.children.map(child => renderOrgNode(child, level + 1))}
        </React.Fragment>
    );

    const AddTaskForm: React.FC = () => {
        const [frequency, setFrequency] = useState<TaskFrequency>('روزانه');
        const [deploymentTaskId, setDeploymentTaskId] = useState<number | null>(null);
        const [customTaskTitle, setCustomTaskTitle] = useState('');
        
        const isIndependent = frequency === 'وظیفه مستقل';

        const handleSubmit = (e: React.FormEvent) => {
            e.preventDefault();
            if (isIndependent) {
                if (!customTaskTitle.trim()) { alert('لطفا عنوان وظیفه مستقل را وارد کنید.'); return; }
                handleAddTask({ frequency, deploymentTaskId: null, customTaskTitle: customTaskTitle.trim() });
            } else {
                if (!deploymentTaskId) { alert('لطفا یک وظیفه از لیست انتخاب کنید.'); return; }
                handleAddTask({ frequency, deploymentTaskId, customTaskTitle: null });
            }
            // Reset form
            setFrequency('روزانه');
            setDeploymentTaskId(null);
            setCustomTaskTitle('');
        };

        return (
            <form onSubmit={handleSubmit} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg space-y-4">
                <h4 className="font-semibold text-slate-800 dark:text-slate-200">افزودن وظیفه جدید</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div>
                        <label className="text-sm font-medium">نوع وظیفه</label>
                        <SearchableSelect options={frequencyOptions} value={frequency} onChange={val => setFrequency(val as TaskFrequency)} />
                    </div>
                    <div className="md:col-span-2">
                        {isIndependent ? (
                            <div>
                                <label className="text-sm font-medium">عنوان وظیفه مستقل</label>
                                <input type="text" value={customTaskTitle} onChange={e => setCustomTaskTitle(e.target.value)} className="w-full mt-1 p-2 bg-white dark:bg-slate-700 border rounded-md" required />
                            </div>
                        ) : (
                            <div>
                                <label className="text-sm font-medium">انتخاب وظیفه از ساختار استقرار</label>
                                <SearchableSelect options={deploymentTasks} value={deploymentTaskId} onChange={val => setDeploymentTaskId(val as number)} placeholder="یک وظیفه انتخاب کنید..."/>
                            </div>
                        )}
                    </div>
                </div>
                 <div className="text-right">
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن</button>
                </div>
            </form>
        );
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیم وظایf سازمانی</h1>
            <div className="flex flex-col md:flex-row md:space-x-6 md:space-x-reverse space-y-6 md:space-y-0">
                <Card className="md:w-1/3">
                    <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">۱. انتخاب سمت سازمانی</h2>
                    <div className="max-h-[60vh] overflow-y-auto pr-2 space-y-1">
                        {orgChart.map(node => renderOrgNode(node))}
                    </div>
                </Card>

                <Card className="md:w-2/3">
                    <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">۲. تخصیص وظایف</h2>
                    {selectedOrgNodeId === null ? (
                        <div className="flex items-center justify-center h-full text-slate-500">
                            <p>برای مشاهده و تخصیص وظایف، یک سمت را از لیست سمت چپ انتخاب کنید.</p>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            <div>
                                <table className="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                                    <thead className="text-xs text-slate-700 uppercase bg-slate-50 dark:bg-slate-700 dark:text-slate-400">
                                        <tr>
                                            <th scope="col" className="px-6 py-3">عنوان وظیفه</th>
                                            <th scope="col" className="px-6 py-3">نوع</th>
                                            <th scope="col" className="px-6 py-3 text-center">عملیات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {currentTasks.map((task, index) => (
                                            <tr key={index} className="bg-white border-b dark:bg-slate-800 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600">
                                                <th scope="row" className="px-6 py-4 font-medium text-slate-900 whitespace-nowrap dark:text-white">
                                                    {task.customTaskTitle || deploymentTaskMap.get(task.deploymentTaskId!) || 'نامشخص'}
                                                </th>
                                                <td className="px-6 py-4">{task.frequency}</td>
                                                <td className="px-6 py-4 text-center">
                                                    <button onClick={() => handleRemoveTask(index)} className="font-medium text-red-600 dark:text-red-500 hover:underline">حذف</button>
                                                </td>
                                            </tr>
                                        ))}
                                         {currentTasks.length === 0 && (
                                            <tr><td colSpan={3} className="text-center p-4">هیچ وظیفه‌ای برای این سمت تخصیص داده نشده است.</td></tr>
                                         )}
                                    </tbody>
                                </table>
                            </div>
                            <AddTaskForm />
                            {isDirty && (
                                <div className="text-right pt-4 border-t dark:border-slate-600">
                                    <button onClick={handleSaveChanges} className="px-6 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">ذخیره تغییرات برای این سمت</button>
                                </div>
                            )}
                        </div>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default OrgTaskSetup;
