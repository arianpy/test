import React, { useState } from 'react';
import type { AccountHeadGroup, AccountHeadLedger, AccountHeadSubLedger } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';

interface AccountHeadDefinitionProps {
  accountHeads: AccountHeadGroup[];
  addSubLedger: (ledgerId: number, subLedger: Omit<AccountHeadSubLedger, 'id'>) => void;
  updateSubLedger: (ledgerId: number, subLedger: AccountHeadSubLedger) => void;
  deleteSubLedger: (ledgerId: number, subLedgerId: number) => void;
}

const ToggleSwitch: React.FC<{ checked: boolean; onChange: () => void; }> = ({ checked, onChange }) => {
    return (
      <label className="relative inline-flex items-center cursor-pointer">
        <input type="checkbox" checked={checked} onChange={onChange} className="sr-only peer" />
        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-cyan-600"></div>
      </label>
    );
};

const SubLedgerModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<AccountHeadSubLedger, 'id'>) => void;
  mode: 'add' | 'edit';
  parentLedgerTitle?: string;
  initialData?: AccountHeadSubLedger | null;
}> = ({ isOpen, onClose, onSubmit, mode, parentLedgerTitle, initialData }) => {
  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [canLinkToDetailed, setCanLinkToDetailed] = useState(false);
  const [active, setActive] = useState(true);
  const [nature, setNature] = useState<'debit' | 'credit' | 'floating'>('floating');

  React.useEffect(() => {
    if (isOpen) {
      setCode(initialData?.code || '');
      setTitle(initialData?.title || '');
      setCanLinkToDetailed(initialData?.canLinkToDetailed || false);
      setActive(initialData ? initialData.active : true);
      setNature(initialData?.nature || 'floating');
    }
  }, [initialData, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ code, title, canLinkToDetailed, active, nature });
    onClose();
  };

  const modalTitle = mode === 'add'
    ? `افزودن حساب معین به: ${parentLedgerTitle}`
    : `ویرایش حساب معین: ${initialData?.title}`;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">کد معین</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">عنوان معین</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                required
              />
            </div>
        </div>
         <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">ماهیت</label>
            <select
                value={nature}
                onChange={(e) => setNature(e.target.value as 'debit' | 'credit' | 'floating')}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
            >
                <option value="debit">بدهکار</option>
                <option value="credit">بستانکار</option>
                <option value="floating">شناور</option>
            </select>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t dark:border-slate-600">
            <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-700">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">قابلیت اتصال به تفصیل</label>
                <ToggleSwitch checked={canLinkToDetailed} onChange={() => setCanLinkToDetailed(prev => !prev)} />
            </div>
             <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-700">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">وضعیت (فعال / غیرفعال)</label>
                <ToggleSwitch checked={active} onChange={() => setActive(prev => !prev)} />
            </div>
        </div>
        <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
            لغو
          </button>
          <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
            ذخیره
          </button>
        </div>
      </form>
    </Modal>
  );
};


const AccountHeadDefinition: React.FC<AccountHeadDefinitionProps> = ({ accountHeads, addSubLedger, updateSubLedger, deleteSubLedger }) => {
    const [expandedGroups, setExpandedGroups] = useState<Record<number, boolean>>({});
    const [expandedLedgers, setExpandedLedgers] = useState<Record<number, boolean>>({});
    const [isModalOpen, setModalOpen] = useState(false);
    const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
    const [selectedLedger, setSelectedLedger] = useState<AccountHeadLedger | null>(null);
    const [selectedSubLedger, setSelectedSubLedger] = useState<AccountHeadSubLedger | null>(null);

    const toggleGroup = (groupId: number) => {
        setExpandedGroups(prev => ({ ...prev, [groupId]: !prev[groupId] }));
    };

    const toggleLedger = (ledgerId: number) => {
        setExpandedLedgers(prev => ({ ...prev, [ledgerId]: !prev[ledgerId] }));
    };

    const handleOpenAddModal = (ledger: AccountHeadLedger) => {
        setSelectedLedger(ledger);
        setSelectedSubLedger(null);
        setModalMode('add');
        setModalOpen(true);
    };

    const handleOpenEditModal = (subLedger: AccountHeadSubLedger, parentLedger: AccountHeadLedger) => {
        setSelectedLedger(parentLedger);
        setSelectedSubLedger(subLedger);
        setModalMode('edit');
        setModalOpen(true);
    };

    const handleDelete = (ledgerId: number, subLedgerId: number) => {
        if (window.confirm('آیا از حذف این حساب معین اطمینان دارید؟')) {
            deleteSubLedger(ledgerId, subLedgerId);
        }
    };

    const handleModalSubmit = (data: Omit<AccountHeadSubLedger, 'id'>) => {
        if (modalMode === 'add' && selectedLedger) {
            addSubLedger(selectedLedger.id, data);
        } else if (modalMode === 'edit' && selectedLedger && selectedSubLedger) {
            updateSubLedger(selectedLedger.id, { ...selectedSubLedger, ...data });
        }
    };

    const natureText: Record<AccountHeadSubLedger['nature'], string> = {
        debit: 'بدهکار',
        credit: 'بستانکار',
        floating: 'شناور'
    };
    const natureColor: Record<AccountHeadSubLedger['nature'], string> = {
        debit: 'bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-300',
        credit: 'bg-fuchsia-100 text-fuchsia-800 dark:bg-fuchsia-900 dark:text-fuchsia-300',
        floating: 'bg-slate-200 text-slate-800 dark:bg-slate-600 dark:text-slate-300'
    };


    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف سرفصل‌های حسابداری</h1>
            <Card>
                <div className="space-y-2">
                    {accountHeads.map(group => (
                        <div key={group.id} className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                            <div 
                                className="p-3 bg-slate-100 dark:bg-slate-700/50 font-bold text-slate-800 dark:text-slate-100 flex justify-between items-center cursor-pointer"
                                onClick={() => toggleGroup(group.id)}
                            >
                                <span>{`گروه ${group.code}: ${group.title}`}</span>
                                <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transition-transform duration-200 ${expandedGroups[group.id] ? 'rotate-180' : ''}`} viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                            </div>
                            {expandedGroups[group.id] && (
                                <ul className="p-2 md:p-4 space-y-3 bg-white dark:bg-slate-800">
                                    {group.children.map(ledger => (
                                        <li key={ledger.id}>
                                            <div 
                                                className="flex justify-between items-center p-2 bg-slate-50 dark:bg-slate-700 rounded cursor-pointer"
                                                onClick={() => toggleLedger(ledger.id)}
                                            >
                                                <div className="flex items-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ml-2 transition-transform duration-200 ${expandedLedgers[ledger.id] ? 'rotate-90' : ''}`} viewBox="0 0 20 20" fill="currentColor">
                                                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                                                    </svg>
                                                    <span className="font-semibold text-slate-700 dark:text-slate-200">{`کل ${ledger.code}: ${ledger.title}`}</span>
                                                </div>
                                                <button onClick={(e) => { e.stopPropagation(); handleOpenAddModal(ledger); }} className="text-xs px-3 py-1 bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300 rounded-full hover:bg-cyan-200 dark:hover:bg-cyan-800 transition-colors">
                                                    افزودن معین
                                                </button>
                                            </div>
                                            {expandedLedgers[ledger.id] && (
                                                <div className="mt-2 mr-4 rtl:mr-0 rtl:ml-4 pr-4 rtl:pr-0 rtl:pl-4 border-r-2 rtl:border-r-0 rtl:border-l-2 border-slate-200 dark:border-slate-600">
                                                    <ul className="space-y-1">
                                                        {ledger.children.map(subLedger => (
                                                            <li key={subLedger.id} className="flex flex-wrap justify-between items-center p-2 rounded group hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                                                <span className="text-sm text-slate-600 dark:text-slate-300 mb-1 sm:mb-0">{`معین ${subLedger.code}: ${subLedger.title}`}</span>
                                                                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                                                                     <span className={`text-xs px-2 py-0.5 rounded-full ${natureColor[subLedger.nature]}`}>
                                                                        {natureText[subLedger.nature]}
                                                                    </span>
                                                                    {subLedger.canLinkToDetailed && (
                                                                        <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300">
                                                                            قابل تفصیلی
                                                                        </span>
                                                                    )}
                                                                    <span className={`text-xs px-2 py-0.5 rounded-full ${subLedger.active ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'}`}>
                                                                        {subLedger.active ? 'فعال' : 'غیرفعال'}
                                                                    </span>
                                                                    <div className="flex space-x-2 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                                                                        <button onClick={() => handleOpenEditModal(subLedger, ledger)} className="text-amber-500 hover:text-amber-700 dark:text-amber-400 dark:hover:text-amber-300">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>
                                                                        </button>
                                                                        <button onClick={() => handleDelete(ledger.id, subLedger.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        ))}
                                                        {ledger.children.length === 0 && <li className="px-2 py-1 text-xs text-slate-400 italic">حساب معین تعریف نشده است.</li>}
                                                    </ul>
                                                </div>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    ))}
                </div>
            </Card>
            <SubLedgerModal
                isOpen={isModalOpen}
                onClose={() => setModalOpen(false)}
                onSubmit={handleModalSubmit}
                mode={modalMode}
                parentLedgerTitle={selectedLedger?.title}
                initialData={selectedSubLedger}
            />
        </div>
    );
};

export default AccountHeadDefinition;