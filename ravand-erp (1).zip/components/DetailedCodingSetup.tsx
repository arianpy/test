import React, { useState, useMemo } from 'react';
import type { DetailedCodingSetting } from '../types';
import { DetailedCodingSection } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';

interface DetailedCodingSetupProps {
    settings: DetailedCodingSetting[];
    addSetting: (setting: Omit<DetailedCodingSetting, 'id'>) => void;
    updateSetting: (setting: DetailedCodingSetting) => void;
    deleteSetting: (id: number) => void;
}

const DetailedCodingSetup: React.FC<DetailedCodingSetupProps> = ({ settings, addSetting, updateSetting, deleteSetting }) => {
    
    const getInitialState = () => ({
        section: null as DetailedCodingSection | null,
        rangeFrom: '' as number | '',
        rangeTo: '' as number | '',
    });
    
    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);

    const sectionOptions = useMemo(() =>
        Object.values(DetailedCodingSection).map(section => ({
            value: section,
            label: section,
        })),
    []);
    
    const availableSectionOptions = useMemo(() => {
        const usedSections = new Set(settings.map(s => s.section));
        const currentSection = editingId ? settings.find(s => s.id === editingId)?.section : null;
        return sectionOptions.filter(opt => !usedSections.has(opt.value as DetailedCodingSection) || opt.value === currentSection);
    }, [settings, sectionOptions, editingId]);

    const handleEdit = (setting: DetailedCodingSetting) => {
        setEditingId(setting.id);
        setFormData({
            section: setting.section,
            rangeFrom: setting.rangeFrom,
            rangeTo: setting.rangeTo,
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleCancelEdit = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.section || formData.rangeFrom === '' || formData.rangeTo === '') {
            alert('لطفا تمامی فیلدها را پر کنید.');
            return;
        }

        const payload = {
            section: formData.section,
            rangeFrom: Number(formData.rangeFrom),
            rangeTo: Number(formData.rangeTo),
        };

        if (editingId) {
            updateSetting({ ...payload, id: editingId });
        } else {
            addSetting(payload);
        }
        handleCancelEdit();
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیمات کدینگ تفصیلی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-white">
                        {editingId ? 'ویرایش محدوده' : 'وارد کردن محدوده'}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div className="md:col-span-2">
                             <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">بخش</label>
                             <SearchableSelect 
                                options={availableSectionOptions}
                                value={formData.section}
                                onChange={(val) => setFormData(p => ({...p, section: val as DetailedCodingSection}))}
                                placeholder="انتخاب بخش..."
                             />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">محدوده از</label>
                            <FormattedNumberInput
                                value={formData.rangeFrom}
                                onValueChange={(val) => setFormData(p => ({...p, rangeFrom: val}))}
                                className="w-full p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                                required
                            />
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">محدوده تا</label>
                            <FormattedNumberInput
                                value={formData.rangeTo}
                                onValueChange={(val) => setFormData(p => ({...p, rangeTo: val}))}
                                className="w-full p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                                required
                            />
                        </div>
                    </div>
                     <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                        {editingId && (
                            <button type="button" onClick={handleCancelEdit} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                        )}
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            {editingId ? 'ذخیره تغییرات' : 'افزودن'}
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                 <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">محدوده‌های تعریف شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">بخش</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">محدوده از</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">محدوده تا</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {settings.length > 0 ? (
                                settings.map((setting) => (
                                    <tr key={setting.id}>
                                        <td className="px-6 py-4 whitespace-nowrap font-medium">{setting.section}</td>
                                        <td className="px-6 py-4 whitespace-nowrap font-mono">{setting.rangeFrom.toLocaleString()}</td>
                                        <td className="px-6 py-4 whitespace-nowrap font-mono">{setting.rangeTo.toLocaleString()}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center space-x-4 rtl:space-x-reverse">
                                            <button onClick={() => handleEdit(setting)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                            <button onClick={() => deleteSetting(setting.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} className="px-6 py-4 text-center text-sm text-slate-500">
                                        هیچ محدوده کدینگی تعریف نشده است.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DetailedCodingSetup;
