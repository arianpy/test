import React, { useState, useMemo, useRef } from 'react';
import type { Asset, AssetLocation, DepreciationMethod, AccountHeadSubLedger } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';
import { toShamsi } from '../utils/date';

// Props Interface
interface DefineAssetProps {
    assets: Asset[];
    addAsset: (asset: Omit<Asset, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>) => void;
    updateAsset: (asset: Asset) => void;
    deleteAsset: (assetId: number) => void;
    assetLocations: AssetLocation[];
    depreciationMethods: DepreciationMethod[];
    allSubLedgers: AccountHeadSubLedger[];
}

// QR Label Modal Component
const QRLabelModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    asset: Asset | null;
}> = ({ isOpen, onClose, asset }) => {
    const [labelSize, setLabelSize] = useState<'small' | 'medium' | 'large'>('medium');
    const printableRef = useRef<HTMLDivElement>(null);

    if (!isOpen || !asset) return null;

    const qrData = encodeURIComponent(JSON.stringify({
        id: asset.id,
        code: asset.code,
        title: asset.title,
        serial: asset.serialNumber,
    }));
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${qrData}`;

    const sizeClasses = {
        small: { container: 'w-48 h-32', qr: 'w-20 h-20', text: 'text-xs' },
        medium: { container: 'w-64 h-48', qr: 'w-24 h-24', text: 'text-sm' },
        large: { container: 'w-80 h-64', qr: 'w-32 h-32', text: 'text-base' },
    };

    const handlePrint = () => {
        const printContent = printableRef.current?.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        if (printWindow) {
            printWindow.document.write('<html><head><title>چاپ لیبل</title>');
            printWindow.document.write('<style>body { direction: rtl; font-family: sans-serif; text-align: center; } .label-container { display: flex; flex-direction: column; align-items: center; justify-content: space-around; border: 1px solid black; padding: 8px; page-break-inside: avoid; } img { max-width: 100%; } @media print { body { -webkit-print-color-adjust: exact; } } </style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write(printContent || '');
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="چاپ لیبل دارایی">
            <div className="space-y-4">
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                    <label>اندازه لیبل:</label>
                    <select value={labelSize} onChange={e => setLabelSize(e.target.value as any)} className="p-2 border rounded-md bg-white dark:bg-slate-700">
                        <option value="small">کوچک</option>
                        <option value="medium">متوسط</option>
                        <option value="large">بزرگ</option>
                    </select>
                </div>
                <div className="flex justify-center items-center p-4 bg-slate-100 dark:bg-slate-900 rounded-md">
                    <div ref={printableRef}>
                        <div className={`label-container ${sizeClasses[labelSize].container} flex flex-col items-center justify-center border border-dashed border-slate-400 p-2 bg-white text-black`}>
                            <h3 className={`font-bold ${sizeClasses[labelSize].text}`}>{asset.title}</h3>
                            <img src={qrCodeUrl} alt="QR Code" className={`${sizeClasses[labelSize].qr} my-2`} />
                            <div className={`text-center ${sizeClasses[labelSize].text}`}>
                                <p>کد: {asset.code}</p>
                                {asset.serialNumber && <p>سریال: {asset.serialNumber}</p>}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex justify-end pt-4 border-t dark:border-slate-600">
                    <button onClick={handlePrint} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">چاپ</button>
                </div>
            </div>
        </Modal>
    );
};

// Main Component
const DefineAsset: React.FC<DefineAssetProps> = ({ assets, addAsset, updateAsset, deleteAsset, assetLocations, depreciationMethods, allSubLedgers }) => {
    
    const getInitialState = (): Omit<Asset, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'> => ({
        code: '', title: '', brand: '', model: '', serialNumber: '',
        locationId: 0, depreciationMethodId: 0, assetSubLedgerId: 0, depreciationSubLedgerId: 0,
    });

    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);
    const [isQrModalOpen, setQrModalOpen] = useState(false);
    const [selectedAssetForQr, setSelectedAssetForQr] = useState<Asset | null>(null);

    const locationOptions = useMemo(() => assetLocations.map(loc => ({ value: loc.id, label: loc.name })), [assetLocations]);
    const depreciationMethodOptions = useMemo(() => depreciationMethods.map(method => ({ value: method.id, label: method.name })), [depreciationMethods]);
    const assetSubLedgerOptions = useMemo(() => allSubLedgers.filter(sl => sl.code.startsWith('1210')).map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}`})), [allSubLedgers]);
    const depreciationSubLedgerOptions = useMemo(() => allSubLedgers.filter(sl => sl.code.startsWith('1211')).map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}`})), [allSubLedgers]);

    const handleChange = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleEdit = (asset: Asset) => {
        setEditingId(asset.id);
        setFormData(asset);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleCancelEdit = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!formData.locationId || !formData.depreciationMethodId || !formData.assetSubLedgerId || !formData.depreciationSubLedgerId) {
            alert('لطفا تمام فیلدهای ستاره‌دار را پر کنید.');
            return;
        }

        if (editingId !== null) {
            updateAsset({ ...formData, id: editingId, createdAt: '', createdBy: '', updatedAt: '', updatedBy: '' }); // Auditable fields will be updated in App.tsx
        } else {
            addAsset(formData);
        }
        handleCancelEdit();
    };

    const handleDelete = (id: number) => {
        deleteAsset(id);
    };

    const handlePrintLabel = (asset: Asset) => {
        setSelectedAssetForQr(asset);
        setQrModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف دارایی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-medium">کد *</label>
                            <input type="text" value={formData.code} onChange={e => handleChange('code', e.target.value)} required className="mt-1 w-full p-2 bg-white dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600" />
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium">عنوان *</label>
                            <input type="text" value={formData.title} onChange={e => handleChange('title', e.target.value)} required className="mt-1 w-full p-2 bg-white dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">برند</label>
                            <input type="text" value={formData.brand} onChange={e => handleChange('brand', e.target.value)} className="mt-1 w-full p-2 bg-white dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">مدل</label>
                            <input type="text" value={formData.model} onChange={e => handleChange('model', e.target.value)} className="mt-1 w-full p-2 bg-white dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">شماره سریال</label>
                            <input type="text" value={formData.serialNumber} onChange={e => handleChange('serialNumber', e.target.value)} className="mt-1 w-full p-2 bg-white dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600" />
                        </div>
                         <div>
                            <label className="block text-sm font-medium">محل استقرار *</label>
                            <SearchableSelect options={locationOptions} value={formData.locationId || null} onChange={val => handleChange('locationId', val)} />
                            {locationOptions.length === 0 && <p className="text-xs text-amber-600 mt-1">هنوز محل استقراری تعریف نشده است.</p>}
                        </div>
                         <div>
                            <label className="block text-sm font-medium">روش استهلاک *</label>
                            <SearchableSelect options={depreciationMethodOptions} value={formData.depreciationMethodId || null} onChange={val => handleChange('depreciationMethodId', val)} />
                             {depreciationMethodOptions.length === 0 && <p className="text-xs text-amber-600 mt-1">هنوز روش استهلاکی تعریف نشده است.</p>}
                        </div>
                         <div>
                            <label className="block text-sm font-medium">معین دارایی *</label>
                             <SearchableSelect options={assetSubLedgerOptions} value={formData.assetSubLedgerId || null} onChange={val => handleChange('assetSubLedgerId', val)} />
                        </div>
                         <div>
                            <label className="block text-sm font-medium">معین استهلاک انباشته *</label>
                            <SearchableSelect options={depreciationSubLedgerOptions} value={formData.depreciationSubLedgerId || null} onChange={val => handleChange('depreciationSubLedgerId', val)} />
                        </div>
                    </div>
                    <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                        {editingId && <button type="button" onClick={handleCancelEdit} className="px-4 py-2 text-sm rounded-md bg-slate-200 dark:bg-slate-600">لغو</button>}
                        <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">{editingId ? 'ذخیره تغییرات' : 'ذخیره دارایی'}</button>
                    </div>
                </form>
            </Card>

             <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">دارایی‌های تعریف شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">کد</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">عنوان</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">شماره سریال</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {assets.length > 0 ? assets.map(asset => (
                                <tr key={asset.id}>
                                    <td className="px-4 py-4">{asset.code}</td>
                                    <td className="px-4 py-4 font-medium">{asset.title}</td>
                                    <td className="px-4 py-4">{asset.serialNumber || '-'}</td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse text-sm">
                                        <button onClick={() => handlePrintLabel(asset)} className="text-green-600 hover:underline">چاپ لیبل</button>
                                        <button onClick={() => handleEdit(asset)} className="text-amber-600 hover:underline">ویرایش</button>
                                        <button onClick={() => handleDelete(asset.id)} className="text-red-600 hover:underline">حذف</button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={4} className="text-center py-6 text-slate-500">هیچ دارایی‌ای تعریف نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
            <QRLabelModal isOpen={isQrModalOpen} onClose={() => setQrModalOpen(false)} asset={selectedAssetForQr} />
        </div>
    );
};

export default DefineAsset;