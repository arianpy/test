import React, { useState, useEffect } from 'react';
import type { Backup, AutoBackupConfig } from '../types';
import Card from './ui/Card';

interface BackupAndRestoreProps {
    backups: Backup[];
    config: AutoBackupConfig;
    createBackup: () => void;
    deleteBackup: (id: number) => void;
    updateConfig: (config: AutoBackupConfig) => void;
    handleRestore: (backup: Backup) => void;
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);

const ToggleSwitch: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; label: string; }> = ({ checked, onChange, label }) => (
    <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-700/50">
        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-cyan-600"></div>
        </label>
    </div>
);

const BackupAndRestore: React.FC<BackupAndRestoreProps> = ({ backups, config, createBackup, deleteBackup, updateConfig, handleRestore }) => {
    const [localConfig, setLocalConfig] = useState<AutoBackupConfig>(config);
    const [successMessage, setSuccessMessage] = useState<string>('');
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        setLocalConfig(config);
        setIsDirty(false);
    }, [config]);

    useEffect(() => {
        setIsDirty(JSON.stringify(config) !== JSON.stringify(localConfig));
    }, [localConfig, config]);

    const showSuccess = (msg: string) => {
        setSuccessMessage(msg);
        setTimeout(() => setSuccessMessage(''), 3000);
    };

    const handleCreateBackup = () => {
        createBackup();
        showSuccess('فایل پشتیبان جدید با موفقیت ایجاد شد.');
    };

    const handleConfigChange = (field: keyof AutoBackupConfig, value: any) => {
        setLocalConfig(prev => ({...prev, [field]: value}));
    };

    const handleSaveConfig = (e: React.FormEvent) => {
        e.preventDefault();
        updateConfig(localConfig);
        showSuccess('تنظیمات پشتیبان‌گیری خودکار با موفقیت ذخیره شد.');
        setIsDirty(false);
    };
    
    const handleDownloadClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault();
        // In a real application, this would trigger a file download.
        // Here, we just simulate it with an alert to prevent navigation issues.
        alert('شبیه‌سازی دانلود فایل پشتیبان...');
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">پشتیبانی و بازیابی</h1>
            
            {successMessage && (
                 <div className="p-4 bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200 rounded-lg text-center transition-opacity duration-300">
                    {successMessage}
                </div>
            )}

            <Card>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">پشتیبان‌گیری دستی</h2>
                <div className="mb-6">
                    <button 
                        onClick={handleCreateBackup}
                        className="px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600"
                    >
                        ایجاد پشتیبان دستی جدید
                    </button>
                </div>
                <h3 className="text-lg font-medium text-slate-800 dark:text-slate-200 mb-2">فهرست پشتیبان‌ها</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ و زمان</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام فایل</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">حجم</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {backups.length > 0 ? (
                                backups.map(backup => (
                                    <tr key={backup.id}>
                                        <td className="px-4 py-4">{backup.timestamp}</td>
                                        <td className="px-4 py-4 font-mono">{backup.filename}</td>
                                        <td className="px-4 py-4 font-mono">{backup.size}</td>
                                        <td className="px-4 py-4 text-center space-x-4 rtl:space-x-reverse">
                                            <button onClick={() => handleRestore(backup)} className="text-green-600 hover:underline">بازیابی</button>
                                            <button onClick={handleDownloadClick} className="text-cyan-600 hover:underline">دانلود</button>
                                            <button onClick={() => deleteBackup(backup.id)} className="text-red-500 hover:underline">حذف</button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} className="text-center py-6 text-slate-500 dark:text-slate-400">
                                        هیچ فایل پشتیبانی یافت نشد.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <Card>
                 <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">تنظیمات پشتیبان‌گیری خودکار</h2>
                 <form onSubmit={handleSaveConfig} className="space-y-6">
                    <ToggleSwitch 
                        label="فعال‌سازی پشتیبان‌گیری خودکار"
                        checked={localConfig.enabled}
                        onChange={(checked) => handleConfigChange('enabled', checked)}
                    />
                    <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 transition-opacity ${localConfig.enabled ? 'opacity-100' : 'opacity-50'}`}>
                        <FormInput 
                            label="دوره زمانی (روز)" 
                            id="period" 
                            type="number" 
                            min="1"
                            value={localConfig.period} 
                            onChange={(e) => handleConfigChange('period', Number(e.target.value))} 
                            disabled={!localConfig.enabled}
                         />
                         <FormInput label="ساعت" id="time" type="time" value={localConfig.time} onChange={(e) => handleConfigChange('time', e.target.value)} disabled={!localConfig.enabled} />
                    </div>
                    <div className="flex justify-end pt-4 border-t dark:border-slate-700">
                        <button type="submit" disabled={!isDirty} className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed">
                            ذخیره تنظیمات
                        </button>
                    </div>
                 </form>
            </Card>
        </div>
    );
};

export default BackupAndRestore;