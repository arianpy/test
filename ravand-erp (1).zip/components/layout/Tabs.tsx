
import React from 'react';
import type { ActiveView } from '../../App';

interface TabsProps {
    openViews: ActiveView[];
    activeViewIndex: number;
    getViewTitle: (view: ActiveView) => string;
    onTabClick: (index: number) => void;
    onTabClose: (index: number) => void;
}

const Tabs: React.FC<TabsProps> = ({ openViews, activeViewIndex, getViewTitle, onTabClick, onTabClose }) => {
    return (
        <div className="flex-shrink-0 bg-slate-200 dark:bg-slate-800 border-b border-slate-300 dark:border-slate-700">
            <nav className="flex items-center space-x-1 rtl:space-x-reverse overflow-x-auto p-1.5" aria-label="Tabs">
                {openViews.map((view, index) => (
                    <button
                        key={`${view.module}-${view.subView || 'base'}-${index}`}
                        onClick={() => onTabClick(index)}
                        className={`flex-shrink-0 flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-custom-blue-primary ${
                            index === activeViewIndex
                                ? 'bg-white dark:bg-slate-700 text-custom-blue-primary shadow-sm'
                                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/50 dark:hover:bg-slate-700/60'
                        }`}
                    >
                        <span>{getViewTitle(view)}</span>
                        {view.module !== 'dashboard' && (
                            <span
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onTabClose(index);
                                }}
                                className="mr-3 rtl:mr-0 rtl:ml-3 h-5 w-5 flex items-center justify-center rounded-full text-slate-500 hover:bg-red-200 hover:text-red-600 dark:hover:bg-red-800/50 dark:hover:text-red-400"
                            >
                                &times;
                            </span>
                        )}
                    </button>
                ))}
            </nav>
        </div>
    );
};

export default Tabs;
