

import React, { useState, useEffect, useMemo } from 'react';
import type { ActiveView, Module, SubView } from '../../App';
import { sidebarStructure, GroupItem, SubViewGroup, SidebarItem, ModuleItem, SubViewEntry, SubViewSimple } from '../../data/sidebarStructure';


interface SidebarProps {
  activeView: ActiveView;
  onNavigate: (view: ActiveView) => void;
  isSidebarOpen: boolean;
  setSidebarOpen: (isOpen: boolean) => void;
  onOpenSiteMap: () => void;
}

const findActiveGroup = (activeModule: Module) => {
    for (const item of sidebarStructure) {
        if (item.type === 'group' && item.modules.some(m => m.id === activeModule)) {
            return item as GroupItem;
        }
    }
    return undefined;
}


const isSubViewInGroup = (subgroup: SubViewGroup, activeSubViewId?: SubView) => {
    if (!activeSubViewId) return false;
    return subgroup.subViews.some(s => s.id === activeSubViewId);
}


const Sidebar: React.FC<SidebarProps> = ({ activeView, onNavigate, isSidebarOpen, setSidebarOpen, onOpenSiteMap }) => {
  const activeGroup = findActiveGroup(activeView.module);
  const [expandedGroup, setExpandedGroup] = useState<string | null>(activeGroup?.id || null);
  const [expandedModule, setExpandedModule] = useState<Module | null>(activeView.module);
  const [expandedSubgroups, setExpandedSubgroups] = useState<Record<string, boolean>>({});
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStructure = useMemo(() => {
    if (!searchTerm.trim()) {
        return sidebarStructure;
    }

    const lowercasedFilter = searchTerm.toLowerCase();

    function filterEntries(entries: SubViewEntry[]): SubViewEntry[] {
        const result: SubViewEntry[] = [];
        for (const entry of entries) {
            // FIX: Added 'type' in entry check to correctly narrow the union type before accessing properties.
            if ('type' in entry && entry.type === 'subgroup') {
                const filteredChildren = entry.subViews.filter(sv => sv.label.toLowerCase().includes(lowercasedFilter));
                if (entry.label.toLowerCase().includes(lowercasedFilter) || filteredChildren.length > 0) {
                    result.push({
                        ...entry,
                        subViews: entry.label.toLowerCase().includes(lowercasedFilter) ? entry.subViews : filteredChildren
                    });
                }
            } else { // SubViewSimple
                if (entry.label.toLowerCase().includes(lowercasedFilter)) {
                    result.push(entry);
                }
            }
        }
        return result;
    }

    const finalStructure = sidebarStructure.map(item => {
        if (item.type === 'module') {
            const filteredSubViews = filterEntries(item.subViews);
            if (item.label.toLowerCase().includes(lowercasedFilter) || filteredSubViews.length > 0) {
                return {
                    ...item,
                    subViews: item.label.toLowerCase().includes(lowercasedFilter) ? item.subViews : filteredSubViews
                };
            }
        }
        if (item.type === 'group') {
            const filteredModules = item.modules.map(mod => {
                const filteredSubViews = filterEntries(mod.subViews);
                if (mod.label.toLowerCase().includes(lowercasedFilter) || filteredSubViews.length > 0) {
                    return {
                        ...mod,
                        subViews: mod.label.toLowerCase().includes(lowercasedFilter) ? mod.subViews : filteredSubViews
                    };
                }
                return null;
            }).filter((m): m is ModuleItem => !!m);
            
            if (item.label.toLowerCase().includes(lowercasedFilter) || filteredModules.length > 0) {
                return {
                    ...item,
                    modules: item.label.toLowerCase().includes(lowercasedFilter) ? item.modules : filteredModules
                };
            }
        }
        return null;
    }).filter((i): i is SidebarItem => !!i);
    
    return finalStructure;

}, [searchTerm]);

  useEffect(() => {
    // When activeView changes, expand the relevant subgroup
    const { module: activeModuleId, subView: activeSubViewId } = activeView;
    const allModules = sidebarStructure.flatMap(item => item.type === 'module' ? [item] : (item.type === 'group' ? item.modules : []));
    const activeModule = allModules.find(m => m.id === activeModuleId);

    if (activeModule && activeSubViewId) {
      const parentSubgroup = activeModule.subViews.find(sv => 'type' in sv && sv.type === 'subgroup' && sv.subViews.some(s => s.id === activeSubViewId)) as SubViewGroup | undefined;
      if (parentSubgroup) {
        const subGroupId = `${activeModuleId}-${parentSubgroup.label}`;
        setExpandedSubgroups(prev => ({ ...prev, [subGroupId]: true }));
      }
    }
  }, [activeView]);


  const handleNavigation = (view: ActiveView) => {
    onNavigate(view);
    const group = findActiveGroup(view.module);
    setExpandedGroup(group?.id || null);
    setExpandedModule(view.module);
    
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };
  
  const handleModuleToggle = (moduleId: Module) => {
      setExpandedModule(prev => (prev === moduleId ? null : moduleId));
  };
  
  const handleGroupToggle = (groupId: string) => {
    setExpandedGroup(prev => (prev === groupId ? null : groupId));
  };
  
  const handleSubgroupToggle = (subGroupId: string) => {
    setExpandedSubgroups(prev => ({ ...prev, [subGroupId]: !prev[subGroupId] }));
  };

  const renderModule = (mod: ModuleItem, isSubItem: boolean = false) => {
    const isModuleActive = activeView.module === mod.id;
    const isModuleTheDirectTarget = isModuleActive && !activeView.subView;
    const isModuleAnActiveParent = isModuleActive && activeView.subView;
    const isExpanded = !!searchTerm.trim() || expandedModule === mod.id;
    const shouldHighlightAsParent = isModuleAnActiveParent || isExpanded;
    
    return (
        <div key={mod.id}>
            <a
                href="#"
                onClick={(e) => { e.preventDefault(); handleModuleToggle(mod.id); }}
                className={`flex items-center justify-between w-full px-4 py-3 transition-colors duration-200 transform rounded-lg 
                    ${isModuleTheDirectTarget
                        ? 'bg-custom-blue-primary text-white'
                        : shouldHighlightAsParent
                        ? 'bg-custom-blue-light/60 dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold'
                        : `text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700 ${isSubItem ? 'py-2' : ''}`
                    }`
                }
            >
                <div className="flex items-center">
                    {mod.icon}
                    <span className="mx-4 font-medium">{mod.label}</span>
                </div>
                {mod.subViews && mod.subViews.length > 0 && (
                    <svg className={`w-5 h-5 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                )}
            </a>
            {isExpanded && mod.subViews && mod.subViews.length > 0 && (
                <div className="mt-2 space-y-1 pr-4 mr-4 border-r-2 border-slate-200 dark:border-slate-600">
                    {/* FIX: Use if/else to correctly handle union type and prevent accessing properties on the wrong type. Also strongly typed map callbacks. */}
                    {mod.subViews.map((subEntry: SubViewEntry) => {
                        if ('type' in subEntry && subEntry.type === 'subgroup') {
                            const subgroup = subEntry;
                            const subGroupId = `${mod.id}-${subgroup.label}`;
                            const isSubgroupExpanded = !!searchTerm.trim() || !!expandedSubgroups[subGroupId];
                            const isSubgroupActive = isModuleActive && isSubViewInGroup(subgroup, activeView.subView);

                            return (
                                <div key={subGroupId}>
                                    <a
                                        href="#"
                                        onClick={(e) => { e.preventDefault(); handleSubgroupToggle(subGroupId); }}
                                        className={`flex items-center justify-between w-full px-4 py-2 text-sm rounded-lg transition-colors duration-200 ${
                                            isSubgroupActive
                                            ? 'bg-custom-blue-light/20 dark:bg-slate-700/50 text-custom-blue-primary dark:text-custom-blue-light font-medium'
                                            : 'text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700'
                                        }`}
                                    >
                                       <span>{subgroup.label}</span>
                                       <svg className={`w-4 h-4 transition-transform duration-200 ${isSubgroupExpanded ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                       </svg>
                                    </a>
                                    {isSubgroupExpanded && (
                                        <div className="mt-1 space-y-1 pr-2 mr-2 border-r border-slate-200 dark:border-slate-600">
                                            {subgroup.subViews.map((sub: SubViewSimple) => {
                                                const isSubViewActive = isModuleActive && activeView.subView === sub.id;
                                                return (
                                                    <a
                                                        key={sub.id}
                                                        href="#"
                                                        onClick={(e) => { e.preventDefault(); handleNavigation({ module: mod.id, subView: sub.id }); }}
                                                        className={`block px-4 py-2 text-sm rounded-lg transition-colors duration-200 ${
                                                            isSubViewActive
                                                            ? 'font-semibold bg-custom-blue-primary text-white shadow-inner'
                                                            : 'text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700'
                                                        }`}
                                                    >
                                                        {sub.label}
                                                    </a>
                                                )
                                            })}
                                        </div>
                                    )}
                                </div>
                            );
                        } else {
                            const sub = subEntry as SubViewSimple;
                            const isSubViewActive = isModuleActive && activeView.subView === sub.id;
                            return (
                                 <a
                                    key={sub.id}
                                    href="#"
                                    onClick={(e) => { e.preventDefault(); handleNavigation({ module: mod.id, subView: sub.id }); }}
                                    className={`block px-4 py-2 text-sm rounded-lg transition-colors duration-200 ${
                                        isSubViewActive
                                        ? 'font-semibold bg-custom-blue-primary text-white shadow-inner'
                                        : 'text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700'
                                    }`}
                                >
                                    {sub.label}
                                </a>
                            )
                        }
                    })}
                </div>
            )}
        </div>
    );
  }

  return (
    <aside
        className={`flex-shrink-0 flex-col w-72 px-4 py-8 overflow-y-auto bg-white border-l rtl:border-l-0 rtl:border-r dark:bg-slate-800 dark:border-slate-700 ${
            isSidebarOpen ? 'flex' : 'hidden'
        } md:flex`}
    >
        <div className="flex items-center justify-between">
            <a href="#" className="text-2xl font-semibold text-slate-800 dark:text-white">
                حسابداری
            </a>
            <button className="md:hidden" onClick={() => setSidebarOpen(false)}>
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <div className="relative mt-6">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 rtl:pl-0 rtl:pr-3 pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                </svg>
            </span>
            <input 
                type="text" 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full py-2 pl-10 pr-4 rtl:pr-10 rtl:pl-4 text-slate-700 bg-white border rounded-md dark:bg-slate-900 dark:text-slate-300 dark:border-slate-600 focus:border-cyan-400 dark:focus:border-cyan-300 focus:ring-cyan-300 focus:ring-opacity-40 focus:outline-none focus:ring"
                placeholder="جستجو در منوها" 
            />
        </div>


        <div className="flex flex-col justify-between flex-1 mt-6">
          <nav className="space-y-2">
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); handleNavigation({ module: 'dashboard' }); }}
              className={`flex items-center px-4 py-3 transition-colors duration-200 transform rounded-lg ${
                activeView.module === 'dashboard'
                  ? 'bg-custom-blue-primary text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
              </svg>
              <span className="mx-4 font-medium">داشبورد</span>
            </a>
            
            {filteredStructure.map(item => {
                if(item.type === 'module') {
                    return renderModule(item);
                }
                if (item.type === 'group') {
                    const isGroupActive = findActiveGroup(activeView.module)?.id === item.id;
                    const isGroupExpanded = !!searchTerm.trim() || expandedGroup === item.id;
                    const shouldHighlightGroup = isGroupActive || isGroupExpanded;
                    return (
                        <div key={item.id}>
                            <a
                                href="#"
                                onClick={(e) => { e.preventDefault(); handleGroupToggle(item.id); }}
                                className={`flex items-center justify-between w-full px-4 py-3 transition-colors duration-200 transform rounded-lg ${
                                    shouldHighlightGroup
                                    ? 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-slate-100 font-bold'
                                    : 'text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700'
                                }`}
                            >
                                <div className="flex items-center">
                                    {item.icon}
                                    <span className="mx-4 font-medium">{item.label}</span>
                                </div>
                                <svg className={`w-5 h-5 transition-transform duration-200 ${isGroupExpanded ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                            </a>
                             {isGroupExpanded && (
                                <div className="mt-2 space-y-1 pr-4 mr-2 border-r-2 border-slate-200 dark:border-slate-600">
                                   {item.modules.map(mod => renderModule(mod, true))}
                                </div>
                            )}
                        </div>
                    )
                }
                return null;
            })}

          </nav>
            <div className="mt-auto">
                <div className="flex items-center justify-around p-2 border-t dark:border-slate-700">
                     <button 
                        onClick={onOpenSiteMap}
                        className="p-3 transition-colors duration-200 transform rounded-full text-slate-600 dark:text-slate-400 hover:bg-custom-blue-light/50 dark:hover:bg-slate-700"
                        title="پلتفرم در یک نگاه"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                            <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
      </aside>
  );
};

export default Sidebar;