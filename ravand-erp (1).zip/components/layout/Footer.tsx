import React from 'react';
import type { FiscalYear } from '../../types';
import SearchableSelect from '../ui/SearchableSelect';

interface FooterProps {
    fiscalYears: FiscalYear[];
    activeFiscalYearId: number | null;
    setActiveFiscalYearId: (id: number | null) => void;
}

const Footer: React.FC<FooterProps> = ({ fiscalYears, activeFiscalYearId, setActiveFiscalYearId }) => {

    const fiscalYearOptions = fiscalYears.map(fy => ({
        value: fy.id,
        label: fy.title
    }));

    return (
        <footer className="flex-shrink-0 px-4 py-2 bg-white dark:bg-slate-800 border-t dark:border-slate-700 flex justify-between items-center text-xs text-slate-600 dark:text-slate-400">
            <div>
                <span>نسخه 1.3.1.1</span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <label htmlFor="active-fiscal-year">سال مالی فعال:</label>
                <div className="w-48">
                    <SearchableSelect
                        options={fiscalYearOptions}
                        value={activeFiscalYearId}
                        onChange={(val) => setActiveFiscalYearId(val as number | null)}
                        placeholder="انتخاب سال مالی..."
                    />
                </div>
            </div>
        </footer>
    );
};

export default Footer;
