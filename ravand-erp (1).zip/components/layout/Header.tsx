
import React from 'react';

interface HeaderProps {
  username: string;
  setSidebarOpen: (isOpen: boolean) => void;
  setProfileModalOpen: (isOpen: boolean) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const SunIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
    </svg>
);

const MoonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
    </svg>
);


const Header: React.FC<HeaderProps> = ({ username, setSidebarOpen, setProfileModalOpen, darkMode, toggleDarkMode }) => {
  return (
    <header className="flex-shrink-0 flex items-center justify-between px-6 py-4 bg-white dark:bg-slate-800 border-b dark:border-slate-700">
      <div className="flex items-center">
        <button onClick={() => setSidebarOpen(true)} className="text-slate-500 focus:outline-none md:hidden">
          <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 6H20M4 12H20M4 18H11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      <div className="flex items-center space-x-4 rtl:space-x-reverse">
        <button 
            onClick={toggleDarkMode} 
            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 focus:outline-none"
            aria-label="Toggle dark mode"
        >
            {darkMode ? <SunIcon /> : <MoonIcon />}
        </button>

        <button onClick={() => setProfileModalOpen(true)} className="flex items-center focus:outline-none">
          <span className="font-medium text-slate-700 dark:text-slate-200">{username}</span>
          <img
            className="w-10 h-10 rounded-full object-cover mr-4"
            src="https://picsum.photos/100/100"
            alt="User avatar"
          />
        </button>
      </div>
    </header>
  );
};

export default Header;