
import React, { useState, useMemo, useEffect } from 'react';
import type { Warehouse, WarehouseType, Personnel } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';

// FIX: Add update and delete props to handle editing and removing warehouses.
interface DefineWarehouseProps {
    warehouses: Warehouse[];
    addWarehouse: (warehouse: Omit<Warehouse, 'id'>) => void;
    updateWarehouse: (warehouse: Warehouse) => void;
    deleteWarehouse: (warehouseId: number) => void;
    personnelList: Personnel[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary" />
    </div>
);

const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }> = ({ label, id, children, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <select id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary">
            {children}
        </select>
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
    <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const warehouseTypeLabels: Record<WarehouseType, string> = {
    raw_materials: 'مواد اولیه',
    wip: 'کالای در جریان ساخت',
    products: 'محصولات',
    used_goods: 'مستعملات',
    supplies: 'ملزومات',
    consignment: 'امانی',
    scrap: 'ضایعات',
    assets: 'اموال',
};

const EditWarehouseModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    warehouse: Warehouse | null;
    updateWarehouse: (warehouse: Warehouse) => void;
    personnelList: Personnel[];
}> = ({ isOpen, onClose, warehouse, updateWarehouse, personnelList }) => {
    const [formData, setFormData] = useState<Warehouse | null>(null);

    useEffect(() => {
        setFormData(warehouse);
    }, [warehouse]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        if (formData) {
            setFormData({ ...formData, [e.target.name]: e.target.value });
        }
    };
    
    const handleSelectChange = (name: string, value: string | number | null) => {
         if (formData) {
            setFormData({ ...formData, [name]: value });
        }
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateWarehouse(formData);
        }
        onClose();
    };

    const personnelOptions = useMemo(() => 
        personnelList.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName}` })),
    [personnelList]);

    if (!isOpen || !formData) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش انبار: ${warehouse?.name}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <FormInput label="کد انبار" name="code" value={formData.code} onChange={handleChange} required />
                <FormInput label="نام انبار" name="name" value={formData.name} onChange={handleChange} required />
                <FormSelect label="نوع انبار" name="type" value={formData.type} onChange={handleChange} required>
                    {Object.entries(warehouseTypeLabels).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                    ))}
                </FormSelect>
                <CustomFormSelect label="مسئول انبار">
                    <SearchableSelect options={personnelOptions} value={formData.managerId} onChange={val => handleSelectChange('managerId', val)} placeholder="انتخاب پرسنل..."/>
                </CustomFormSelect>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};


const DefineWarehouse: React.FC<DefineWarehouseProps> = ({ warehouses, addWarehouse, updateWarehouse, deleteWarehouse, personnelList }) => {
    const initialState = {
        code: '',
        name: '',
        type: 'raw_materials' as WarehouseType,
        managerId: null as number | null,
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedWarehouse, setSelectedWarehouse] = useState<Warehouse | null>(null);
    
    const personnelMap = useMemo(() =>
        personnelList.reduce((map, p) => {
            map[p.id] = `${p.firstName} ${p.lastName}`;
            return map;
        }, {} as Record<number, string>),
    [personnelList]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSelectChange = (name: string, value: string | number | null) => {
        setFormData({ ...formData, [name]: value });
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addWarehouse(formData);
        setFormData(initialState); // Reset form
        alert('انبار جدید با موفقیت ذخیره شد.');
    };
    
    const personnelOptions = useMemo(() => 
        personnelList.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName}` })),
    [personnelList]);
    
    const handleOpenEditModal = (warehouse: Warehouse) => {
        setSelectedWarehouse(warehouse);
        setEditModalOpen(true);
    };

    const handleDelete = (warehouseId: number) => {
        if (window.confirm('آیا از حذف این انبار اطمینان دارید؟')) {
            deleteWarehouse(warehouseId);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف انبار</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <FormInput label="کد انبار" id="code" name="code" type="text" value={formData.code} onChange={handleChange} required />
                        <FormInput label="نام انبار" id="name" name="name" type="text" value={formData.name} onChange={handleChange} required />
                        <FormSelect label="نوع انبار" id="type" name="type" value={formData.type} onChange={handleChange} required>
                            {Object.entries(warehouseTypeLabels).map(([key, label]) => (
                                <option key={key} value={key}>{label}</option>
                            ))}
                        </FormSelect>
                        <CustomFormSelect label="مسئول انبار">
                            <SearchableSelect options={personnelOptions} value={formData.managerId} onChange={val => handleSelectChange('managerId', val)} placeholder="انتخاب پرسنل..."/>
                        </CustomFormSelect>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-custom-blue-primary">
                            ذخیره انبار
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">انبارهای تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">کد انبار</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">نام انبار</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">نوع انبار</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مسئول انبار</th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {warehouses.length > 0 ? (
                            warehouses.map((wh) => (
                                <tr key={wh.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{wh.code}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{wh.name}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{warehouseTypeLabels[wh.type]}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{wh.managerId ? personnelMap[wh.managerId] : '-'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(wh)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(wh.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={5} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز انباری تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
             <EditWarehouseModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                warehouse={selectedWarehouse}
                updateWarehouse={updateWarehouse}
                personnelList={personnelList}
            />
        </div>
    );
};

export default DefineWarehouse;
