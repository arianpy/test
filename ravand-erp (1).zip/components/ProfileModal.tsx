
import React, { useState } from 'react';
import Modal from './ui/Modal';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  setChangePasswordModalOpen: (isOpen: boolean) => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, setChangePasswordModalOpen }) => {
    // Mock user data
    const [username, setUsername] = useState('کاربر تست');
    const [email, setEmail] = useState('testuser@example.com');
    const [mobile, setMobile] = useState('09123456789');
    const [password, setPassword] = useState('************');
 
    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically handle the form submission, e.g., API call
        console.log({ username, email, mobile });
        onClose();
    };

    const handleChangePasswordClick = () => {
        onClose(); // Close this modal
        setChangePasswordModalOpen(true); // Open the change password modal
    };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="اطلاعات کاربری">
        <form onSubmit={handleSave}>
            <div className="flex flex-col items-center space-y-4">
                 <div className="relative">
                    <img
                        className="w-32 h-32 rounded-full object-cover border-4 border-slate-200 dark:border-slate-600"
                        src="https://picsum.photos/200/200"
                        alt="User avatar"
                    />
                     <button type="button" className="absolute bottom-0 right-0 bg-custom-blue-primary rounded-full p-2 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-custom-blue-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 20 20" fill="currentColor">
                           <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                           <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
                        </svg>
                    </button>
                </div>
                
                <div className="w-full pt-4 space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">نام کاربری</label>
                        <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">ایمیل</label>
                        <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">شماره موبایل</label>
                        <input
                        type="tel"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">رمز عبور</label>
                        <input
                        type="password"
                        value={password}
                        readOnly
                        className="mt-1 block w-full px-3 py-2 bg-slate-100 dark:bg-slate-700/50 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none"
                        />
                    </div>
                </div>

                <div className="w-full flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                    لغو
                    </button>
                    {/* FIX: Corrected button type to "button" to avoid form submission. */}
                    <button type="button" onClick={handleChangePasswordClick} className="px-4 py-2 text-sm font-medium text-white bg-amber-500 rounded-md hover:bg-amber-600">
                    تغییر رمز عبور
                    </button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">
                    ذخیره تغییرات
                    </button>
                </div>
            </div>
        </form>
    </Modal>
  );
};

export default ProfileModal;