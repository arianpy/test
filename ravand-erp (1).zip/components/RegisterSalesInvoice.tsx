import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
// FIX: Corrected type import for Auditable to resolve type errors.
import type { SalesInvoice, SalesInvoiceItem, Person, Product, AccountHeadGroup, AutoDocSetting, Currency, FiscalYear, SalesInvoiceType } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import BulkImportSalesModal from './BulkImportSalesModal';

interface RegisterSalesInvoiceProps {
    title: string;
    invoices: SalesInvoice[];
    // FIX: Updated prop type to match what App.tsx provides, which is an object without Auditable fields.
    addInvoice: (invoice: Omit<SalesInvoice, 'id'>) => void;
    deleteInvoice: (id: number) => void;
    // FIX: Updated prop type to match what App.tsx provides, which is an object without Auditable fields.
    addInvoicesBatch: (invoices: Omit<SalesInvoice, 'id'>[]) => void;
    customers: Person[];
    items: Product[];
    accountHeads: AccountHeadGroup[];
    autoDocSetting?: AutoDocSetting;
    currencies: Currency[];
    fiscalYears: FiscalYear[];
    invoiceType: SalesInvoiceType;
}

const formatNumber = (num: number | undefined | null): string => {
    if (num === null || num === undefined) return '0';
    return new Intl.NumberFormat('en-US').format(num);
};

// Resizable Header Cell Component
const ResizableHeaderCell: React.FC<{
    title: string;
    width: number;
    onMouseDown: (e: React.MouseEvent) => void;
}> = ({ title, width, onMouseDown }) => (
    <th style={{ width: `${width}px`, minWidth: '150px' }} className="p-2 font-medium text-center relative group select-none border-l dark:border-slate-600">
        <div className="flex items-center justify-center h-full">
            {title}
        </div>
        <div
            onMouseDown={onMouseDown}
            className="absolute top-0 right-0 h-full w-4 cursor-col-resize select-none z-10"
        >
             <div className="h-full w-px bg-slate-400 dark:bg-slate-500 mx-auto group-hover:bg-custom-blue-primary group-hover:w-1 transition-all"></div>
        </div>
    </th>
);


const RegisterSalesInvoice: React.FC<RegisterSalesInvoiceProps> = ({ title, invoices, addInvoice, deleteInvoice, addInvoicesBatch, customers, items, accountHeads, autoDocSetting, currencies, fiscalYears, invoiceType }) => {
    
    const mainCurrency = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0].mainCurrency : 'IRR', [fiscalYears]);

    const getInitialState = () => ({
        orderNumber: '',
        docNumber: '',
        date: new Date().toISOString().split('T')[0],
        customerId: '',
        description: '',
        debtorSubLedgerId: '',
        creditorSubLedgerId: '',
        currencyCode: mainCurrency,
        exchangeRate: 1,
        tradeDiscount: '' as number | '',
    });

    const [formData, setFormData] = useState(getInitialState());
    const [invoiceItems, setInvoiceItems] = useState<Omit<SalesInvoiceItem, 'id'>[]>([]);
    const [isBulkModalOpen, setBulkModalOpen] = useState(false);
    
    useEffect(() => {
        if (autoDocSetting) {
            setFormData(prev => ({
                ...prev,
                debtorSubLedgerId: autoDocSetting.defaultDebtorSubLedgerId?.toString() || '',
                creditorSubLedgerId: autoDocSetting.defaultCreditorSubLedgerId?.toString() || '',
            }));
        }
        setFormData(prev => ({...prev, currencyCode: mainCurrency, exchangeRate: 1}));
    }, [autoDocSetting, mainCurrency]);


    const allSubLedgers = useMemo(() => {
        return accountHeads.flatMap(group => group.children.flatMap(ledger => ledger.children));
    }, [accountHeads]);
    
    const itemMap = useMemo(() => 
        items.reduce((map, item) => {
            map[item.id] = item;
            return map;
        }, {} as Record<number, Product>),
    [items]);

    const customerMap = useMemo(() => 
        customers.reduce((map, s) => {
            map[s.id] = s.personType === 'natural' ? `${s.firstName} ${s.lastName}` : s.registeredName;
            return map;
        }, {} as Record<number, string>),
    [customers]);
    
    const isForeignCurrency = useMemo(() => formData.currencyCode !== mainCurrency, [formData.currencyCode, mainCurrency]);
    
    // Column Resizing Logic
    const initialWidths = {
        item: 350,
        quantity: 180,
        unitPriceMain: 220,
        unitPriceInvoice: 220,
        subtotalMain: 240,
        subtotalInvoice: 240,
        discountPercent: 180,
        discountAmountMain: 220,
        discountAmountInvoice: 220,
        rowTotalMain: 240,
        rowTotalInvoice: 240,
        actions: 100
    };

    const [columnWidths, setColumnWidths] = useState(initialWidths);
    const resizingColumnRef = useRef<{ key: string; startX: number; startWidth: number } | null>(null);

    const handleMouseDown = useCallback((e: React.MouseEvent, key: string) => {
        e.preventDefault();
        resizingColumnRef.current = {
            key,
            startX: e.clientX,
            startWidth: columnWidths[key as keyof typeof columnWidths],
        };
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
    }, [columnWidths]);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!resizingColumnRef.current) return;
        const { key, startX, startWidth } = resizingColumnRef.current;
        const deltaX = e.clientX - startX;
        const newWidth = Math.max(startWidth - deltaX, 150); 
        setColumnWidths(prev => ({ ...prev, [key]: newWidth }));
    }, []);

    const handleMouseUp = useCallback(() => {
        resizingColumnRef.current = null;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
    }, []);
    
    useEffect(() => {
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [handleMouseMove, handleMouseUp]);
    
    const tableHeaders = useMemo(() => {
        const mainCurrencyCode = mainCurrency;
        const invoiceCurrencyCode = formData.currencyCode;
        
        const headers: { key: string, title: string }[] = [
            { key: 'item', title: 'کالا' },
            { key: 'quantity', title: 'تعداد' },
            { key: 'unitPriceMain', title: `فی (${mainCurrencyCode})` },
        ];
        if (isForeignCurrency) headers.push({ key: 'unitPriceInvoice', title: `فی (${invoiceCurrencyCode})` });
        headers.push({ key: 'subtotalMain', title: `جمع کل پیش از تخفیف (${mainCurrencyCode})` });
        if (isForeignCurrency) headers.push({ key: 'subtotalInvoice', title: `جمع کل پیش از تخفیف (${invoiceCurrencyCode})` });
        headers.push({ key: 'discountPercent', title: 'تخفیف (%)' });
        headers.push({ key: 'discountAmountMain', title: `مبلغ تخفیف (${mainCurrencyCode})` });
        if (isForeignCurrency) headers.push({ key: 'discountAmountInvoice', title: `مبلغ تخفیف (${invoiceCurrencyCode})` });
        headers.push({ key: 'rowTotalMain', title: `جمع نهایی (${mainCurrencyCode})` });
        if (isForeignCurrency) headers.push({ key: 'rowTotalInvoice', title: `جمع نهایی (${invoiceCurrencyCode})` });
        headers.push({ key: 'actions', title: 'عملیات' });
        return headers;
    }, [isForeignCurrency, mainCurrency, formData.currencyCode]);

    const totalTableWidth = useMemo(() => {
        return tableHeaders.reduce((sum, header) => sum + columnWidths[header.key as keyof typeof columnWidths], 0);
    }, [columnWidths, tableHeaders]);


    const handleHeaderChange = (field: keyof typeof formData, value: any) => {
        const newFormData = {...formData, [field]: value};
        if (field === 'currencyCode' && value === mainCurrency) {
            newFormData.exchangeRate = 1;
        }
        setFormData(newFormData);
    };

    const handleAddItem = () => {
        setInvoiceItems(prev => [...prev, { productId: 0, quantity: 1, unitPrice: 0, discount: 0 }]);
    };
    
    const handleItemChange = (index: number, field: keyof Omit<SalesInvoiceItem, 'id'>, value: string | number) => {
        const newItems = [...invoiceItems];
        (newItems[index] as any)[field] = value;
        
        if (field === 'productId' && itemMap[Number(value)]) {
            newItems[index].unitPrice = itemMap[Number(value)].cost;
        }

        setInvoiceItems(newItems);
    };

    const handleRemoveItem = (index: number) => {
        setInvoiceItems(prev => prev.filter((_, i) => i !== index));
    };

    const calculatedRows = useMemo(() => {
        return invoiceItems.map(item => {
            const exchangeRate = Number(formData.exchangeRate) || 1;
            const unitPriceMain = Number(item.unitPrice) || 0;
            const quantity = Number(item.quantity) || 0;
            const discountPercent = Number(item.discount) || 0;
            const unitPriceInvoice = unitPriceMain * exchangeRate;
            const subtotalMain = quantity * unitPriceMain;
            const subtotalInvoice = subtotalMain * exchangeRate;
            const discountAmountMain = subtotalMain * (discountPercent / 100);
            const discountAmountInvoice = discountAmountMain * exchangeRate;
            const rowTotalMain = subtotalMain - discountAmountMain;
            const rowTotalInvoice = rowTotalMain * exchangeRate;
            
            return {
                ...item, unitPriceMain, unitPriceInvoice, subtotalMain, subtotalInvoice,
                discountAmountMain, discountAmountInvoice, rowTotalMain,
                rowTotalInvoice
            };
        });
    }, [invoiceItems, formData.exchangeRate]);

    const totals = useMemo(() => {
        const totalBeforeTradeDiscountMain = calculatedRows.reduce((sum, row) => sum + row.rowTotalMain, 0);
        const totalBeforeTradeDiscountInvoice = calculatedRows.reduce((sum, row) => sum + row.rowTotalInvoice, 0);
        
        const tradeDiscountMain = Number(formData.tradeDiscount) || 0;
        const tradeDiscountInvoice = tradeDiscountMain * (Number(formData.exchangeRate) || 1);

        const finalTotalMain = totalBeforeTradeDiscountMain - tradeDiscountMain;
        const finalTotalInvoice = totalBeforeTradeDiscountInvoice - tradeDiscountInvoice;

        return { totalBeforeTradeDiscountMain, totalBeforeTradeDiscountInvoice, tradeDiscountMain, tradeDiscountInvoice, finalTotalMain, finalTotalInvoice };
    }, [calculatedRows, formData.tradeDiscount, formData.exchangeRate]);
    

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (invoices.some(inv => inv.docNumber === formData.docNumber && inv.docNumber.trim() !== '')) {
            alert('شماره فاکتور تکراری است. لطفا شماره دیگری وارد کنید.');
            return;
        }

        if (!formData.customerId || invoiceItems.length === 0 || invoiceItems.some(i => !i.productId)) {
            alert('لطفا مشتری و حداقل یک قلم کالا معتبر را مشخص کنید.');
            return;
        }
// FIX: Added auditable properties to satisfy the SalesInvoice type.
        addInvoice({
            invoiceType: invoiceType,
            orderNumber: formData.orderNumber,
            docNumber: formData.docNumber,
            date: formData.date,
            customerId: Number(formData.customerId),
            description: formData.description,
            debtorSubLedgerId: formData.debtorSubLedgerId ? Number(formData.debtorSubLedgerId) : null,
            creditorSubLedgerId: formData.creditorSubLedgerId ? Number(formData.creditorSubLedgerId) : null,
            items: invoiceItems.map(item => ({ ...item, id: Date.now() + Math.random() })),
            currencyCode: formData.currencyCode,
            exchangeRate: Number(formData.exchangeRate),
            tradeDiscount: Number(formData.tradeDiscount) || 0,
            createdAt: new Date().toISOString(),
            createdBy: 'کاربر تست',
            updatedAt: new Date().toISOString(),
            updatedBy: 'کاربر تست',
        });
        setFormData(getInitialState());
        setInvoiceItems([]);
        alert('فاکتور فروش با موفقیت ثبت شد.');
    };

    return (
        <div className="space-y-6">
             <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>
                <button
                    type="button"
                    onClick={() => setBulkModalOpen(true)}
                    className="flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L6.293 6.707z" clipRule="evenodd" />
                    </svg>
                    بارگذاری گروهی
                </button>
            </div>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Header */}
                    <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end">
                            <FormInput label="شماره سفارش" name="orderNumber" value={formData.orderNumber} onChange={e => handleHeaderChange('orderNumber', e.target.value)} />
                            <FormInput label="شماره فاکتور" name="docNumber" value={formData.docNumber} onChange={e => handleHeaderChange('docNumber', e.target.value)} required />
                            <FormInput label="تاریخ" name="date" type="date" value={formData.date} onChange={e => handleHeaderChange('date', e.target.value)} required />
                             <CustomFormSelect label="مشتری">
                                <SearchableSelect options={customers.map(s => ({ value: s.id, label: s.personType === 'natural' ? `${s.firstName} ${s.lastName}` : s.registeredName }))} value={formData.customerId} onChange={val => handleHeaderChange('customerId', val)} placeholder="انتخاب مشتری..." />
                            </CustomFormSelect>
                             <CustomFormSelect label="معین بدهکار">
                                <SearchableSelect options={allSubLedgers.map(s => ({ value: s.id, label: s.title }))} value={formData.debtorSubLedgerId} onChange={val => handleHeaderChange('debtorSubLedgerId', val)} disabled={!autoDocSetting?.isDebtorEditable} />
                            </CustomFormSelect>
                             <CustomFormSelect label="معین بستانکار">
                                <SearchableSelect options={allSubLedgers.map(s => ({ value: s.id, label: s.title }))} value={formData.creditorSubLedgerId} onChange={val => handleHeaderChange('creditorSubLedgerId', val)} disabled={!autoDocSetting?.isCreditorEditable} />
                            </CustomFormSelect>
                             <CustomFormSelect label="ارز فاکتور">
                                <SearchableSelect options={currencies.map(c => ({ value: c.code, label: c.name }))} value={formData.currencyCode} onChange={val => handleHeaderChange('currencyCode', val)} />
                            </CustomFormSelect>
                            {isForeignCurrency && (
                                 <FormInput label="نرخ تبدیل" name="exchangeRate">
                                    <FormattedNumberInput
                                        value={formData.exchangeRate}
                                        onValueChange={val => handleHeaderChange('exchangeRate', val)}
                                        className="w-full mt-1 block px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"
                                    />
                                 </FormInput>
                            )}
                        </div>
                        <FormInput label="شرح کلی فاکتور" name="description" as="textarea" rows={2} value={formData.description} onChange={e => handleHeaderChange('description', e.target.value)} />
                    </div>

                    {/* Items Table */}
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold">اقلام فاکتور</h3>
                            <button type="button" onClick={handleAddItem} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن ردیف</button>
                        </div>
                        <div className="overflow-x-auto border dark:border-slate-700 rounded-lg">
                            <table className="text-sm" style={{ width: `${totalTableWidth}px`, minWidth: '100%' }}>
                                <thead className="bg-slate-100 dark:bg-slate-700/50">
                                    <tr>
                                        {tableHeaders.map(h => (
                                            <ResizableHeaderCell 
                                                key={h.key}
                                                title={h.title}
                                                width={columnWidths[h.key as keyof typeof columnWidths]}
                                                onMouseDown={(e) => handleMouseDown(e, h.key)}
                                            />
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {calculatedRows.map((row, index) => (
                                        <tr key={index} className="divide-x divide-slate-200 dark:divide-slate-600 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                            {tableHeaders.map(header => {
                                                const cellKey = header.key;
                                                const width = columnWidths[cellKey as keyof typeof columnWidths];
                                                
                                                const cellContent = () => {
                                                    switch(cellKey) {
                                                        case 'item': return <SearchableSelect options={items.map(i => ({ value: i.id, label: `${i.code} - ${i.title}` }))} value={row.productId} onChange={val => handleItemChange(index, 'productId', val as number)} placeholder="انتخاب کالا..." />;
                                                        case 'quantity': return <FormattedNumberInput value={row.quantity} onValueChange={val => handleItemChange(index, 'quantity', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600 text-center" />;
                                                        case 'unitPriceMain': return <FormattedNumberInput value={row.unitPrice} onValueChange={val => handleItemChange(index, 'unitPrice', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600 text-center" />;
                                                        case 'discountPercent': return <FormattedNumberInput value={row.discount} onValueChange={val => handleItemChange(index, 'discount', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600 text-center" />;
                                                        case 'unitPriceInvoice': return <div className="p-2 font-mono">{formatNumber(row.unitPriceInvoice)}</div>;
                                                        case 'subtotalInvoice': return <div className="p-2 font-mono">{formatNumber(row.subtotalInvoice)}</div>;
                                                        case 'subtotalMain': return <div className="p-2 font-mono">{formatNumber(row.subtotalMain)}</div>;
                                                        case 'discountAmountInvoice': return <div className="p-2 font-mono">{formatNumber(row.discountAmountInvoice)}</div>;
                                                        case 'discountAmountMain': return <div className="p-2 font-mono">{formatNumber(row.discountAmountMain)}</div>;
                                                        case 'rowTotalInvoice': return <div className="p-2 font-mono font-semibold">{formatNumber(row.rowTotalInvoice)}</div>;
                                                        case 'rowTotalMain': return <div className="p-2 font-mono font-semibold">{formatNumber(row.rowTotalMain)}</div>;
                                                        case 'actions': return <button type="button" onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900">&times;</button>;
                                                        default: return null;
                                                    }
                                                };

                                                return (
                                                    <td key={cellKey} style={{ width: `${width}px` }} className="p-1 text-center align-middle">
                                                      {cellContent()}
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    {/* Totals */}
                    <div className="flex justify-end pt-4">
                        <div className="w-full md:w-2/3 lg:w-1/2 space-y-3">
                            <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                                <span className="font-semibold">جمع نهایی پیش از تخفیف تجاری ({mainCurrency})</span>
                                <span className="font-mono">{formatNumber(totals.totalBeforeTradeDiscountMain)}</span>
                            </div>
                            {isForeignCurrency && (
                                <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                                    <span className="font-semibold">جمع نهایی پیش از تخفیف تجاری ({formData.currencyCode})</span>
                                    <span className="font-mono">{formatNumber(totals.totalBeforeTradeDiscountInvoice)}</span>
                                </div>
                            )}
                             <div className="flex justify-between items-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                                <span className="font-semibold pl-4">تخفیف تجاری ({mainCurrency})</span>
                                <div className="w-48">
                                    <FormattedNumberInput
                                        value={formData.tradeDiscount}
                                        onValueChange={val => handleHeaderChange('tradeDiscount', val)}
                                        className="w-full bg-white dark:bg-slate-700 p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600 text-center"
                                    />
                                </div>
                            </div>
                             {isForeignCurrency && (
                                <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                                    <span className="font-semibold">تخفیف تجاری ({formData.currencyCode})</span>
                                    <span className="font-mono">{formatNumber(totals.tradeDiscountInvoice)}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-center p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-lg border-t-2 dark:border-slate-600">
                                <span className="font-bold">جمع نهایی فاکتور ({mainCurrency})</span>
                                <span className="font-bold font-mono">{formatNumber(totals.finalTotalMain)}</span>
                            </div>
                             {isForeignCurrency && (
                                <div className="flex justify-between items-center p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-lg">
                                    <span className="font-bold">جمع نهایی فاکتور ({formData.currencyCode})</span>
                                    <span className="font-bold font-mono">{formatNumber(totals.finalTotalInvoice)}</span>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره فاکتور</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فاکتورهای ثبت شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">شماره فاکتور</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">تاریخ</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">مشتری</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">مبلغ نهایی ({mainCurrency})</th>
                                <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {invoices.filter(inv => inv.invoiceType === invoiceType).length > 0 ? (
                                invoices.filter(inv => inv.invoiceType === invoiceType).map(invoice => {
                                    const total = invoice.items.reduce((sum, item) => {
                                        const subtotal = item.quantity * item.unitPrice;
                                        const discountAmount = subtotal * (item.discount / 100);
                                        const subtotalAfterDiscount = subtotal - discountAmount;
                                        return sum + subtotalAfterDiscount;
                                    }, 0);
                                    const finalTotal = total - invoice.tradeDiscount;
                                    
                                    return (
                                        <tr key={invoice.id}>
                                            <td className="px-6 py-4 whitespace-nowrap">{invoice.docNumber}</td>
                                            <td className="px-6 py-4 whitespace-nowrap">{new Date(invoice.date).toLocaleDateString('fa-IR')}</td>
                                            <td className="px-6 py-4 whitespace-nowrap">{customerMap[invoice.customerId] || 'نامشخص'}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-left font-mono">{`${formatNumber(finalTotal)}`}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-center">
                                                <button onClick={() => deleteInvoice(invoice.id)} className="text-red-500 hover:text-red-700 text-sm">حذف</button>
                                            </td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-4 text-slate-500 dark:text-slate-400">فاکتوری ثبت نشده است.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

             <BulkImportSalesModal
                isOpen={isBulkModalOpen}
                onClose={() => setBulkModalOpen(false)}
                addInvoicesBatch={addInvoicesBatch}
                customers={customers}
                items={items}
            />
        </div>
    );
};

// Wrapper components for consistent styling
type FormInputProps = {
    label: string;
} & (
    | ({ as?: 'input' } & React.InputHTMLAttributes<HTMLInputElement>)
    | ({ as: 'textarea' } & React.TextareaHTMLAttributes<HTMLTextAreaElement>)
    | ({ as?: never; children: React.ReactNode } & { name: string; id?: string; })
);

const FormInput: React.FC<FormInputProps> = ({ label, as = 'input', children, ...props }) => {
    const commonClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary";
    return (
        <div>
            <label htmlFor={props.id || props.name} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
            {children ? children : (as === 'textarea' ? <textarea {...(props as React.TextareaHTMLAttributes<HTMLTextAreaElement>)} className={commonClasses} /> : <input {...(props as React.InputHTMLAttributes<HTMLInputElement>)} className={commonClasses} />)}
        </div>
    );
};

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);


export default RegisterSalesInvoice;
