

import React, { useState, useMemo, useEffect } from 'react';
// FIX: Added Auditable to the import to correctly type props.
import type { Campaign, Opportunity, Quotation, SalesInvoice, SalesNote, Person, Product, Currency, FiscalYear, SalesReminder, QuotationItem, SalesInvoiceItem, Auditable, CampaignMedia } from '../types';
import { CampaignStatus, OpportunityStatus, QuotationStatus } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';

// --- ICONS ---
const CampaignIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>;
const OpportunityIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>;
const QuotationIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" /><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" /></svg>;
const InvoiceIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" /><path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd" /></svg>;
const NoteIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>;
const ReminderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" /></svg>;

const TaskIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;
const ProcessIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>;

// --- MODAL COMPONENTS ---
const FormInput: React.FC<(React.InputHTMLAttributes<HTMLInputElement> | React.TextareaHTMLAttributes<HTMLTextAreaElement>) & { label: string, as?: 'input' | 'textarea' }> = ({ label, id, as = 'input', ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {as === 'textarea' ?
            <textarea id={id} {...props as React.TextareaHTMLAttributes<HTMLTextAreaElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" /> :
            <input id={id} {...props as React.InputHTMLAttributes<HTMLInputElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
        }
    </div>
);

// FIX: Corrected prop types for onSave and campaign to handle both new and existing items correctly, resolving type errors.
const CampaignModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (data: Campaign | Omit<Campaign, 'id' | keyof Auditable>) => void; campaign: Campaign | null; selectedDate: string; }> = ({ isOpen, onClose, onSave, campaign, selectedDate }) => {
    // FIX: Added missing 'media' property to initial state to match the Campaign type definition.
    const getInitialState = (): Omit<Campaign, 'id' | keyof Auditable> => ({ date: selectedDate, name: '', status: CampaignStatus.Planned, budget: 0, description: '', media: [] });
    const [formData, setFormData] = useState<Campaign | Omit<Campaign, 'id' | keyof Auditable>>(getInitialState());
    useEffect(() => { if (campaign) setFormData(campaign); else setFormData(getInitialState()); }, [campaign, isOpen, selectedDate]);
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSave(formData); };
    return <Modal isOpen={isOpen} onClose={onClose} title={campaign?.name ? "ویرایش کمپین" : "ایجاد کمپین"}><form onSubmit={handleSubmit} className="space-y-4"><FormInput label="نام کمپین" value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required /><div><label className="block text-sm font-medium">بودجه</label><FormattedNumberInput value={formData.budget} onValueChange={val => setFormData(p => ({ ...p, budget: val }))} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" /></div><div><label className="block text-sm font-medium">وضعیت</label><SearchableSelect options={Object.values(CampaignStatus).map(s => ({ value: s, label: s }))} value={formData.status} onChange={val => setFormData(p => ({ ...p, status: val as CampaignStatus }))} /></div><FormInput label="توضیحات" as="textarea" value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} /><div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600"><button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button><button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button></div></form></Modal>;
};

// FIX: Corrected prop types for onSave and opportunity to handle both new and existing items correctly, resolving type errors.
const OpportunityModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (data: Opportunity | Omit<Opportunity, 'id' | keyof Auditable>) => void; opportunity: Opportunity | null; customers: Person[]; selectedDate: string; }> = ({ isOpen, onClose, onSave, opportunity, customers, selectedDate }) => {
    const getInitialState = (): Omit<Opportunity, 'id' | keyof Auditable> => ({ date: selectedDate, name: '', customerId: 0, status: OpportunityStatus.Prospect, estimatedValue: 0, description: '' });
    const [formData, setFormData] = useState<Opportunity | Omit<Opportunity, 'id' | keyof Auditable>>(getInitialState());
    useEffect(() => { if (opportunity) setFormData(opportunity); else setFormData(getInitialState()); }, [opportunity, isOpen, selectedDate]);
    const customerOptions = useMemo(() => customers.map(c => ({ value: c.id, label: c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName })), [customers]);
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); if (!formData.customerId) { alert("لطفا مشتری را انتخاب کنید."); return; } onSave(formData); };
    return <Modal isOpen={isOpen} onClose={onClose} title={opportunity?.name ? "ویرایش فرصت فروش" : "ایجاد فرصت فروش"}> <form onSubmit={handleSubmit} className="space-y-4"><FormInput label="عنوان فرصت" value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required /><div><label className="block text-sm font-medium">مشتری</label><SearchableSelect options={customerOptions} value={formData.customerId} onChange={val => setFormData(p => ({ ...p, customerId: val as number }))} /></div><div><label className="block text-sm font-medium">ارزش تخمینی</label><FormattedNumberInput value={formData.estimatedValue} onValueChange={val => setFormData(p => ({ ...p, estimatedValue: val }))} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" /></div><div><label className="block text-sm font-medium">وضعیت</label><SearchableSelect options={Object.values(OpportunityStatus).map(s => ({ value: s, label: s }))} value={formData.status} onChange={val => setFormData(p => ({ ...p, status: val as OpportunityStatus }))} /></div><FormInput label="توضیحات" as="textarea" value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} /><div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600"><button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button><button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button></div></form></Modal>;
};

// FIX: Corrected prop types for onSave and quotation to handle both new and existing items correctly, resolving type errors.
const QuotationModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (data: Quotation | Omit<Quotation, 'id' | keyof Auditable>) => void; quotation: Quotation | null; customers: Person[], products: Product[], selectedDate: string; }> = ({ isOpen, onClose, onSave, quotation, customers, products, selectedDate }) => {
    const getInitialState = (): Omit<Quotation, 'id' | keyof Auditable> => ({date: selectedDate, quotationNumber: `QT-${Date.now().toString().slice(-6)}`, customerId: 0, status: QuotationStatus.Draft, items: [], totalAmount: 0, description: ''});
    const [formData, setFormData] = useState<Quotation | Omit<Quotation, 'id' | keyof Auditable>>(getInitialState());
    useEffect(() => { if (quotation) setFormData(quotation); else setFormData(getInitialState()); }, [quotation, isOpen, selectedDate]);
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSave(formData); };
    return <Modal isOpen={isOpen} onClose={onClose} title="ایجاد/ویرایش پیش فاکتور"><p className='text-center p-8'>در حال توسعه...</p></Modal>; // Simplified for now
};

// FIX: Corrected prop types for onSave and note to handle both new and existing items correctly, resolving type errors.
const SalesNoteModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (data: SalesNote | Omit<SalesNote, 'id' | keyof Auditable>) => void; note: SalesNote | null; selectedDate: string; }> = ({ isOpen, onClose, onSave, note, selectedDate }) => {
    const getInitialState = (): Omit<SalesNote, 'id' | keyof Auditable> => ({ date: selectedDate, title: '', content: '' });
    const [formData, setFormData] = useState<SalesNote | Omit<SalesNote, 'id' | keyof Auditable>>(getInitialState());
    useEffect(() => { if (note) setFormData(note); else setFormData(getInitialState()); }, [note, isOpen, selectedDate]);
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSave(formData); };
    return <Modal isOpen={isOpen} onClose={onClose} title={note?.title ? "ویرایش یادداشت" : "ایجاد یادداشت"}><form onSubmit={handleSubmit} className="space-y-4"><FormInput label="عنوان" value={formData.title} onChange={e => setFormData(p => ({ ...p, title: e.target.value }))} required /><FormInput label="متن یادداشت" as="textarea" rows={5} value={formData.content} onChange={e => setFormData(p => ({ ...p, content: e.target.value }))} /><div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600"><button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">لغو</button><button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره</button></div></form></Modal>;
};

// FIX: Corrected prop types for onSave and reminder to handle both new and existing items correctly, resolving type errors.
const ReminderModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (data: SalesReminder | Omit<SalesReminder, 'id' | keyof Auditable>) => void; reminder: SalesReminder | null; selectedDate: string; }> = ({ isOpen, onClose, onSave, reminder, selectedDate }) => {
    const getInitialState = (): Omit<SalesReminder, 'id' | keyof Auditable> => ({ date: selectedDate, title: '', content: '', remindAt: new Date().toISOString().slice(0, 16) });
    const [formData, setFormData] = useState<SalesReminder | Omit<SalesReminder, 'id' | keyof Auditable>>(getInitialState());
    useEffect(() => { if (reminder) setFormData(reminder); else setFormData(getInitialState()); }, [reminder, isOpen, selectedDate]);
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSave(formData); };
    return <Modal isOpen={isOpen} onClose={onClose} title={reminder?.title ? "ویرایش یادآوری" : "ایجاد یادآوری"}><form onSubmit={handleSubmit} className="space-y-4"><FormInput label="عنوان" value={formData.title} onChange={e => setFormData(p => ({ ...p, title: e.target.value }))} required /><FormInput label="زمان یادآوری" type="datetime-local" value={formData.remindAt} onChange={e => setFormData(p => ({ ...p, remindAt: e.target.value }))} /><FormInput label="متن" as="textarea" rows={4} value={formData.content} onChange={e => setFormData(p => ({ ...p, content: e.target.value }))} /><div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600"><button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">لغو</button><button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره</button></div></form></Modal>;
};


interface SalesTimelineProps {
    campaigns: Campaign[]; addCampaign: (c: Omit<Campaign, 'id' | keyof Auditable>) => void; updateCampaign: (c: Campaign) => void; deleteCampaign: (id: number) => void;
    opportunities: Opportunity[]; addOpportunity: (o: Omit<Opportunity, 'id' | keyof Auditable>) => void; updateOpportunity: (o: Opportunity) => void; deleteOpportunity: (id: number) => void;
    quotations: Quotation[]; addQuotation: (q: Omit<Quotation, 'id' | keyof Auditable>) => void; updateQuotation: (q: Quotation) => void; deleteQuotation: (id: number) => void;
    salesInvoices: SalesInvoice[]; addSalesInvoice: (i: Omit<SalesInvoice, 'id' | keyof Auditable>) => void;
    salesNotes: SalesNote[]; addSalesNote: (n: Omit<SalesNote, 'id' | keyof Auditable>) => void; updateSalesNote: (n: SalesNote) => void; deleteSalesNote: (id: number) => void;
    salesReminders: SalesReminder[]; addSalesReminder: (r: Omit<SalesReminder, 'id' | keyof Auditable>) => void; updateSalesReminder: (r: SalesReminder) => void; deleteSalesReminder: (id: number) => void;
    customers: Person[]; products: Product[]; currencies: Currency[]; fiscalYears: FiscalYear[];
}

const KarnameCard: React.FC<{ title: string, count: number, icon: React.ReactNode, className?: string }> = ({ title, count, icon, className }) => (
    <div className={`bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md flex items-center space-x-4 rtl:space-x-reverse ${className}`}>
        <div className="p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-slate-500 dark:text-slate-400 text-sm">{title}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{count}</p>
        </div>
    </div>
);

const ActivityItem: React.FC<{ icon: React.ReactNode, children: React.ReactNode, onEdit?: () => void, onDelete?: () => void, iconColor?: string }> = ({ icon, children, onEdit, onDelete, iconColor }) => (
    <div className="group flex justify-between items-center p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700/50 text-sm">
        <div className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
            <span className={iconColor || 'text-slate-400'}>{icon}</span>
            {children}
        </div>
        {(onEdit || onDelete) && ( <div className="opacity-0 group-hover:opacity-100 transition-opacity space-x-2 rtl:space-x-reverse"> {onEdit && <button onClick={onEdit} className="text-amber-500 hover:text-amber-700"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg></button>} {onDelete && <button onClick={onDelete} className="text-red-500 hover:text-red-700"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg></button>} </div> )}
    </div>
);


const SalesTimeline: React.FC<SalesTimelineProps> = (props) => {
    const { campaigns, opportunities, quotations, salesInvoices, salesNotes, salesReminders, customers } = props;
    const [calendarType, setCalendarType] = useState<'shamsi' | 'gregorian'>('shamsi');

    const calendarData = useMemo(() => {
        const persianMonths = [{ name: 'فروردین', days: 31 }, { name: 'اردیبهشت', days: 31 }, { name: 'خرداد', days: 31 }, { name: 'تیر', days: 31 }, { name: 'مرداد', days: 31 }, { name: 'شهریور', days: 31 }, { name: 'مهر', days: 30 }, { name: 'آبان', days: 30 }, { name: 'آذر', days: 30 }, { name: 'دی', days: 30 }, { name: 'بهمن', days: 30 }, { name: 'اسفند', days: 29 }];
        const startDate = new Date('2025-03-21T00:00:00Z');
        const calendar = [];
        let currentDate = new Date(startDate);
        for (const month of persianMonths) {
            const monthData = { name: month.name, days: [] as any[] };
            for (let day = 1; day <= month.days; day++) {
                monthData.days.push({ gregorianISO: currentDate.toISOString().split('T')[0], shamsiDisplay: `${day} ${month.name}`, gregorianDisplay: currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) });
                currentDate.setDate(currentDate.getDate() + 1);
            }
            calendar.push(monthData);
        }
        return calendar;
    }, []);

    const [selectedDate, setSelectedDate] = useState<string>('');
    const [modalState, setModalState] = useState({ campaign: false, opportunity: false, quotation: false, invoice: false, note: false, reminder: false });
    const [editingItem, setEditingItem] = useState<any>(null);

    const activitiesByDate = useMemo(() => {
        const map = new Map<string, any[]>();
        const addActivity = (item: any, type: string) => { const date = item.date.split('T')[0]; if (!map.has(date)) map.set(date, []); map.get(date)!.push({ ...item, type }); };
        campaigns.forEach(c => addActivity(c, 'campaign')); 
        opportunities.forEach(o => addActivity(o, 'opportunity'));
        quotations.forEach(q => addActivity(q, 'quotation'));
        salesInvoices.forEach(i => addActivity(i, 'invoice')); 
        salesNotes.forEach(n => addActivity(n, 'note')); 
        salesReminders.forEach(r => addActivity(r, 'reminder'));
        return map;
    }, [campaigns, opportunities, quotations, salesInvoices, salesNotes, salesReminders]);
    
    const customerMap = useMemo(() => new Map(customers.map(c => [c.id, c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName])), [customers]);

    const handleOpenModal = (type: keyof typeof modalState, date: string, itemToEdit?: any) => { setSelectedDate(date); setEditingItem(itemToEdit || null); setModalState(prev => ({ ...prev, [type]: true })); };
    const handleCloseModal = (type: keyof typeof modalState) => { setModalState(prev => ({ ...prev, [type]: false })); setEditingItem(null); };

    const handleSave = (type: keyof typeof modalState, data: any) => {
        const handlerMap = {
            campaign: { add: props.addCampaign, update: props.updateCampaign },
            opportunity: { add: props.addOpportunity, update: props.updateOpportunity },
            quotation: { add: props.addQuotation, update: props.updateQuotation },
            invoice: { add: props.addSalesInvoice, update: () => {} },
            note: { add: props.addSalesNote, update: props.updateSalesNote },
            reminder: { add: props.addSalesReminder, update: props.updateSalesReminder },
        };
        if ('id' in data) {
            handlerMap[type].update(data);
        } else {
            handlerMap[type].add(data);
        }
        handleCloseModal(type);
    };
    
    const iconColorMap: { [key: string]: string } = {
        campaign: 'text-purple-500',
        opportunity: 'text-green-500',
        quotation: 'text-blue-500',
        invoice: 'text-indigo-500',
        note: 'text-yellow-600 dark:text-yellow-400',
        reminder: 'text-red-500',
    };

    const actionButtons = [
        { type: 'campaign', title: 'افزودن کمپین', icon: <CampaignIcon /> },
        { type: 'opportunity', title: 'افزودن فرصت', icon: <OpportunityIcon /> },
        { type: 'quotation', title: 'افزودن پیش فاکتور', icon: <QuotationIcon /> },
        { type: 'invoice', title: 'افزودن فاکتور', icon: <InvoiceIcon /> },
        { type: 'note', title: 'افزودن یادداشت', icon: <NoteIcon /> },
        { type: 'reminder', title: 'افزودن یادآوری', icon: <ReminderIcon /> },
    ];


    return (
        <div className="p-6 bg-slate-50 dark:bg-slate-900/50">
             <div className="sticky top-0 bg-slate-50 dark:bg-slate-900/50 z-10 py-4 -mx-6 px-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <KarnameCard title="وظایف در انتظار انجام" count={5} icon={<TaskIcon />} className="border-l-4 border-cyan-400 [&>div:first-child]:bg-cyan-100 [&>div:first-child]:text-cyan-600 dark:[&>div:first-child]:bg-cyan-900/50 dark:[&>div:first-child]:text-cyan-300" />
                    <KarnameCard title="فرآیندهای در انتظار مشارکت" count={2} icon={<ProcessIcon />} className="border-l-4 border-sky-400 [&>div:first-child]:bg-sky-100 [&>div:first-child]:text-sky-600 dark:[&>div:first-child]:bg-sky-900/50 dark:[&>div:first-child]:text-sky-300" />
                </div>
                <div className="flex justify-center">
                    <div className="flex items-center space-x-2 rounded-full bg-slate-200 dark:bg-slate-700 p-1">
                        <button onClick={() => setCalendarType('shamsi')} className={`px-4 py-1 rounded-full text-sm transition-all duration-300 ${calendarType === 'shamsi' ? 'bg-white dark:bg-slate-800 shadow text-cyan-600 ring-1 ring-cyan-500' : 'text-slate-500 dark:text-slate-400'}`}>شمسی</button>
                        <button onClick={() => setCalendarType('gregorian')} className={`px-4 py-1 rounded-full text-sm transition-all duration-300 ${calendarType === 'gregorian' ? 'bg-white dark:bg-slate-800 shadow text-cyan-600 ring-1 ring-cyan-500' : 'text-slate-500 dark:text-slate-400'}`}>میلادی</button>
                    </div>
                </div>
            </div>

            <div className="container mx-auto w-full h-full pt-6">
                <div className="relative wrap overflow-hidden p-4 h-full">
                    <div className="absolute border-2 border-cyan-400 dark:border-cyan-500 h-full" style={{ left: '50%', transform: 'translateX(-50%)' }}></div>
                    {calendarData.map(month => (
                        <React.Fragment key={month.name}>
                            <div className="mb-8 flex justify-center items-center w-full"><div className="z-20 px-4 py-2 bg-sky-500 text-white rounded-lg shadow-md font-semibold">{month.name} ۱۴۰۴</div></div>
                            {month.days.map(day => {
                                const activitiesForThisDay = activitiesByDate.get(day.gregorianISO) || [];
                                const counts = {
                                    campaign: activitiesForThisDay.filter(a => a.type === 'campaign').length,
                                    opportunity: activitiesForThisDay.filter(a => a.type === 'opportunity').length,
                                    quotation: activitiesForThisDay.filter(a => a.type === 'quotation').length,
                                    invoice: activitiesForThisDay.filter(a => a.type === 'invoice').length,
                                    note: activitiesForThisDay.filter(a => a.type === 'note').length,
                                    reminder: activitiesForThisDay.filter(a => a.type === 'reminder').length,
                                };

                                return (
                                <div key={day.gregorianISO} className="mb-6 flex justify-between items-start w-full text-right">
                                    <div className={`order-1 w-[calc(50%-3rem)]`}>
                                        <Card className="p-3 text-center bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm"><span className="font-semibold text-lg">{calendarType === 'shamsi' ? day.shamsiDisplay : day.gregorianDisplay}</span></Card>
                                    </div>
                                    <div className={`z-20 flex items-center order-1 shadow-xl w-8 h-8 rounded-full transition-all duration-300 ${activitiesForThisDay.length > 0 ? 'bg-cyan-500' : 'bg-slate-300 dark:bg-slate-600'}`}></div>
                                    <div className="order-1 w-[calc(50%-3rem)]">
                                        <Card className={`p-3 transition-all duration-300 border-l-4 ${activitiesForThisDay.length > 0 ? 'border-cyan-400' : 'border-transparent'}`}>
                                            {activitiesForThisDay.map((activity: any) => (
                                                <React.Fragment key={`${activity.type}-${activity.id}`}>
                                                    {activity.type === 'campaign' && <ActivityItem icon={<CampaignIcon/>} iconColor={iconColorMap.campaign} onEdit={() => handleOpenModal('campaign', day.gregorianISO, activity)} onDelete={() => props.deleteCampaign(activity.id)}><span><strong>کمپین:</strong> {activity.name}</span></ActivityItem>}
                                                    {activity.type === 'opportunity' && <ActivityItem icon={<OpportunityIcon/>} iconColor={iconColorMap.opportunity} onEdit={() => handleOpenModal('opportunity', day.gregorianISO, activity)} onDelete={() => props.deleteOpportunity(activity.id)}><span><strong>فرصت:</strong> {activity.name} ({customerMap.get(activity.customerId) || 'ناشناس'})</span></ActivityItem>}
                                                    {activity.type === 'quotation' && <ActivityItem icon={<QuotationIcon/>} iconColor={iconColorMap.quotation} onEdit={() => handleOpenModal('quotation', day.gregorianISO, activity)} onDelete={() => props.deleteQuotation(activity.id)}><span><strong>پیش‌فاکتور:</strong> شماره {activity.quotationNumber}</span></ActivityItem>}
                                                    {activity.type === 'invoice' && <ActivityItem icon={<InvoiceIcon/>} iconColor={iconColorMap.invoice}><span><strong>فاکتور:</strong> شماره {activity.docNumber}</span></ActivityItem>}
                                                    {activity.type === 'note' && <ActivityItem icon={<NoteIcon/>} iconColor={iconColorMap.note} onEdit={() => handleOpenModal('note', day.gregorianISO, activity)} onDelete={() => props.deleteSalesNote(activity.id)}><span><strong>یادداشت:</strong> {activity.title}</span></ActivityItem>}
                                                    {activity.type === 'reminder' && <ActivityItem icon={<ReminderIcon/>} iconColor={iconColorMap.reminder} onEdit={() => handleOpenModal('reminder', day.gregorianISO, activity)} onDelete={() => props.deleteSalesReminder(activity.id)}><span><strong>یادآوری:</strong> {activity.title}</span></ActivityItem>}
                                                </React.Fragment>
                                            ))}
                                            <div className={`flex flex-wrap items-start justify-center gap-x-4 gap-y-2 ${activitiesForThisDay.length > 0 ? 'mt-2 pt-2 border-t border-slate-200 dark:border-slate-600' : ''}`}>
                                                {actionButtons.map(btn => (
                                                    <div key={btn.type} className="flex flex-col items-center">
                                                        <button title={btn.title} onClick={() => handleOpenModal(btn.type as any, day.gregorianISO)} className="p-2 text-slate-500 rounded-full bg-slate-100 hover:bg-cyan-100 hover:text-cyan-600 dark:bg-slate-700 dark:text-slate-400 dark:hover:bg-cyan-900/50 dark:hover:text-cyan-300 transition-colors">{btn.icon}</button>
                                                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-1">{counts[btn.type as keyof typeof counts]}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        </Card>
                                    </div>
                                </div>
                            )})}
                        </React.Fragment>
                    ))}
                </div>
            </div>

            {/* Modals */}
            <CampaignModal isOpen={modalState.campaign} onClose={() => handleCloseModal('campaign')} onSave={(d) => handleSave('campaign', d)} campaign={editingItem} selectedDate={selectedDate} />
            <OpportunityModal isOpen={modalState.opportunity} onClose={() => handleCloseModal('opportunity')} onSave={(d) => handleSave('opportunity', d)} opportunity={editingItem} customers={customers} selectedDate={selectedDate} />
            <QuotationModal isOpen={modalState.quotation} onClose={() => handleCloseModal('quotation')} onSave={(d) => handleSave('quotation', d)} quotation={editingItem} customers={props.customers} products={props.products} selectedDate={selectedDate} />
            <SalesNoteModal isOpen={modalState.note} onClose={() => handleCloseModal('note')} onSave={(d) => handleSave('note', d)} note={editingItem} selectedDate={selectedDate} />
            <ReminderModal isOpen={modalState.reminder} onClose={() => handleCloseModal('reminder')} onSave={(d) => handleSave('reminder', d)} reminder={editingItem} selectedDate={selectedDate} />
        </div>
    );
};

export default SalesTimeline;
