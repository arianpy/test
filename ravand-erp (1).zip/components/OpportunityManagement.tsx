
import React, { useState, useMemo, useEffect } from 'react';
import type { Opportunity, Person, Auditable } from '../types';
import { OpportunityStatus } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface OpportunityManagementProps {
    opportunities: Opportunity[];
    addOpportunity: (opportunity: Omit<Opportunity, 'id' | keyof Auditable>) => void;
    updateOpportunity: (opportunity: Opportunity) => void;
    deleteOpportunity: (id: number) => void;
    customers: Person[];
}

const OpportunityModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (opportunity: Opportunity | Omit<Opportunity, 'id' | keyof Auditable>) => void;
    initialData: Opportunity | null;
    customers: Person[];
}> = ({ isOpen, onClose, onSave, initialData, customers }) => {
    
    const getInitialState = (): Omit<Opportunity, 'id' | keyof Auditable> => ({
        date: new Date().toISOString().split('T')[0],
        name: '',
        customerId: 0,
        status: OpportunityStatus.Prospect,
        estimatedValue: 0,
        description: '',
    });

    const [formData, setFormData] = useState<Opportunity | Omit<Opportunity, 'id' | keyof Auditable>>(getInitialState());

    useEffect(() => {
        if (initialData) {
            setFormData({
                ...initialData,
                estimatedValue: initialData.estimatedValue || 0,
            });
        } else {
            setFormData(getInitialState());
        }
    }, [initialData, isOpen]);
    
    const customerOptions = useMemo(() => customers.map(c => ({ value: c.id, label: c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName })), [customers]);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if(!formData.customerId) {
            alert('لطفا مشتری را انتخاب کنید.');
            return;
        }
        const dataToSave = {
            ...formData,
            estimatedValue: Number(formData.estimatedValue) || 0,
        };
        onSave(dataToSave);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={initialData ? 'ویرایش فرصت فروش' : 'ایجاد فرصت فروش جدید'}>
            <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormInput label="عنوان فرصت" name="name" value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required />
                    <div>
                        <label className="block text-sm font-medium mb-1">تاریخ</label>
                        <ShamsiDatePicker value={formData.date} onChange={date => setFormData(p => ({...p, date}))} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">مشتری</label>
                        <SearchableSelect
                            options={customerOptions}
                            value={formData.customerId}
                            onChange={val => setFormData(p => ({ ...p, customerId: val as number }))}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">ارزش تخمینی</label>
                        <FormattedNumberInput
                            value={formData.estimatedValue}
                            onValueChange={val => setFormData(p => ({ ...p, estimatedValue: val }))}
                            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">وضعیت</label>
                        <SearchableSelect
                            options={Object.values(OpportunityStatus).map(s => ({ value: s, label: s }))}
                            value={formData.status}
                            onChange={val => setFormData(p => ({ ...p, status: val as OpportunityStatus }))}
                        />
                    </div>
                </div>
                <FormInput label="توضیحات" name="description" as="textarea" rows={3} value={formData.description} onChange={e => setFormData(p => ({...p, description: e.target.value}))} />
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره</button>
                </div>
            </form>
        </Modal>
    );
};


const OpportunityManagement: React.FC<OpportunityManagementProps> = ({ opportunities, addOpportunity, updateOpportunity, deleteOpportunity, customers }) => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [editingOpportunity, setEditingOpportunity] = useState<Opportunity | null>(null);
    const customerMap = useMemo(() => new Map(customers.map(c => [c.id, c.personType === 'natural' ? `${c.firstName} ${c.lastName}` : c.registeredName])), [customers]);

    const handleOpenModal = (opportunity: Opportunity | null = null) => {
        setEditingOpportunity(opportunity);
        setModalOpen(true);
    };

    const handleSave = (data: Opportunity | Omit<Opportunity, 'id' | keyof Auditable>) => {
        if ('id' in data) {
            updateOpportunity(data);
        } else {
            addOpportunity(data);
        }
        setModalOpen(false);
    };

    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این فرصت فروش اطمینان دارید؟')) {
            deleteOpportunity(id);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">مدیریت فرصت‌های فروش</h1>
                <button
                    onClick={() => handleOpenModal()}
                    className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700"
                >
                    ایجاد فرصت جدید
                </button>
            </div>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">عنوان فرصت</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">مشتری</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                                <th className="px-4 py-3 text-left text-xs uppercase">ارزش تخمینی</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">اطلاعات ثبت</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">آخرین ویرایش</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {opportunities.length > 0 ? opportunities.map(o => (
                                <tr key={o.id}>
                                    <td className="px-4 py-4 font-medium">{o.name}</td>
                                    <td className="px-4 py-4">{toShamsi(o.date)}</td>
                                    <td className="px-4 py-4">{customerMap.get(o.customerId) || '-'}</td>
                                    <td className="px-4 py-4">{o.status}</td>
                                    <td className="px-4 py-4 text-left font-mono">{o.estimatedValue.toLocaleString()}</td>
                                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400">
                                        <div>{toShamsi(o.createdAt.split('T')[0])}</div>
                                        <div className="text-xs">{o.createdBy}</div>
                                    </td>
                                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400">
                                        <div>{toShamsi(o.updatedAt.split('T')[0])}</div>
                                        <div className="text-xs">{o.updatedBy}</div>
                                    </td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenModal(o)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(o.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={8} className="text-center py-6">هیچ فرصتی یافت نشد.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
            <OpportunityModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} initialData={editingOpportunity} customers={customers} />
        </div>
    );
};

const FormInput: React.FC<(React.InputHTMLAttributes<HTMLInputElement> | React.TextareaHTMLAttributes<HTMLTextAreaElement>) & { label: string, as?: 'input' | 'textarea' }> = ({ label, id, as = 'input', ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {as === 'textarea' ?
            <textarea id={id} {...props as React.TextareaHTMLAttributes<HTMLTextAreaElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" /> :
            <input id={id} {...props as React.InputHTMLAttributes<HTMLInputElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
        }
    </div>
);

export default OpportunityManagement;
