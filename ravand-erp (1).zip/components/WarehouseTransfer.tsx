import React, { useState, useMemo } from 'react';
import type {
    WarehouseTransfer,
    WarehouseTransferItem,
    Warehouse,
    PurchaseItem,
} from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';

interface WarehouseTransferProps {
    transfers: WarehouseTransfer[];
    // FIX: Updated prop type to match what App.tsx provides, which is an object without Auditable fields.
    addTransfer: (transfer: Omit<WarehouseTransfer, 'id'>) => void;
    warehouses: Warehouse[];
    purchaseItems: PurchaseItem[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        <input id={id} {...props} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const WarehouseTransferComponent: React.FC<WarehouseTransferProps> = ({ transfers, addTransfer, warehouses, purchaseItems }) => {
    
    const getInitialState = () => ({
        sourceWarehouseId: '',
        destinationWarehouseId: '',
        docNumber: '',
        date: new Date().toISOString().split('T')[0],
        description: '',
    });
    
    const [header, setHeader] = useState(getInitialState());
    const [items, setItems] = useState<Omit<WarehouseTransferItem, 'id'>[]>([]);

    const purchaseItemMap = useMemo(() => purchaseItems.reduce((map, item) => {
        map[item.id] = item;
        return map;
    }, {} as Record<number, PurchaseItem>), [purchaseItems]);

    const handleHeaderChange = (field: keyof typeof header, value: any) => {
        setHeader(prev => ({ ...prev, [field]: value }));
    };

    const handleAddItem = () => {
        setItems(prev => [...prev, { purchaseItemId: 0, quantity: 1, description: '' }]);
    };
    
    const handleItemChange = (index: number, field: keyof Omit<WarehouseTransferItem, 'id'>, value: string | number) => {
        const newItems = [...items];
        (newItems[index] as any)[field] = value;
        setItems(newItems);
    };

    const handleRemoveItem = (index: number) => {
        setItems(prev => prev.filter((_, i) => i !== index));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (transfers.some(t => t.docNumber === header.docNumber && header.docNumber.trim() !== '')) {
            alert('شماره سند تکراری است.');
            return;
        }

        if (!header.sourceWarehouseId || !header.destinationWarehouseId) {
            alert('لطفا انبار مبدا و مقصد را انتخاب کنید.');
            return;
        }
        if (header.sourceWarehouseId === header.destinationWarehouseId) {
            alert('انبار مبدا و مقصد نمی‌توانند یکسان باشند.');
            return;
        }
        if (items.length === 0 || items.some(i => !i.purchaseItemId)) {
            alert('لطفا حداقل یک قلم کالای معتبر را برای انتقال انتخاب کنید.');
            return;
        }

// FIX: Added auditable properties to satisfy the WarehouseTransfer type.
        addTransfer({ 
            ...header, 
            sourceWarehouseId: Number(header.sourceWarehouseId),
            destinationWarehouseId: Number(header.destinationWarehouseId),
            items: items.map(item => ({...item, id: Date.now() + Math.random()})),
            createdAt: new Date().toISOString(),
            createdBy: 'کاربر تست',
            updatedAt: new Date().toISOString(),
            updatedBy: 'کاربر تست',
        });
        setHeader(getInitialState());
        setItems([]);
        alert('سند انتقال بین انبارها با موفقیت ثبت شد.');
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">ثبت انتقال بین انبارها</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 border rounded-lg dark:border-slate-700">
                        <CustomFormSelect label="انبار مبدا">
                           <SearchableSelect options={warehouses.map(w => ({ value: w.id, label: w.name }))} value={header.sourceWarehouseId} onChange={val => handleHeaderChange('sourceWarehouseId', val)} />
                        </CustomFormSelect>
                        <CustomFormSelect label="انبار مقصد">
                           <SearchableSelect options={warehouses.map(w => ({ value: w.id, label: w.name }))} value={header.destinationWarehouseId} onChange={val => handleHeaderChange('destinationWarehouseId', val)} />
                        </CustomFormSelect>
                        <FormInput label="شماره سند" name="docNumber" value={header.docNumber} onChange={e => handleHeaderChange('docNumber', e.target.value)} required/>
                        <FormInput label="تاریخ" name="date" type="date" value={header.date} onChange={e => handleHeaderChange('date', e.target.value)} required />
                        <div className="md:col-span-2 lg:col-span-3">
                            <FormInput label="توضیحات" name="description" value={header.description} onChange={e => handleHeaderChange('description', e.target.value)} />
                        </div>
                    </div>
                    
                    <div className="space-y-4 pt-4 border-t dark:border-slate-700">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold">اقلام انتقالی</h3>
                            <button type="button" onClick={handleAddItem} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن ردیف</button>
                        </div>
                         <div className="overflow-x-auto">
                             <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                                 <thead className="bg-slate-50 dark:bg-slate-700">
                                     <tr>
                                         <th className="px-2 py-3 text-right font-medium" style={{width: '40%'}}>کالا</th>
                                         <th className="px-2 py-3 text-right font-medium">واحد</th>
                                         <th className="px-2 py-3 text-right font-medium">تعداد</th>
                                         <th className="px-2 py-3 text-right font-medium" style={{width: '30%'}}>توضیحات</th>
                                         <th className="w-10"></th>
                                     </tr>
                                 </thead>
                                 <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                     {items.map((item, index) => (
                                         <tr key={index}>
                                             <td className="p-1"><SearchableSelect options={purchaseItems.map(pi => ({ value: pi.id, label: `${pi.code} - ${pi.title}`}))} value={item.purchaseItemId} onChange={val => handleItemChange(index, 'purchaseItemId', val as number)} /></td>
                                             <td className="p-2 text-center">{item.purchaseItemId ? purchaseItemMap[item.purchaseItemId]?.primaryUnit : '-'}</td>
                                             <td className="p-1 w-32"><FormattedNumberInput value={item.quantity} onValueChange={val => handleItemChange(index, 'quantity', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                             <td className="p-1"><input type="text" value={item.description || ''} onChange={e => handleItemChange(index, 'description', e.target.value)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                             <td className="p-1 text-center">
                                                <button type="button" onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-900">&times;</button>
                                             </td>
                                         </tr>
                                     ))}
                                 </tbody>
                             </table>
                         </div>
                    </div>

                    <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ثبت انتقال</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">اسناد انتقال ثبت شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">تاریخ</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شماره سند</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">از انبار</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">به انبار</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {transfers.length > 0 ? (
                            transfers.map((tr) => (
                                <tr key={tr.id}>
                                    <td className="px-4 py-4">{new Date(tr.date).toLocaleDateString('fa-IR')}</td>
                                    <td className="px-4 py-4">{tr.docNumber}</td>
                                    <td className="px-4 py-4">{warehouses.find(w => w.id === tr.sourceWarehouseId)?.name || '-'}</td>
                                    <td className="px-4 py-4">{warehouses.find(w => w.id === tr.destinationWarehouseId)?.name || '-'}</td>
                                </tr>
                            ))
                        ) : (
                            <tr><td colSpan={4} className="text-center py-4">سندی ثبت نشده است.</td></tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

        </div>
    );
};

export default WarehouseTransferComponent;
