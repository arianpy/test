import React, { useState, useEffect } from 'react';
import type { DeploymentNode } from '../../types';
import Card from './ui/Card';
import BulkImportDeploymentModal from './BulkImportDeploymentModal';

interface DeploymentStructureDefinitionProps {
    structure: DeploymentNode[];
    setStructure: (nodes: DeploymentNode[]) => void;
    addNode: (title: string, parentId: number | null) => void;
    updateNode: (nodeId: number, newTitle: string) => void;
    deleteNode: (nodeId: number) => void;
}

const levelNames: Record<number, string> = {
    1: 'پروژه',
    2: 'فاز',
    3: 'عملیات',
    4: 'فعالیت',
    5: 'اقدام',
    6: 'وظیفه',
};

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

const DeploymentStructureDefinition: React.FC<DeploymentStructureDefinitionProps> = ({ structure, setStructure, addNode, updateNode, deleteNode }) => {
    const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
    const [expandedNodes, setExpandedNodes] = useState<Set<number>>(new Set());
    
    const [editingNode, setEditingNode] = useState<{ id: number; title: string } | null>(null);
    const [addingToParent, setAddingToParent] = useState<{ parentId: number | null; level: number } | null>(null);
    const [newNodeTitle, setNewNodeTitle] = useState('');

     // Automatically expand the first level of projects when the component loads
    useEffect(() => {
        if (structure.length > 0) {
            const rootNodeIds = structure.map(node => node.id);
            setExpandedNodes(new Set(rootNodeIds));
        }
    }, []); // Runs only once on mount
    
    const handleExport = () => {
        const headers = ["پروژه", "فاز", "عملیات", "فعالیت", "اقدام", "وظیفه"];
        const csvRows: string[][] = [];

        const traverseAndBuildRows = (nodes: DeploymentNode[], level: number) => {
            nodes.forEach(node => {
                const row = new Array(6).fill('');
                row[level] = node.title;
                csvRows.push(row);
                if (node.children && node.children.length > 0) {
                    traverseAndBuildRows(node.children, level + 1);
                }
            });
        };

        traverseAndBuildRows(structure, 0);

        if (csvRows.length === 0) {
            alert('هیچ داده‌ای برای خروجی گرفتن وجود ندارد.');
            return;
        }

        exportToCsv('ساختار-استقرار.csv', [headers, ...csvRows]);
    };

    const toggleNode = (nodeId: number) => {
        setExpandedNodes(prev => {
            const newSet = new Set(prev);
            if (newSet.has(nodeId)) {
                newSet.delete(nodeId);
            } else {
                newSet.add(nodeId);
            }
            return newSet;
        });
    };

    const handleStartEdit = (node: DeploymentNode) => {
        setAddingToParent(null);
        setEditingNode({ id: node.id, title: node.title });
    };

    const handleCancelEdit = () => {
        setEditingNode(null);
    };

    const handleSaveEdit = () => {
        if (editingNode && editingNode.title.trim()) {
            updateNode(editingNode.id, editingNode.title.trim());
        }
        setEditingNode(null);
    };
    
    const handleStartAdd = (parentId: number | null, level: number) => {
        setEditingNode(null);
        setAddingToParent({ parentId, level });
        setNewNodeTitle('');
        if (parentId !== null) {
            setExpandedNodes(prev => new Set(prev).add(parentId));
        }
    };

    const handleCancelAdd = () => {
        setAddingToParent(null);
    };

    const handleSaveNewNode = () => {
        if (addingToParent && newNodeTitle.trim()) {
            addNode(newNodeTitle.trim(), addingToParent.parentId);
        }
        setAddingToParent(null);
        setNewNodeTitle('');
    };

    const handleDeleteNode = (node: DeploymentNode) => {
        if (window.confirm(`آیا از حذف "${node.title}" و تمام زیرمجموعه‌های آن اطمینان دارید؟`)) {
            deleteNode(node.id);
        }
    };

    // FIX: Changed return type from JSX.Element[] to React.ReactElement[] to resolve namespace error.
    const renderRows = (nodes: DeploymentNode[], level = 1): React.ReactElement[] => {
        let rows: React.ReactElement[] = [];

        nodes.forEach(node => {
            const isExpanded = expandedNodes.has(node.id);
            rows.push(
                <tr key={node.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2 border-b dark:border-slate-700" style={{ paddingRight: `${level * 20}px` }}>
                        <div className="flex items-center">
                            {node.children.length > 0 ? (
                                <button onClick={() => toggleNode(node.id)} className="ml-2 p-1 text-slate-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
                                </button>
                            ) : (
                                <span className="ml-2 w-6 inline-block"></span>
                            )}
                            {editingNode?.id === node.id ? (
                                <input 
                                    type="text"
                                    value={editingNode.title}
                                    onChange={(e) => setEditingNode({ ...editingNode, title: e.target.value })}
                                    onKeyDown={e => { if (e.key === 'Enter') handleSaveEdit(); if (e.key === 'Escape') handleCancelEdit(); }}
                                    onBlur={handleSaveEdit}
                                    autoFocus
                                    className="px-2 py-1 bg-white dark:bg-slate-700 border border-custom-blue-primary rounded-md shadow-sm w-full"
                                />
                            ) : (
                                <span onClick={() => handleStartEdit(node)}>{node.title}</span>
                            )}
                        </div>
                    </td>
                    <td className="p-2 border-b dark:border-slate-700 text-slate-600 dark:text-slate-400 text-center">{levelNames[level]}</td>
                    <td className="p-2 border-b dark:border-slate-700 text-center">
                         <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                             {level < 6 && (
                                <button onClick={() => handleStartAdd(node.id, level + 1)} title={`افزودن ${levelNames[level+1]}`} className="p-1 rounded-full hover:bg-green-100 dark:hover:bg-green-800 text-green-600 dark:text-green-400 text-lg font-bold">+</button>
                             )}
                            <button onClick={() => handleStartEdit(node)} title="ویرایش" className="p-1 rounded-full hover:bg-amber-100 dark:hover:bg-amber-800 text-amber-600 dark:text-amber-400">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>
                            </button>
                             <button onClick={() => handleDeleteNode(node)} title="حذف" className="p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400">
                               <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                            </button>
                         </div>
                    </td>
                </tr>
            );
            
            if (addingToParent?.parentId === node.id && isExpanded) {
                rows.push(
                    <tr key={`add-to-${node.id}`} className="bg-slate-50 dark:bg-slate-800/50">
                        <td className="p-2 border-b dark:border-slate-700" style={{ paddingRight: `${(level + 1) * 20}px` }}>
                             <input
                                type="text"
                                value={newNodeTitle}
                                onChange={(e) => setNewNodeTitle(e.target.value)}
                                onKeyDown={e => { if (e.key === 'Enter') handleSaveNewNode(); if(e.key === 'Escape') handleCancelAdd(); }}
                                autoFocus
                                className="px-2 py-1 bg-white dark:bg-slate-700 border border-custom-blue-primary rounded-md shadow-sm w-full"
                                placeholder={`عنوان ${levelNames[level+1]} جدید...`}
                            />
                        </td>
                        <td className="p-2 border-b dark:border-slate-700 text-slate-600 dark:text-slate-400 text-center">{levelNames[level+1]}</td>
                        <td className="p-2 border-b dark:border-slate-700 text-center">
                            <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse">
                                <button onClick={handleSaveNewNode} className="text-green-600 hover:underline">ذخیره</button>
                                <button onClick={handleCancelAdd} className="text-red-600 hover:underline">لغو</button>
                            </div>
                        </td>
                    </tr>
                );
            }

            if (isExpanded && node.children.length > 0) {
                rows.push(...renderRows(node.children, level + 1));
            }
        });

        return rows;
    };
    
    const renderedRows = renderRows(structure);
    if (addingToParent?.parentId === null) {
        renderedRows.push(
            <tr key="add-to-root" className="bg-slate-50 dark:bg-slate-800/50">
                <td className="p-2 border-b dark:border-slate-700" style={{ paddingRight: '20px' }}>
                     <input
                        type="text"
                        value={newNodeTitle}
                        onChange={(e) => setNewNodeTitle(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter') handleSaveNewNode(); if(e.key === 'Escape') handleCancelAdd(); }}
                        autoFocus
                        className="px-2 py-1 bg-white dark:bg-slate-700 border border-custom-blue-primary rounded-md shadow-sm w-full"
                        placeholder={`عنوان ${levelNames[1]} جدید...`}
                    />
                </td>
                <td className="p-2 border-b dark:border-slate-700 text-slate-600 dark:text-slate-400 text-center">{levelNames[1]}</td>
                <td className="p-2 border-b dark:border-slate-700 text-center">
                    <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse">
                        <button onClick={handleSaveNewNode} className="text-green-600 hover:underline">ذخیره</button>
                        <button onClick={handleCancelAdd} className="text-red-600 hover:underline">لغو</button>
                    </div>
                </td>
            </tr>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف ساختار استقرار</h1>
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <button
                        onClick={() => handleStartAdd(null, 1)}
                        className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600"
                    >
                        افزودن پروژه
                    </button>
                    <button
                        onClick={() => setIsBulkModalOpen(true)}
                        className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700"
                    >
                        بارگذاری از اکسل
                    </button>
                    <button
                        onClick={handleExport}
                        className="px-4 py-2 text-sm font-medium text-white bg-teal-600 rounded-md hover:bg-teal-700"
                    >
                        خروجی اکسل
                    </button>
                </div>
            </div>

            <Card>
                <div className="overflow-auto" style={{ height: 'calc(100vh - 250px)' }}>
                    <table className="min-w-full w-full text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-10">
                            <tr>
                                <th className="p-3 text-right font-semibold text-slate-700 dark:text-slate-200 w-3/5">عنوان</th>
                                <th className="p-3 text-center font-semibold text-slate-700 dark:text-slate-200 w-1/5">سطح</th>
                                <th className="p-3 text-center font-semibold text-slate-700 dark:text-slate-200 w-1/5">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-900">
                           {renderedRows}
                           {structure.length === 0 && !addingToParent && (
                                <tr>
                                    <td colSpan={3} className="text-center p-8 text-slate-500">
                                        هیچ داده‌ای وجود ندارد. یک پروژه جدید اضافه کنید یا از اکسل بارگذاری نمایید.
                                    </td>
                                </tr>
                           )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <BulkImportDeploymentModal
                isOpen={isBulkModalOpen}
                onClose={() => setIsBulkModalOpen(false)}
                onSave={setStructure}
            />
        </div>
    );
};

export default DeploymentStructureDefinition;