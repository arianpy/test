import React, { useState, useMemo, useEffect } from 'react';
import type { User, Personnel, UserGroup } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';

interface UserManagementProps {
    personnelList: Personnel[];
    users: User[];
    addUser: (user: Omit<User, 'id'>) => void;
    updateUser: (user: User) => void;
    deleteUser: (userId: number) => void;
    userGroups: UserGroup[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);

const ToggleSwitch: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; label: string; }> = ({ checked, onChange, label }) => (
    <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-700/50 h-full">
        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-cyan-600"></div>
        </label>
    </div>
);

const UserForm: React.FC<{
    title: string;
    onClose: () => void;
    onSubmit: (user: any, password?: string) => void; // Can be Omit<User, 'id'> or User
    initialData?: User | null;
    personnelList: Personnel[];
    userGroups: UserGroup[];
}> = ({ title, onClose, onSubmit, initialData, personnelList, userGroups }) => {
    const getInitialState = () => ({
        username: initialData?.username || '',
        personnelId: initialData?.personnelId || null,
        userGroupId: initialData?.userGroupId || null,
        position: '',
        email: initialData?.email || '',
        mobile: initialData?.mobile || '',
        canChangeProfile: initialData?.canChangeProfile ?? true,
    });
    
    const [formData, setFormData] = useState(getInitialState());
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        setFormData(getInitialState());
        setPassword('');
        setConfirmPassword('');
        setError('');
    }, [initialData]);

    useEffect(() => {
        if (formData.personnelId) {
            const selected = personnelList.find(p => p.id === formData.personnelId);
            if (selected) {
                setFormData(prev => ({
                    ...prev,
                    position: selected.position,
                    email: !initialData ? selected.email : prev.email,
                    mobile: !initialData ? selected.mobile : prev.mobile,
                }));
            }
        } else if (!initialData) {
             setFormData(prev => ({ ...prev, position: '', email: '', mobile: '' }));
        }
    }, [formData.personnelId, personnelList, initialData]);

    const personnelOptions = useMemo(() => personnelList.map(p => ({ value: p.id, label: `${p.firstName} ${p.lastName}` })), [personnelList]);
    const userGroupOptions = useMemo(() => userGroups.map(g => ({ value: g.id, label: g.name })), [userGroups]);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!formData.userGroupId) { setError('لطفا گروه کاربری را انتخاب کنید.'); return; }
        
        if (!initialData) { // Only for new users
            if (password.length < 8) { setError('رمز عبور باید حداقل ۸ کاراکتر باشد.'); return; }
            if (!/[A-Z]/.test(password)) { setError('رمز عبور باید شامل حداقل یک حرف بزرگ انگلیسی باشد.'); return; }
            if (password !== confirmPassword) { setError('رمز عبور و تکرار آن مطابقت ندارند.'); return; }
        }
        if (password && password !== confirmPassword) { setError('رمز عبور و تکرار آن مطابقت ندارند.'); return; }
        if (!formData.email.includes('@')) { setError('فرمت ایمیل نامعتبر است.'); return; }

        const userPayload = { ...formData, id: initialData?.id };
        onSubmit(userPayload, password);
    };

    return (
         <Modal isOpen={true} onClose={onClose} title={title} size="3xl">
            <form onSubmit={handleSubmit} className="space-y-6">
                {error && <div className="p-3 bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 rounded-md text-sm">{error}</div>}
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <FormInput label="نام کاربری" name="username" value={formData.username} onChange={e => setFormData(p => ({...p, username: e.target.value}))} required />
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">پرسنل متناظر</label>
                        <SearchableSelect options={personnelOptions} value={formData.personnelId} onChange={val => setFormData(p => ({...p, personnelId: val as number}))} placeholder="یک پرسنل انتخاب کنید..." />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">گروه کاربری</label>
                        <SearchableSelect options={userGroupOptions} value={formData.userGroupId} onChange={val => setFormData(p => ({...p, userGroupId: val as number}))} placeholder="یک گروه انتخاب کنید..." />
                    </div>
                    <FormInput label="رمز عبور" name="password" type="password" value={password} onChange={e => setPassword(e.target.value)} required={!initialData} placeholder={initialData ? 'برای عدم تغییر خالی بگذارید' : ''} />
                    <FormInput label="تکرار رمز عبور" name="confirmPassword" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required={!initialData} />
                    <FormInput label="ایمیل کاربر" name="email" type="email" value={formData.email} onChange={e => setFormData(p => ({...p, email: e.target.value}))} required />
                    <FormInput label="شماره تلفن همراه" name="mobile" type="tel" value={formData.mobile} onChange={e => setFormData(p => ({...p, mobile: e.target.value}))} />
                    <div className="lg:col-span-3">
                         <ToggleSwitch 
                            label="امکان تغییر مشخصات توسط کاربر" 
                            checked={formData.canChangeProfile} 
                            onChange={(checked) => setFormData(prev => ({...prev, canChangeProfile: checked}))}
                         />
                    </div>
                </div>

                <div className="flex justify-end pt-5 border-t dark:border-slate-700">
                    <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره</button>
                </div>
            </form>
         </Modal>
    );
};


const UserManagement: React.FC<UserManagementProps> = ({ personnelList, users, addUser, updateUser, deleteUser, userGroups }) => {
    
    const [isAddModalOpen, setAddModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);

    const personnelMap = useMemo(() =>
        personnelList.reduce((map, p) => {
            map[p.id] = { name: `${p.firstName} ${p.lastName}`, position: p.position };
            return map;
        }, {} as Record<number, {name: string, position: string}>),
    [personnelList]);
    
    const userGroupMap = useMemo(() => 
        new Map(userGroups.map(g => [g.id, g.name])),
    [userGroups]);

    const handleSaveUser = (userFromForm: any, password?: string) => {
        // Explicitly create the payload to ensure it matches the User type
        const userPayload: Omit<User, 'id'> = {
            username: userFromForm.username,
            personnelId: userFromForm.personnelId,
            userGroupId: userFromForm.userGroupId,
            email: userFromForm.email,
            mobile: userFromForm.mobile,
            canChangeProfile: userFromForm.canChangeProfile,
        };
    
        if (editingUser) {
            // If we are editing, add the existing ID back
            updateUser({ ...userPayload, id: editingUser.id });
            alert('کاربر با موفقیت ویرایش شد.');
        } else {
            // If we are adding, call addUser with the clean payload
            addUser(userPayload);
            alert('کاربر با موفقیت ایجاد شد.');
        }
        setEditingUser(null);
        setAddModalOpen(false);
    };

    const handleDeleteUser = (userId: number) => {
        if (window.confirm('آیا از حذف این کاربر اطمینان دارید؟')) {
            deleteUser(userId);
        }
    };
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                 <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف کاربران</h1>
                 <button onClick={() => { setEditingUser(null); setAddModalOpen(true); }} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                    ایجاد کاربر جدید
                </button>
            </div>
           
            {(isAddModalOpen || editingUser) && (
                <UserForm
                    title={editingUser ? 'ویرایش کاربر' : 'ایجاد کاربر جدید'}
                    onClose={() => { setAddModalOpen(false); setEditingUser(null); }}
                    onSubmit={handleSaveUser}
                    initialData={editingUser}
                    personnelList={personnelList}
                    userGroups={userGroups}
                />
            )}

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فهرست کاربران</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">نام کاربری</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">پرسنل متناظر</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">گروه کاربری</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">ایمیل</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">تغییر پروفایل</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {users.length > 0 ? (
                            users.map((user) => (
                                <tr key={user.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{user.username}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{user.personnelId ? personnelMap[user.personnelId]?.name : '---'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{userGroupMap.get(user.userGroupId) || 'بدون گروه'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{user.email}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                                         <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                            user.canChangeProfile ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'
                                        }`}>
                                        {user.canChangeProfile ? 'مجاز' : 'غیرمجاز'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => setEditingUser(user)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500">
                                    هنوز کاربری تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default UserManagement;