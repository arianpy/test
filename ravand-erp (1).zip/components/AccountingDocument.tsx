import React, { useState, useMemo, useEffect } from 'react';
// FIX: Auditable type is now correctly exported and imported.
import type { AccountingDocument, AccountingDocumentRow, AccountHeadGroup, AccountHeadSubLedger, Currency, Auditable } from '../types';
import { AccountingDocumentType } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';


interface AccountingDocumentProps {
    documents: AccountingDocument[];
    // FIX: Changed prop type to Omit<..., 'id'> to align with App.tsx.
    addDocument: (doc: Omit<AccountingDocument, 'id'>) => void;
    deleteDocument: (id: number) => void;
    accountHeads: AccountHeadGroup[];
    currencies: Currency[];
    calculateNextDailyNumber: (date: string) => number;
}

const initialRowState: Omit<AccountingDocumentRow, 'id'> = {
    subLedgerId: null,
    detailedId: null,
    debit: 0,
    credit: 0,
    currencyDebit: 0,
    currencyCredit: 0,
    description: '',
};

const AccountingDocumentComponent: React.FC<AccountingDocumentProps> = ({ documents, addDocument, deleteDocument, accountHeads, currencies, calculateNextDailyNumber }) => {
    
    const getInitialHeaderState = (date: string) => ({
        type: AccountingDocumentType.Current,
        date: date,
        dailyNumber: calculateNextDailyNumber(date),
        docNumber: '',
        trackingNumber: '',
        groupId: null,
        currencyCode: 'IRR',
        exchangeRate: 1,
        description: '',
    });
    
    const today = new Date().toISOString().split('T')[0];
    const [header, setHeader] = useState(getInitialHeaderState(today));
    const [rows, setRows] = useState<Omit<AccountingDocumentRow, 'id'|'detailedId'>[]>([{ ...initialRowState }]);

    useEffect(() => {
        setHeader(prev => ({...prev, dailyNumber: calculateNextDailyNumber(prev.date)}));
    }, [header.date, calculateNextDailyNumber]);

    const allSubLedgers = useMemo(() => {
        return accountHeads.flatMap(group => group.children.flatMap(ledger => ledger.children));
    }, [accountHeads]);

    const subLedgerMap = useMemo(() => {
        return allSubLedgers.reduce((map, sl) => {
            map[sl.id] = sl;
            return map;
        }, {} as Record<number, AccountHeadSubLedger>);
    }, [allSubLedgers]);

    const subLedgerOptions = useMemo(() => {
        return allSubLedgers.map(sl => ({ value: sl.id, label: `${sl.code} - ${sl.title}` }));
    }, [allSubLedgers]);

    const { totalDebit, totalCredit, difference, isBalanced } = useMemo(() => {
        const totals = rows.reduce((acc, row) => {
            acc.debit += Number(row.debit) || 0;
            acc.credit += Number(row.credit) || 0;
            return acc;
        }, { debit: 0, credit: 0 });

        const diff = totals.debit - totals.credit;
        return {
            totalDebit: totals.debit,
            totalCredit: totals.credit,
            difference: diff,
            isBalanced: diff === 0 && (totals.debit > 0 || totals.credit > 0),
        };
    }, [rows]);
    
    const isForeignCurrency = header.currencyCode && header.currencyCode !== 'IRR';

    const handleHeaderChange = (field: keyof typeof header, value: any) => {
        setHeader(prev => ({...prev, [field]: value}));
    };

    const handleAddRow = () => {
        setRows(prev => [...prev, { ...initialRowState }]);
    };
    
    const handleRemoveRow = (index: number) => {
        setRows(prev => prev.filter((_, i) => i !== index));
    };

    const handleRowChange = (index: number, field: keyof Omit<AccountingDocumentRow, 'id' | 'detailedId'>, value: string | number | null) => {
       const newRows = [...rows];
       (newRows[index] as any)[field] = value;
       setRows(newRows);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isBalanced) {
            alert('سند تراز نمی باشد. لطفا قبل از ذخیره، سند را تراز کنید.');
            return;
        }
        if (rows.some(r => !r.subLedgerId)) {
             alert('لطفا برای تمام ردیف ها حساب معین انتخاب کنید.');
            return;
        }
// FIX: Added auditable properties to satisfy the AccountingDocument type.
        addDocument({
            ...header,
            exchangeRate: Number(header.exchangeRate),
            rows: rows.map(r => ({...r, id: Date.now() + Math.random(), detailedId: null})),
            isIssued: false, // Defaulting to not issued on save
            createdAt: new Date().toISOString(),
            createdBy: 'کاربر تست',
            updatedAt: new Date().toISOString(),
            updatedBy: 'کاربر تست',
        });
        alert('سند حسابداری با موفقیت ذخیره شد.');
        const newDate = new Date().toISOString().split('T')[0];
        setHeader(getInitialHeaderState(newDate));
        setRows([{ ...initialRowState }]);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">صدور سند حسابداری</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Header */}
                    <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end">
                            <CustomFormSelect label="نوع سند" >
                                <SearchableSelect options={Object.values(AccountingDocumentType).map(t=>({value: t, label: t}))} value={header.type} onChange={val => handleHeaderChange('type', val)} />
                            </CustomFormSelect>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تاریخ</label>
                                <ShamsiDatePicker value={header.date} onChange={date => handleHeaderChange('date', date)} required />
                            </div>
                            <FormInput label="شماره روزانه" name="dailyNumber" value={header.dailyNumber} readOnly disabled className="bg-slate-100 dark:bg-slate-800" />
                            <FormInput label="شماره سند" name="docNumber" value={header.docNumber} onChange={e => handleHeaderChange('docNumber', e.target.value)} />
                            <FormInput label="شماره پیگیری" name="trackingNumber" value={header.trackingNumber} onChange={e => handleHeaderChange('trackingNumber', e.target.value)} />
                            <CustomFormSelect label="گروه" >
                                <SearchableSelect options={accountHeads.map(g => ({ value: g.id, label: g.title }))} value={header.groupId} onChange={val => handleHeaderChange('groupId', val)} placeholder="انتخاب گروه..."/>
                            </CustomFormSelect>
                            <CustomFormSelect label="ارز" >
                                 <SearchableSelect options={currencies.map(c => ({ value: c.code, label: c.name }))} value={header.currencyCode} onChange={val => handleHeaderChange('currencyCode', val)} />
                            </CustomFormSelect>
                            {isForeignCurrency && (
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">نرخ تبدیل</label>
                                    <FormattedNumberInput value={header.exchangeRate} onValueChange={val => handleHeaderChange('exchangeRate', val)} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"/>
                                </div>
                            )}
                        </div>
                         <div>
                            <label className="block text-sm font-medium">شرح سند</label>
                            <textarea name="description" value={header.description} onChange={e => handleHeaderChange('description', e.target.value)} rows={2} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"></textarea>
                        </div>
                    </div>
                    
                    {/* Rows */}
                    <div className="space-y-4">
                         <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold">ردیف‌های سند</h3>
                            <button type="button" onClick={handleAddRow} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن ردیف</button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                                <thead className="bg-slate-50 dark:bg-slate-700">
                                    <tr>
                                        <th className="px-2 py-3 text-right font-medium">معین</th>
                                        <th className="px-2 py-3 text-right font-medium">تفصیلی</th>
                                        <th className="px-2 py-3 text-right font-medium">بدهکار</th>
                                        <th className="px-2 py-3 text-right font-medium">بستانکار</th>
                                        {isForeignCurrency && <th className="px-2 py-3 text-right font-medium">بدهکار ارزی</th>}
                                        {isForeignCurrency && <th className="px-2 py-3 text-right font-medium">بستانکار ارزی</th>}
                                        <th className="px-2 py-3 text-right font-medium">شرح ردیف</th>
                                        <th className="w-10"></th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                    {rows.map((row, index) => {
                                        const selectedSubLedger = row.subLedgerId ? subLedgerMap[row.subLedgerId] : null;
                                        return (
                                        <tr key={index}>
                                            <td className="p-1 min-w-[250px]">
                                                <SearchableSelect options={subLedgerOptions} value={row.subLedgerId} onChange={val => handleRowChange(index, 'subLedgerId', val)} placeholder="انتخاب معین..." />
                                            </td>
                                            <td className="p-1 min-w-[150px]"><input type="text" placeholder="-" disabled={!selectedSubLedger?.canLinkToDetailed} className="w-full bg-transparent p-2 focus:outline-none disabled:text-slate-400 disabled:bg-slate-100 dark:disabled:bg-slate-800 rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                            <td className="p-1 min-w-[140px]"><FormattedNumberInput value={row.debit} onValueChange={val => handleRowChange(index, 'debit', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                            <td className="p-1 min-w-[140px]"><FormattedNumberInput value={row.credit} onValueChange={val => handleRowChange(index, 'credit', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                            {isForeignCurrency && <td className="p-1 min-w-[140px]"><FormattedNumberInput value={row.currencyDebit} onValueChange={val => handleRowChange(index, 'currencyDebit', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>}
                                            {isForeignCurrency && <td className="p-1 min-w-[140px]"><FormattedNumberInput value={row.currencyCredit} onValueChange={val => handleRowChange(index, 'currencyCredit', val)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>}
                                            <td className="p-1 min-w-[250px]"><input type="text" value={row.description} onChange={e => handleRowChange(index, 'description', e.target.value)} className="w-full bg-transparent p-2 focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" /></td>
                                            <td className="p-1 text-center"><button type="button" onClick={() => handleRemoveRow(index)} className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-900">&times;</button></td>
                                        </tr>
                                    )})}
                                </tbody>
                                <tfoot className="bg-slate-100 dark:bg-slate-700 font-bold">
                                    <tr>
                                        <td colSpan={2} className="px-2 py-3 text-left">جمع کل:</td>
                                        <td className="px-2 py-3 font-mono">{new Intl.NumberFormat('en-US').format(totalDebit)}</td>
                                        <td className="px-2 py-3 font-mono">{new Intl.NumberFormat('en-US').format(totalCredit)}</td>
                                        {isForeignCurrency && <td colSpan={2}></td>}
                                        <td colSpan={2}></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div className={`mt-4 p-3 rounded-md text-center font-semibold ${isBalanced ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'}`}>
                            اختلاف: <span className="font-mono">{new Intl.NumberFormat('en-US').format(difference)}</span>
                        </div>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex justify-end items-center pt-5 border-t dark:border-slate-700 space-x-2 rtl:space-x-reverse">
                        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره</button>
                        <button type="button" disabled className="px-4 py-2 text-sm font-medium text-slate-600 bg-slate-200 rounded-md disabled:cursor-not-allowed">حذف</button>
                        <button type="button" disabled={!isBalanced} className="px-4 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 disabled:bg-blue-300 dark:disabled:bg-blue-800 disabled:cursor-not-allowed">صدور سند</button>
                        <button type="button" disabled className="px-4 py-2 text-sm font-medium text-white bg-red-500 rounded-md hover:bg-red-600 disabled:bg-red-300 disabled:cursor-not-allowed">حذف سند</button>
                    </div>
                </form>
            </Card>

            <Card>
                 <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">اسناد حسابداری ذخیره شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">تاریخ</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شماره روزانه</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شماره سند</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">نوع سند</th>
                            <th className="px-4 py-3 text-right text-xs font-medium uppercase">شرح</th>
                             <th className="px-4 py-3 text-left text-xs font-medium uppercase">مبلغ</th>
                             <th className="px-4 py-3 text-center text-xs font-medium uppercase">وضعیت</th>
                             <th className="px-4 py-3 text-center text-xs font-medium uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {documents.length > 0 ? (
                            documents.map((doc) => {
                                const docTotal = doc.rows.reduce((sum, r) => sum + r.debit, 0);
                                return (
                                <tr key={doc.id}>
                                    <td className="px-4 py-4 whitespace-nowrap">{toShamsi(doc.date)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{doc.dailyNumber}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{doc.docNumber}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{doc.type}</td>
                                    <td className="px-4 py-4 whitespace-nowrap max-w-xs truncate">{doc.description}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono">{new Intl.NumberFormat('en-US').format(docTotal)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center">
                                         <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                            doc.isIssued ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
                                        }`}>
                                        {doc.isIssued ? 'صادر شده' : 'پیش‌نویس'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center">
                                        <button onClick={() => deleteDocument(doc.id)} className="text-red-500 hover:text-red-700 text-sm">حذف</button>
                                    </td>
                                </tr>
                            )})
                        ) : (
                            <tr>
                                <td colSpan={8} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    سندی ذخیره نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

// Wrapper components to maintain consistent styling
const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, ...props }) => (
    <div>
        <label htmlFor={props.id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        <input {...props} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);


export default AccountingDocumentComponent;
