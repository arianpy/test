import React, { useState, useEffect } from 'react';
import type { HistoricalData, BudgetPrediction } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface HistoricalDataFormProps {
    type: 'gdp' | 'inflation';
    addData: (type: 'gdp' | 'inflation', data: Omit<HistoricalData, 'id'>) => void;
}

const HistoricalDataForm: React.FC<HistoricalDataFormProps> = ({ type, addData }) => {
    const [year, setYear] = useState<string>('');
    const [value, setValue] = useState<string>('');

    const title = type === 'gdp' ? 'تولید ناخالص داخلی (GDP)' : 'نرخ تورم';
    const valueLabel = type === 'gdp' ? 'میزان GDP (میلیارد دلار)' : 'درصد تورم';
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!year || !value) return;
        addData(type, { year: Number(year), value: Number(value) });
        setYear('');
        setValue('');
    };

    return (
        <form onSubmit={handleSubmit} className="p-4 border rounded-lg dark:border-slate-700">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">{`افزودن ${title} جدید`}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label className="block text-sm font-medium">سال</label>
                    <input type="number" placeholder="مثال: 1401" value={year} onChange={e => setYear(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium">{valueLabel}</label>
                    <input type="number" step="0.1" placeholder="مقدار را وارد کنید" value={value} onChange={e => setValue(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
                </div>
                <div className="md:pt-6">
                    <button type="submit" className="w-full px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                        افزودن
                    </button>
                </div>
            </div>
        </form>
    );
};


interface IndependentBudgetingDefinitionsProps {
    gdpData: HistoricalData[];
    inflationData: HistoricalData[];
    addData: (type: 'gdp' | 'inflation', data: Omit<HistoricalData, 'id'>) => void;
    budgetPrediction: BudgetPrediction;
    updateBudgetPrediction: (prediction: BudgetPrediction) => void;
}

const DataTable: React.FC<{title: string; data: HistoricalData[]}> = ({ title, data }) => (
    <div>
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2">{title}</h3>
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                <thead className="bg-slate-50 dark:bg-slate-700">
                <tr>
                    <th className="px-6 py-3 text-right text-xs font-medium uppercase">سال</th>
                    <th className="px-6 py-3 text-right text-xs font-medium uppercase">مقدار</th>
                </tr>
                </thead>
                <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                {data.length > 0 ? data.map(item => (
                    <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap">{item.year}</td>
                        <td className="px-6 py-4 whitespace-nowrap font-mono">{new Intl.NumberFormat('en-US').format(item.value)}</td>
                    </tr>
                )) : (
                    <tr><td colSpan={2} className="text-center py-4">داده‌ای ثبت نشده است.</td></tr>
                )}
                </tbody>
            </table>
        </div>
    </div>
);


const IndependentBudgetingDefinitions: React.FC<IndependentBudgetingDefinitionsProps> = ({ gdpData, inflationData, addData, budgetPrediction, updateBudgetPrediction }) => {
    
    const [localPrediction, setLocalPrediction] = useState<BudgetPrediction>(budgetPrediction);

    useEffect(() => {
        setLocalPrediction(budgetPrediction);
    }, [budgetPrediction]);

    const handlePredictionChange = (field: keyof BudgetPrediction, value: number) => {
        setLocalPrediction(prev => ({...prev, [field]: value}));
    };

    const handleSavePrediction = (e: React.FormEvent) => {
        e.preventDefault();
        updateBudgetPrediction(localPrediction);
        alert('تنظیمات پیش‌بینی با موفقیت ذخیره شد.');
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعاریف بودجه ریزی مستقل</h1>
            <p className="text-slate-600 dark:text-slate-400">
                در این بخش می‌توانید داده‌های تاریخی و پیش‌بینی‌های مورد نیاز برای مدل‌ها را وارد و مدیریت کنید.
            </p>

             <Card>
                <form onSubmit={handleSavePrediction}>
                    <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">تنظیمات پیش‌بینی بودجه</h2>
                     <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">این مقادیر برای سال مالی فعال استفاده خواهند شد.</p>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                        <div>
                            <label className="block text-sm font-medium mb-1">پیش‌بینی نرخ تورم (%)</label>
                            <FormattedNumberInput
                                value={localPrediction.predictedInflationRate}
                                onValueChange={val => handlePredictionChange('predictedInflationRate', val)}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">پیش‌بینی نرخ ارز (فرعی به اصلی)</label>
                            <FormattedNumberInput
                                value={localPrediction.predictedExchangeRate}
                                onValueChange={val => handlePredictionChange('predictedExchangeRate', val)}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"
                            />
                        </div>
                         <div>
                            <button type="submit" className="w-full px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                                ذخیره تنظیمات
                            </button>
                        </div>
                    </div>
                </form>
            </Card>

            <Card>
                <div className="space-y-8">
                   <div>
                        <HistoricalDataForm type="gdp" addData={addData} />
                   </div>
                   <div>
                       <DataTable title="تاریخچه تولید ناخالص داخلی (GDP)" data={gdpData} />
                   </div>
                </div>
            </Card>
            
            <Card>
                 <div className="space-y-8">
                   <div>
                        <HistoricalDataForm type="inflation" addData={addData} />
                   </div>
                   <div>
                       <DataTable title="تاریخچه نرخ تورم" data={inflationData} />
                   </div>
                </div>
            </Card>
        </div>
    );
};

export default IndependentBudgetingDefinitions;