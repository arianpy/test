import React, { useState, useMemo, useEffect } from 'react';
import type { PaymentGateway, Currency } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface DefinePaymentGatewaysProps {
    gateways: PaymentGateway[];
    addGateway: (gateway: Omit<PaymentGateway, 'id'>) => void;
    updateGateway: (gateway: PaymentGateway) => void;
    deleteGateway: (gatewayId: number) => void;
    currencies: Currency[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const EditPaymentGatewayModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    gateway: PaymentGateway | null;
    updateGateway: (gateway: PaymentGateway) => void;
    currencies: Currency[];
}> = ({ isOpen, onClose, gateway, updateGateway, currencies }) => {
    
    const [formData, setFormData] = useState<PaymentGateway | null>(gateway);

    useEffect(() => {
        setFormData(gateway);
    }, [gateway]);

    if (!isOpen || !formData) return null;
    
    const currencyOptions = currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`}));

    const handleChange = (field: keyof Omit<PaymentGateway, 'id'>, value: any) => {
        setFormData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateGateway(formData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش درگاه پرداخت: ${gateway?.title}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <FormInput label="عنوان درگاه پرداخت" value={formData.title} onChange={e => handleChange('title', e.target.value)} required />
                    <FormInput label="کد درگاه پرداخت" value={formData.code} onChange={e => handleChange('code', e.target.value)} required />
                    <CustomFormSelect label="ارز">
                        <SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} />
                    </CustomFormSelect>
                     <div>
                        <label className="block text-sm font-medium">مانده افتتاحیه</label>
                        <FormattedNumberInput value={formData.openingBalance} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full p-2 border rounded-md" />
                    </div>
                </div>

                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};

const DefinePaymentGateways: React.FC<DefinePaymentGatewaysProps> = ({ gateways, addGateway, updateGateway, deleteGateway, currencies }) => {
    const initialState: Omit<PaymentGateway, 'id'> = {
        title: '',
        code: '',
        openingBalance: 0,
        currencyCode: currencies[0]?.code || 'IRR',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedGateway, setSelectedGateway] = useState<PaymentGateway | null>(null);

    const currencyMap = useMemo(() => 
        currencies.reduce((map, currency) => {
            map[currency.code] = currency.name;
            return map;
        }, {} as Record<string, string>),
    [currencies]);

    const currencyOptions = useMemo(() => currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`})), [currencies]);

    const handleChange = (field: keyof Omit<PaymentGateway, 'id'>, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addGateway(formData);
        setFormData(initialState);
        alert('درگاه پرداخت جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (gateway: PaymentGateway) => {
        setSelectedGateway(gateway);
        setEditModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف درگاه پرداخت</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <FormInput label="عنوان درگاه پرداخت" value={formData.title} onChange={e => handleChange('title', e.target.value)} required placeholder="عنوان درگاه پرداخت را وارد کنید"/>
                        <FormInput label="کد درگاه پرداخت" value={formData.code} onChange={e => handleChange('code', e.target.value)} required placeholder="کد درگاه پرداخت را وارد کنید"/>
                        <div>
                            <label className="block text-sm font-medium">مانده افتتاحیه استقرار</label>
                            <FormattedNumberInput value={formData.openingBalance || ''} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full p-2 border rounded-md" placeholder="مانده افتتاحیه استقرار را وارد کنید"/>
                        </div>
                        <CustomFormSelect label="انتخاب ارز">
                            <SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} />
                        </CustomFormSelect>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            وارد کردن درگاه پرداخت
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">درگاه‌های پرداخت تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs uppercase">عنوان</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">کد</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">ارز</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">مانده افتتاحیه</th>
                            <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {gateways.length > 0 ? (
                            gateways.map((gateway) => (
                                <tr key={gateway.id}>
                                    <td className="px-4 py-4 whitespace-nowrap">{gateway.title}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{gateway.code}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{currencyMap[gateway.currencyCode] || gateway.currencyCode}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono">{gateway.openingBalance.toLocaleString()}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center space-x-4 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(gateway)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => deleteGateway(gateway.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={5} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز درگاه پرداختی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditPaymentGatewayModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                gateway={selectedGateway}
                updateGateway={updateGateway}
                currencies={currencies}
            />
        </div>
    );
};

export default DefinePaymentGateways;
