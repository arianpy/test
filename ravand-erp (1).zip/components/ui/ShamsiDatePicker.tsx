
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { toShamsi, toGregorian } from '../../utils/date';
import { toJalaali, toGregorian as toGregorianFromJalali, jalaaliMonthLength } from '../../utils/jalali';

interface ShamsiDatePickerProps {
    value: string; // Gregorian YYYY-MM-DD
    onChange: (value: string) => void;
    [key: string]: any; // other props for input
}

const CalendarIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
    </svg>
);

const ShamsiDatePicker: React.FC<ShamsiDatePickerProps> = ({ value, onChange, className, ...props }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [viewDate, setViewDate] = useState(value ? new Date(value) : new Date());
    const [calendarView, setCalendarView] = useState<'days' | 'months'>('days');
    const wrapperRef = useRef<HTMLDivElement>(null);

    const SHAMSI_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
    const SHAMSI_WEEKDAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        if (isOpen) {
            setViewDate(value ? new Date(value) : new Date());
            setCalendarView('days');
        }
    }, [isOpen, value]);
    
    const todayJalaali = useMemo(() => {
        const today = new Date();
        return toJalaali(today.getFullYear(), today.getMonth() + 1, today.getDate());
    }, []);

    const jalaaliViewDate = useMemo(() => {
        return toJalaali(viewDate.getFullYear(), viewDate.getMonth() + 1, viewDate.getDate());
    }, [viewDate]);

    const calendarData = useMemo(() => {
        const { jy, jm } = jalaaliViewDate;
        const firstDayOfMonthGregorian = toGregorianFromJalali(jy, jm, 1);
        const firstDayOfMonthDateObj = new Date(firstDayOfMonthGregorian.gy, firstDayOfMonthGregorian.gm - 1, firstDayOfMonthGregorian.gd);
        const dayOfWeek = (firstDayOfMonthDateObj.getDay() + 1) % 7;
        const monthLength = jalaaliMonthLength(jy, jm);
        const days = Array.from({ length: dayOfWeek }, () => null);
        for (let i = 1; i <= monthLength; i++) {
            days.push(i);
        }
        return { days };
    }, [jalaaliViewDate]);

    const handleDayClick = (day: number) => {
        if (!day) return;
        const gregorian = toGregorianFromJalali(jalaaliViewDate.jy, jalaaliViewDate.jm, day);
        const newDate = `${gregorian.gy}-${String(gregorian.gm).padStart(2, '0')}-${String(gregorian.gd).padStart(2, '0')}`;
        onChange(newDate);
        setIsOpen(false);
    };

    const handleMonthClick = (monthIndex: number) => {
        const newJalaaliMonth = monthIndex + 1;
        const { gy, gm, gd } = toGregorianFromJalali(jalaaliViewDate.jy, newJalaaliMonth, 1);
        setViewDate(new Date(gy, gm - 1, gd));
        setCalendarView('days');
    };
    
    const handleTodayClick = () => {
        const today = new Date();
        const newDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
        onChange(newDate);
        setIsOpen(false);
    };

    const goToPrev = () => {
        setViewDate(prev => {
            const newDate = new Date(prev);
            if (calendarView === 'days') {
                newDate.setDate(1); // Go to the first of the month before subtracting
                newDate.setMonth(newDate.getMonth() - 1);
            } else {
                newDate.setFullYear(newDate.getFullYear() - 1);
            }
            return newDate;
        });
    };

    const goToNext = () => {
        setViewDate(prev => {
            const newDate = new Date(prev);
            if (calendarView === 'days') {
                newDate.setDate(1); // Go to the first of the month before adding
                newDate.setMonth(newDate.getMonth() + 1);
            } else {
                newDate.setFullYear(newDate.getFullYear() + 1);
            }
            return newDate;
        });
    };

    const selectedJalaali = useMemo(() => value ? toJalaali(new Date(value).getFullYear(), new Date(value).getMonth() + 1, new Date(value).getDate()) : null, [value]);

    return (
        <div className={`relative ${className || ''}`} ref={wrapperRef}>
            <div className="relative">
                 <input
                    type="text"
                    value={toShamsi(value)}
                    onClick={() => setIsOpen(!isOpen)}
                    readOnly
                    placeholder="انتخاب تاریخ"
                    className="w-full pl-10 pr-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary cursor-pointer transition-colors"
                    {...props}
                />
                 <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <CalendarIcon />
                </span>
            </div>

            {isOpen && (
                <div className="absolute z-10 w-80 mt-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-2xl p-4 transition-all duration-300 ease-out origin-top animate-fade-in-down">
                    <div className="flex justify-between items-center mb-4">
                        <button type="button" onClick={goToNext} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
                        </button>
                        <button type="button" onClick={() => setCalendarView(v => v === 'days' ? 'months' : 'days')} className="font-semibold text-sm px-4 py-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                            {calendarView === 'days' ? `${SHAMSI_MONTHS[jalaaliViewDate.jm - 1]} ${jalaaliViewDate.jy}` : jalaaliViewDate.jy}
                        </button>
                        <button type="button" onClick={goToPrev} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                        </button>
                    </div>
                    {calendarView === 'days' ? (
                        <>
                            <div className="grid grid-cols-7 gap-1 text-center text-xs text-slate-500 dark:text-slate-400 mb-2">
                                {SHAMSI_WEEKDAYS.map(d => <div key={d} className="font-bold">{d}</div>)}
                            </div>
                            <div className="grid grid-cols-7 gap-1">
                                {calendarData.days.map((day, index) => {
                                    const isSelected = selectedJalaali && selectedJalaali.jy === jalaaliViewDate.jy && selectedJalaali.jm === jalaaliViewDate.jm && selectedJalaali.jd === day;
                                    const isToday = todayJalaali.jy === jalaaliViewDate.jy && todayJalaali.jm === jalaaliViewDate.jm && todayJalaali.jd === day;
                                    return (
                                    <button
                                        key={index}
                                        type="button"
                                        onClick={() => handleDayClick(day!)}
                                        disabled={!day}
                                        className={`h-9 w-9 rounded-full text-sm transition-all duration-200 transform hover:scale-110 flex items-center justify-center
                                            ${!day ? 'bg-transparent cursor-default' : 'hover:bg-custom-blue-light/30 dark:hover:bg-slate-700'}
                                            ${isSelected ? 'bg-custom-blue-primary text-white font-bold shadow-lg scale-110' : 'text-slate-700 dark:text-slate-300'}
                                            ${isToday && !isSelected ? 'ring-2 ring-custom-blue-primary' : ''}
                                        `}
                                    >
                                        {day}
                                    </button>
                                )})}
                            </div>
                        </>
                    ) : (
                        <div className="grid grid-cols-3 gap-2 mt-4">
                            {SHAMSI_MONTHS.map((month, index) => (
                                <button
                                    key={month}
                                    type="button"
                                    onClick={() => handleMonthClick(index)}
                                    className={`p-3 rounded-lg text-sm transition-all duration-200 transform hover:scale-105
                                        ${jalaaliViewDate.jm === index + 1 ? 'bg-custom-blue-primary text-white font-bold shadow-lg' : 'hover:bg-custom-blue-light/30 dark:hover:bg-slate-700'}
                                    `}
                                >
                                    {month}
                                </button>
                            ))}
                        </div>
                    )}
                     <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700">
                        <button type="button" onClick={handleTodayClick} className="w-full text-center py-2 text-sm text-custom-blue-primary font-semibold hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md transition-colors">
                            امروز
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ShamsiDatePicker;
