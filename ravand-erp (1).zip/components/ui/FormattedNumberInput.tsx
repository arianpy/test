
import React, { useState, useEffect } from 'react';

// Use 'en-US' for English numerals and comma separators.
const formatNumber = (num: number | string | undefined | null): string => {
    if (num === null || num === undefined || num === '' || isNaN(Number(num))) {
        return '';
    }
    return new Intl.NumberFormat('en-US').format(Number(num));
};

const parseNumber = (str: string): string => {
    // Removes all non-digit characters.
    return str.replace(/[^\d]/g, '');
};

const FormattedNumberInput: React.FC<
    React.InputHTMLAttributes<HTMLInputElement> & {
        onValueChange: (value: number) => void;
        value: number | '';
    }
> = ({ value, onValueChange, ...props }) => {
    const [displayValue, setDisplayValue] = useState(formatNumber(value));
    const [isFocused, setIsFocused] = useState(false);

    useEffect(() => {
        // Update display value if prop changes from outside and the input is not focused
        if (!isFocused) {
            setDisplayValue(formatNumber(value));
        }
    }, [value, isFocused]);

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
        setIsFocused(true);
        // On focus, show the raw, unformatted number for easier editing
        setDisplayValue(value === '' ? '' : String(value));
        // Select all text for easy replacement
        e.target.select();
        if (props.onFocus) {
            props.onFocus(e);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const rawValue = parseNumber(e.target.value);
        // Update the display to show the user's raw input as they type
        setDisplayValue(rawValue); 
        // Notify parent component of the new numeric value
        onValueChange(rawValue === '' ? 0 : Number(rawValue));
    };
    
    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        setIsFocused(false);
        // Format the number on blur
        setDisplayValue(formatNumber(value));
        if (props.onBlur) {
            props.onBlur(e);
        }
    };

    return (
        <input
            {...props}
            type="text" // Use text type to show formatted string
            value={displayValue}
            onFocus={handleFocus}
            onChange={handleChange}
            onBlur={handleBlur}
            dir="ltr" // Force LTR direction for number input
            style={{ textAlign: 'left', ...props.style }} // Force left alignment
        />
    );
};

export default FormattedNumberInput;
