import React from 'react';

// FIX: Updated CardProps to extend standard HTML div attributes to allow props like onClick.
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', ...props }) => {
  return (
    <div className={`bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 ${className}`} {...props}>
      {children}
    </div>
  );
};

export default Card;
