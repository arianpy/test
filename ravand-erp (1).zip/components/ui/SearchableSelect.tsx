
import React, { useState, useEffect, useRef, useMemo } from 'react';

interface SearchableSelectProps {
    options: { value: string | number; label: string }[];
    value: string | number | null;
    onChange: (value: string | number | null) => void;
    placeholder?: string;
    disabled?: boolean;
}

const SearchableSelect: React.FC<SearchableSelectProps> = ({ options, value, onChange, placeholder = "انتخاب...", disabled = false }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const wrapperRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    const selectedOption = useMemo(() => options.find(opt => opt.value === value), [options, value]);

    const filteredOptions = useMemo(() => {
        if (!searchTerm) return options;
        return options.filter(option =>
            option.label.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [options, searchTerm]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (optionValue: string | number) => {
        onChange(optionValue);
        setSearchTerm('');
        setIsOpen(false);
        inputRef.current?.blur();
    };
    
    const handleInputClick = () => {
        if(disabled) return;
        setIsOpen(prev => !prev);
    };
    
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value);
        if (!isOpen) {
            setIsOpen(true);
        }
    };
    
    const handleFocus = () => {
        setSearchTerm(''); // Clear search on focus before opening
    }

    return (
        <div className="relative w-full" ref={wrapperRef}>
            <div className="relative">
                <input
                    ref={inputRef}
                    type="text"
                    onClick={handleInputClick}
                    onFocus={handleFocus}
                    onChange={handleInputChange}
                    value={isOpen ? searchTerm : (selectedOption?.label || '')}
                    placeholder={!selectedOption ? placeholder : undefined}
                    disabled={disabled}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary disabled:bg-slate-100 dark:disabled:bg-slate-800 dark:disabled:text-slate-400"
                />
                 <span className="absolute inset-y-0 left-0 flex items-center pl-2 pointer-events-none">
                    <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 3a.75.75 0 01.53.22l3.5 3.5a.75.75 0 01-1.06 1.06L10 4.81 7.03 7.78a.75.75 0 01-1.06-1.06l3.5-3.5A.75.75 0 0110 3zm-3.5 9.5a.75.75 0 011.06 0L10 15.19l2.97-2.97a.75.75 0 111.06 1.06l-3.5 3.5a.75.75 0 01-1.06 0l-3.5-3.5a.75.75 0 010-1.06z" clipRule="evenodd" />
                    </svg>
                </span>
            </div>

            {isOpen && (
                <ul className="absolute z-30 w-full mt-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md shadow-lg max-h-60 overflow-y-auto">
                    {filteredOptions.length > 0 ? (
                        filteredOptions.map(option => (
                            <li
                                key={option.value}
                                onClick={() => handleSelect(option.value)}
                                className={`px-3 py-2 cursor-pointer hover:bg-custom-blue-light/50 dark:hover:bg-slate-700 ${value === option.value ? 'bg-custom-blue-light/50 dark:bg-slate-700' : ''}`}
                            >
                                {option.label}
                            </li>
                        ))
                    ) : (
                        <li className="px-3 py-2 text-slate-500">موردی یافت نشد</li>
                    )}
                </ul>
            )}
        </div>
    );
};

export default SearchableSelect;
