import React, { useState, useEffect, useMemo } from 'react';
import type { TrendForm, TrendInstance, TrendBox, TrendField, TrendButton, Auditable, TrendInstanceData, TrendInstanceHistoryEntry } from '../types';
import Modal from './ui/Modal';

// Props
interface TrendInstanceModalProps {
    isOpen: boolean;
    onClose: () => void;
    formTemplate: TrendForm;
    instance: TrendInstance | null;
    onSave: (data: TrendInstance | Omit<TrendInstance, 'id' | keyof Auditable>) => void;
    getCurrentUser: () => string;
}

const TrendInstanceModal: React.FC<TrendInstanceModalProps> = ({ isOpen, onClose, formTemplate, instance, onSave, getCurrentUser }) => {
    
    const getInitialInstanceData = (): Omit<TrendInstance, 'id' | keyof Auditable> => ({
        formId: formTemplate.id,
        title: `${formTemplate.title} - ${new Date().toLocaleString('fa-IR')}`,
        currentBoxId: formTemplate.boxes[0]?.id || 0,
        status: 'در حال انجام',
        data: {},
        history: [{
            boxId: formTemplate.boxes[0]?.id || 0,
            enteredAt: new Date().toISOString(),
            exitedAt: null,
            user: getCurrentUser(),
            action: 'ایجاد'
        }]
    });

    const [currentInstance, setCurrentInstance] = useState<TrendInstance | Omit<TrendInstance, 'id' | keyof Auditable>>(instance || getInitialInstanceData());
    const [instanceData, setInstanceData] = useState<TrendInstanceData>(instance?.data || {});

    useEffect(() => {
        if (instance) {
            setCurrentInstance(instance);
            setInstanceData(instance.data);
        } else {
            setCurrentInstance(getInitialInstanceData());
            setInstanceData({});
        }
    }, [instance, isOpen]);

    const currentBox = useMemo(() => {
        return formTemplate.boxes.find(b => b.id === currentInstance.currentBoxId);
    }, [currentInstance.currentBoxId, formTemplate.boxes]);

    const handleDataChange = (fieldId: number, value: any) => {
        setInstanceData(prev => ({ ...prev, [fieldId]: value }));
    };

    const handleAction = (button: TrendButton) => {
        // TODO: Add validation based on button.requiredFieldIds

        const updatedInstance = {
            ...currentInstance,
            data: { ...currentInstance.data, ...instanceData },
            currentBoxId: button.destinationBoxId || currentInstance.currentBoxId,
            status: button.destinationBoxId === null ? 'تکمیل شده' : 'در حال انجام',
            // TODO: Add history update logic
        };
        
        onSave(updatedInstance);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={instance ? instance.title : 'ایجاد روند جدید'} size="3xl">
            {currentBox ? (
                <div className="space-y-4">
                     <h3 className="text-xl font-bold mb-1 text-slate-900 dark:text-white">{currentBox.name}</h3>
                     <p className="text-sm text-slate-500 mb-4">مرحله: {formTemplate.stages.find(s=>s.id === currentBox.stageId)?.name || 'نامشخص'}</p>
                    
                     {/* This section needs a full implementation to render different field types */}
                     <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-md">
                        <p className="text-center text-slate-500">
                            محیط اجرای فرم در حال توسعه است.
                        </p>
                     </div>

                    <div className="flex flex-wrap gap-2 pt-4 border-t dark:border-slate-600">
                        {currentBox.buttons.map(button => (
                            <button
                                key={button.id}
                                style={{ backgroundColor: button.color }}
                                onClick={() => handleAction(button)}
                                className="px-4 py-2 text-white rounded-md text-sm shadow-md hover:opacity-90 transition-opacity"
                            >
                                {button.text}
                            </button>
                        ))}
                    </div>

                </div>
            ) : (
                <p>خطا: مرحله فعلی روند یافت نشد.</p>
            )}
        </Modal>
    );
};

export default TrendInstanceModal;
