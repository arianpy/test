
import React from 'react';
import type { DeletedDocumentLog } from '../types';
import Card from './ui/Card';
import { toShamsi } from '../utils/date';

interface DeletedDocumentsManagementProps {
    deletedLogs: DeletedDocumentLog[];
}

const DeletedDocumentsManagement: React.FC<DeletedDocumentsManagementProps> = ({ deletedLogs }) => {
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">مدیریت اسناد حذف شده</h1>
            <p className="text-slate-600 dark:text-slate-400">
                در این بخش می‌توانید تاریخچه اسنادی که از سیستم حذف شده‌اند را مشاهده کنید. این اطلاعات به منظور ردیابی و امنیت نگهداری می‌شوند.
            </p>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">نوع سند</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">شناسه سند</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">تاریخ و زمان حذف</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">کاربر حذف کننده</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {deletedLogs.length > 0 ? (
                                deletedLogs.map(log => (
                                    <tr key={log.id}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{log.documentType}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{log.documentIdentifier}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{toShamsi(log.deletedAt.split('T')[0])} ساعت {new Date(log.deletedAt).toLocaleTimeString('fa-IR')}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{log.deletedBy}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                        هیچ سند حذف شده‌ای برای نمایش وجود ندارد.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DeletedDocumentsManagement;
