
import React, { useMemo, useEffect } from 'react';
import type { LaborForecastRow, Personnel, FiscalYear } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

interface DirectLaborForecastProps {
    personnelList: Personnel[];
    fiscalYears: FiscalYear[];
    data: LaborForecastRow[];
    setData: React.Dispatch<React.SetStateAction<LaborForecastRow[]>>;
}

const DirectLaborForecast: React.FC<DirectLaborForecastProps> = ({ personnelList, fiscalYears, data, setData }) => {

    const positionsData = useMemo(() => {
        const positions = new Map<string, { personnel: Personnel[], totalMonthlySalary: number }>();
        personnelList.forEach(p => {
            if (!p.position) return;
            const posData = positions.get(p.position) || { personnel: [], totalMonthlySalary: 0 };
            posData.personnel.push(p);
            const activeContract = p.contracts.find(c => c.status === 'active');
            if (activeContract) {
                // Assuming 25 working days, 8 hours a day
                posData.totalMonthlySalary += activeContract.hourlyWage * 8 * 25;
            }
            positions.set(p.position, posData);
        });
        
        const result: { position: string, employeeCount: number, avgMonthlySalary: number }[] = [];
        positions.forEach((data, position) => {
            result.push({
                position,
                employeeCount: data.personnel.length,
                avgMonthlySalary: data.personnel.length > 0 ? data.totalMonthlySalary / data.personnel.length : 0,
            });
        });
        return result;
    }, [personnelList]);

    useEffect(() => {
        if (data.length === 0 && positionsData.length > 0) {
            const initialData = positionsData.map(p => ({
                position: p.position,
                salaryIncreasePercent: 0,
                monthlyEmployeeCount: Array.from({ length: 12 }, (_, i) => ({ month: i + 1, value: p.employeeCount })),
            }));
            setData(initialData);
        }
    }, [data, positionsData, setData]);
    
    const fiscalYear = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0] : null, [fiscalYears]);
    const mainCurrency = fiscalYear?.mainCurrency || 'IRR';

    const handleDataChange = (position: string, field: 'increase' | 'employeeCount', value: number, month?: number) => {
        const newData = data.map(row => {
            if (row.position === position) {
                if (field === 'employeeCount' && month) {
                    const newCounts = row.monthlyEmployeeCount.map(mc => 
                        mc.month === month ? { ...mc, value } : mc
                    );
                    return { ...row, monthlyEmployeeCount: newCounts };
                }
                if (field === 'increase') {
                    return { ...row, salaryIncreasePercent: value };
                }
            }
            return row;
        });
        setData(newData);
    };
    
    const handleExport = () => {
        const headers = [
            "سمت", "تعداد پرسنل", "میانگین حقوق فعلی", "افزایش حقوق (%)", "حقوق پیش‌بینی شده",
            ...Array.from({length: 12}, (_, i) => `تعداد پرسنل ماه ${i+1}`),
            `جمع کل (${mainCurrency})`,
        ];

        const rows = data.map(row => {
            const posInfo = positionsData.find(p => p.position === row.position);
            if (!posInfo) return null;

            const increase = Number(row.salaryIncreasePercent) || 0;
            const predictedSalary = posInfo.avgMonthlySalary * (1 + increase / 100);
            const totalCost = row.monthlyEmployeeCount.reduce((sum, mc) => {
                return sum + (Number(mc.value) || 0) * predictedSalary;
            }, 0);
            
            const monthlyCounts = row.monthlyEmployeeCount.map(mc => mc.value || 0);

            return [
                row.position,
                posInfo.employeeCount,
                posInfo.avgMonthlySalary,
                increase,
                predictedSalary,
                ...monthlyCounts,
                totalCost,
            ].map(v => typeof v === 'number' ? v.toFixed(0) : v);
        }).filter(Boolean);

        exportToCsv("پیشبینی-دستمزد.csv", [headers, ...rows as (string|number)[][]]);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">پیش‌بینی دستمزد مستقیم</h1>
                <button onClick={handleExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">خروجی اکسل</button>
            </div>
             <Card className="p-0 overflow-hidden">
                 <div className="overflow-auto border-b dark:border-slate-700" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                    <table className="min-w-full w-max border-collapse text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-20 shadow-sm">
                            <tr>
                                <th className="px-3 py-3 text-right font-semibold sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30 whitespace-nowrap">سمت</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">تعداد پرسنل</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">میانگین حقوق فعلی</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">افزایش حقوق (%)</th>
                                <th className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">حقوق پیش‌بینی شده</th>
                                {Array.from({ length: 12 }).map((_, i) => <th key={i} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">{i + 1}</th>)}
                                <th className="px-3 py-3 text-center font-semibold border-b dark:border-slate-700 whitespace-nowrap">جمع کل ({mainCurrency})</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white dark:bg-slate-900">
                             {data.map(row => {
                                const posInfo = positionsData.find(p => p.position === row.position);
                                if (!posInfo) return null;

                                const increase = Number(row.salaryIncreasePercent) || 0;
                                const predictedSalary = posInfo.avgMonthlySalary * (1 + increase / 100);
                                const totalCost = row.monthlyEmployeeCount.reduce((sum, mc) => {
                                    return sum + (Number(mc.value) || 0) * predictedSalary;
                                }, 0);
                                
                                return (
                                <tr key={row.position} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td className="px-3 py-2 font-semibold whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50 border-l border-b dark:border-slate-700 z-10">{row.position}</td>
                                    <td className="px-3 py-2 text-center border-l border-b dark:border-slate-700">{posInfo.employeeCount}</td>
                                    <td className="px-3 py-2 font-mono text-center border-l border-b dark:border-slate-700">{posInfo.avgMonthlySalary.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    <td className="border-l border-b dark:border-slate-700 w-24"><FormattedNumberInput value={row.salaryIncreasePercent} onValueChange={val => handleDataChange(row.position, 'increase', val)} className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700" /></td>
                                    <td className="px-3 py-2 font-mono text-center font-semibold border-l border-b dark:border-slate-700">{predictedSalary.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    {row.monthlyEmployeeCount.map(mc => (
                                        <td key={mc.month} className="border-l border-b dark:border-slate-700 w-20">
                                            <FormattedNumberInput 
                                                value={mc.value} 
                                                onValueChange={(val) => handleDataChange(row.position, 'employeeCount', val, mc.month)} 
                                                className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700"
                                            />
                                        </td>
                                    ))}
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-b dark:border-slate-700">{totalCost.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                </tr>
                                )
                             })}
                         </tbody>
                    </table>
                 </div>
            </Card>
        </div>
    );
};

export default DirectLaborForecast;
