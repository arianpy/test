
import React, { useState, useMemo } from 'react';
import type { Bank, TreasuryTransaction, Person } from '../../types';
import Card from '../ui/Card';
import { toShamsi } from '../../utils/date';

interface CashAndBankReportProps {
    banks: Bank[];
    transactions: TreasuryTransaction[];
    persons: Person[];
}

const formatNumber = (num: number) => new Intl.NumberFormat('fa-IR').format(num);

const CashAndBankReport: React.FC<CashAndBankReportProps> = ({ banks, transactions, persons }) => {
    const [activeTab, setActiveTab] = useState<'cash' | 'receivedDocs' | 'paidDocs'>('cash');
    const [selectedBankId, setSelectedBankId] = useState<number | null>(null);

    const personMap = useMemo(() => new Map(persons.map(p => [p.id, p.personType === 'natural' ? `${p.firstName} ${p.lastName}` : p.registeredName])), [persons]);

    const bankBalances = useMemo(() => {
        const balances = new Map<number, { deposits: number; withdrawals: number }>();
        transactions.forEach(t => {
            if (t.destination.bankId) {
                const current = balances.get(t.destination.bankId) || { deposits: 0, withdrawals: 0 };
                current.deposits += t.amount;
                balances.set(t.destination.bankId, current);
            }
            if (t.source.bankId) {
                const current = balances.get(t.source.bankId) || { deposits: 0, withdrawals: 0 };
                current.withdrawals += t.amount;
                balances.set(t.source.bankId, current);
            }
        });
        return balances;
    }, [transactions]);

    const receivedDocs = useMemo(() =>
        transactions.filter(t => t.transactionType === 'اسناد' && t.operationType === 'دریافت').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    , [transactions]);

    const paidDocs = useMemo(() =>
        transactions.filter(t => t.transactionType === 'اسناد' && t.operationType === 'پرداخت').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    , [transactions]);
    
    const selectedBankTransactions = useMemo(() => {
        if (!selectedBankId) return [];
        const selectedBank = banks.find(b => b.id === selectedBankId);
        if (!selectedBank) return [];

        const relatedTransactions = transactions
            .filter(t => t.source.bankId === selectedBankId || t.destination.bankId === selectedBankId)
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        
        let runningBalance = selectedBank.openingBalance;
        return relatedTransactions.map(t => {
            const isDeposit = t.destination.bankId === selectedBankId;
            const change = isDeposit ? t.amount : -t.amount;
            runningBalance += change;
            return {
                ...t,
                deposit: isDeposit ? t.amount : 0,
                withdrawal: !isDeposit ? t.amount : 0,
                balance: runningBalance,
            };
        });
    }, [selectedBankId, transactions, banks]);

    const renderCashTab = () => (
        <div className="space-y-6">
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs uppercase">نام بانک</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">جمع واریز</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">جمع برداشت</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">مانده</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {banks.map(bank => {
                            const balance = bankBalances.get(bank.id) || { deposits: 0, withdrawals: 0 };
                            const finalBalance = bank.openingBalance + balance.deposits - balance.withdrawals;
                            return (
                                <tr key={bank.id} onClick={() => setSelectedBankId(bank.id)} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.mainBankName} - {bank.branchName}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono text-green-600">{formatNumber(balance.deposits)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono text-red-600">{formatNumber(balance.withdrawals)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono font-semibold">{formatNumber(finalBalance)}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
            {selectedBankId && (
                <div className="mt-6 pt-6 border-t dark:border-slate-700">
                     <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-slate-200">گردش حساب: {banks.find(b => b.id === selectedBankId)?.branchName}</h3>
                     <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                             <thead className="bg-slate-50 dark:bg-slate-700">
                                <tr>
                                    <th className="px-4 py-3 text-right text-xs uppercase">تاریخ</th>
                                    <th className="px-4 py-3 text-right text-xs uppercase">شرح</th>
                                    <th className="px-4 py-3 text-left text-xs uppercase">واریز</th>
                                    <th className="px-4 py-3 text-left text-xs uppercase">برداشت</th>
                                    <th className="px-4 py-3 text-left text-xs uppercase">مانده</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                <tr>
                                    <td colSpan={4} className="px-4 py-2 font-semibold">مانده اولیه</td>
                                    <td className="px-4 py-2 text-left font-mono font-semibold">{formatNumber(banks.find(b => b.id === selectedBankId)?.openingBalance || 0)}</td>
                                </tr>
                                {selectedBankTransactions.map(t => (
                                    <tr key={t.id}>
                                        <td className="px-4 py-4 whitespace-nowrap">{toShamsi(t.date)}</td>
                                        <td className="px-4 py-4">{t.description}</td>
                                        <td className="px-4 py-4 text-left font-mono text-green-600">{t.deposit > 0 ? formatNumber(t.deposit) : '-'}</td>
                                        <td className="px-4 py-4 text-left font-mono text-red-600">{t.withdrawal > 0 ? formatNumber(t.withdrawal) : '-'}</td>
                                        <td className="px-4 py-4 text-left font-mono font-semibold">{formatNumber(t.balance)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </div>
                </div>
            )}
        </div>
    );
    
    const renderDocsTab = (docs: TreasuryTransaction[], title: string) => (
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                <thead className="bg-slate-50 dark:bg-slate-700">
                    <tr>
                        <th className="px-4 py-3 text-right text-xs uppercase">تاریخ ثبت</th>
                        <th className="px-4 py-3 text-right text-xs uppercase">شماره سند</th>
                        <th className="px-4 py-3 text-right text-xs uppercase">تاریخ سررسید</th>
                        <th className="px-4 py-3 text-left text-xs uppercase">مبلغ</th>
                        <th className="px-4 py-3 text-right text-xs uppercase">طرف حساب</th>
                        <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                    </tr>
                </thead>
                <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                    {docs.map(doc => {
                        const party = title === 'دریافتی' ? doc.source : doc.destination;
                        return (
                            <tr key={doc.id}>
                                <td className="px-4 py-4 whitespace-nowrap">{toShamsi(doc.date)}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{party.docNumber}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{party.dueDate ? toShamsi(party.dueDate) : '-'}</td>
                                <td className="px-4 py-4 text-left font-mono">{formatNumber(doc.amount)}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{personMap.get(party.relatedPartyId || 0) || '-'}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{doc.status}</td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گزارش نقد و بانک</h1>
            <div className="border-b border-slate-200 dark:border-slate-700">
                <nav className="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
                    <button onClick={() => setActiveTab('cash')} className={`${activeTab === 'cash' ? 'border-custom-blue-primary text-custom-blue-primary' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'} whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm`}>نقد</button>
                    <button onClick={() => setActiveTab('receivedDocs')} className={`${activeTab === 'receivedDocs' ? 'border-custom-blue-primary text-custom-blue-primary' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'} whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm`}>اسناد دریافتی</button>
                    <button onClick={() => setActiveTab('paidDocs')} className={`${activeTab === 'paidDocs' ? 'border-custom-blue-primary text-custom-blue-primary' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'} whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm`}>اسناد پرداختی</button>
                </nav>
            </div>
            <Card>
                {activeTab === 'cash' && renderCashTab()}
                {activeTab === 'receivedDocs' && renderDocsTab(receivedDocs, 'دریافتی')}
                {activeTab === 'paidDocs' && renderDocsTab(paidDocs, 'پرداختی')}
            </Card>
        </div>
    );
};

export default CashAndBankReport;
