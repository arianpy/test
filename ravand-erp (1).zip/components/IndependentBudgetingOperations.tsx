import React, { useState } from 'react';
import type { HistoricalData, MonthlyIndicator } from '../types';
import Card from './ui/Card';

interface IndependentBudgetingOperationsProps {
    historicalGdp: HistoricalData[];
    historicalInflation: HistoricalData[];
    createForecast: (targetYear: number, baseYear: number, data: MonthlyIndicator[]) => void;
}

const initialMonthlyData: MonthlyIndicator[] = Array.from({ length: 12 }, (_, i) => ({
  month: i + 1,
  goldCoinPrice: 0,
  goldOuncePrice: 0,
  officialUsdRate: 0,
  usdToEurRate: 0,
}));

const monthNames = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
];

const IndependentBudgetingOperations: React.FC<IndependentBudgetingOperationsProps> = ({ historicalGdp, historicalInflation, createForecast }) => {
    const [baseYear, setBaseYear] = useState<string>('');
    const [monthlyData, setMonthlyData] = useState<MonthlyIndicator[]>(initialMonthlyData);

    const handleDataChange = (month: number, field: keyof Omit<MonthlyIndicator, 'month'>, value: string) => {
        const newData = [...monthlyData];
        const monthIndex = newData.findIndex(d => d.month === month);
        if(monthIndex > -1) {
            (newData[monthIndex] as any)[field] = Number(value);
        }
        setMonthlyData(newData);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!baseYear || historicalGdp.length < 2 || historicalInflation.length < 2) {
            alert("لطفاً سال پایه را مشخص کرده و اطمینان حاصل کنید که حداقل دو سال داده تاریخی برای GDP و تورم در بخش تعاریف وارد شده است.");
            return;
        }
        createForecast(Number(baseYear) + 1, Number(baseYear), monthlyData);
        alert(`پیش‌بینی برای سال ${Number(baseYear) + 1} با موفقیت ایجاد شد. نتایج را در بخش گزارشات مشاهده کنید.`);
        setBaseYear('');
        setMonthlyData(initialMonthlyData);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">عملیات بودجه ریزی مستقل</h1>
            <p className="text-slate-600 dark:text-slate-400">
                برای ایجاد یک پیش‌بینی جدید، سال پایه را مشخص کرده و شاخص‌های اقتصادی مربوط به هر ماه از آن سال را در جدول زیر وارد نمایید.
            </p>

            <Card>
                <form onSubmit={handleSubmit}>
                    <div className="mb-6">
                         <label htmlFor="baseYear" className="block text-sm font-medium text-slate-700 dark:text-slate-300">سال پایه برای محاسبات</label>
                        <input
                            id="baseYear"
                            type="number"
                            placeholder="مثال: 1402"
                            value={baseYear}
                            onChange={(e) => setBaseYear(e.target.value)}
                            required
                            className="mt-1 block w-full md:w-1/3 px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"
                        />
                    </div>

                    <h3 className="text-lg font-semibold mb-4">ورود داده‌های ماهانه سال پایه</h3>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                             <thead className="bg-slate-50 dark:bg-slate-700">
                                <tr>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">ماه</th>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">تمام سکه (ریال)</th>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">انس طلا (دلار)</th>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">دلار دستوری (ریال)</th>
                                    <th className="px-4 py-3 text-right text-xs font-medium uppercase">نرخ تبدیل دلار به یورو</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                {monthlyData.map(({ month }) => (
                                    <tr key={month}>
                                        <td className="px-4 py-2 whitespace-nowrap">{monthNames[month-1]}</td>
                                        <td><input type="number" className="w-full bg-transparent p-2 focus:outline-none" onChange={(e) => handleDataChange(month, 'goldCoinPrice', e.target.value)} /></td>
                                        <td><input type="number" className="w-full bg-transparent p-2 focus:outline-none" onChange={(e) => handleDataChange(month, 'goldOuncePrice', e.target.value)} /></td>
                                        <td><input type="number" className="w-full bg-transparent p-2 focus:outline-none" onChange={(e) => handleDataChange(month, 'officialUsdRate', e.target.value)} /></td>
                                        <td><input type="number" step="0.0001" className="w-full bg-transparent p-2 focus:outline-none" onChange={(e) => handleDataChange(month, 'usdToEurRate', e.target.value)} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                     <div className="flex justify-end pt-8">
                        <button type="submit" className="px-8 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
                            ایجاد پیش‌بینی
                        </button>
                    </div>

                </form>
            </Card>
        </div>
    );
};

export default IndependentBudgetingOperations;