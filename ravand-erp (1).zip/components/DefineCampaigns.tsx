import React, { useState, useMemo, useEffect } from 'react';
import type { Campaign, CampaignMedia, CampaignAudienceGroup, Auditable } from '../types';
import { CampaignStatus } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface DefineCampaignsProps {
    campaigns: Campaign[];
    addCampaign: (campaign: Omit<Campaign, 'id' | keyof Auditable>) => void;
    updateCampaign: (campaign: Campaign) => void;
    deleteCampaign: (id: number) => void;
    audienceGroups: CampaignAudienceGroup[];
}

const FormInput: React.FC<(React.InputHTMLAttributes<HTMLInputElement> | React.TextareaHTMLAttributes<HTMLTextAreaElement>) & { label: string, as?: 'input' | 'textarea' }> = ({ label, id, as = 'input', ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {as === 'textarea' ?
            <textarea id={id} {...props as React.TextareaHTMLAttributes<HTMLTextAreaElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" /> :
            <input id={id} {...props as React.InputHTMLAttributes<HTMLInputElement>} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm" />
        }
    </div>
);

const DefineCampaigns: React.FC<DefineCampaignsProps> = ({ campaigns, addCampaign, updateCampaign, deleteCampaign, audienceGroups }) => {
    
    const getInitialState = (): Omit<Campaign, 'id' | keyof Auditable> => ({
        date: new Date().toISOString().split('T')[0],
        name: '',
        slogan: '',
        audienceGroupId: null,
        roi: '',
        kpi: '',
        status: CampaignStatus.Planned,
        budget: 0,
        description: '',
        media: [],
    });

    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);

    const audienceGroupOptions = useMemo(() => audienceGroups.map(g => ({ value: g.id, label: g.name })), [audienceGroups]);
    const mediaTypeOptions = [
        { value: 'Social Media', label: 'شبکه اجتماعی' },
        { value: 'Email', label: 'ایمیل' },
        { value: 'SMS', label: 'پیامک' },
        { value: 'Banner', label: 'بنر' },
        { value: 'Other', label: 'سایر' },
    ];

    const handleEditClick = (campaign: Campaign) => {
        setEditingId(campaign.id);
        setFormData({ ...campaign });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleClearForm = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };
    
    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        const dataToSave = {
            ...formData,
            budget: Number(formData.budget) || 0,
        };
        if (editingId !== null) {
            // FIX: Cast the object to Campaign to include the existing auditable properties, resolving the type error.
            updateCampaign(dataToSave as Campaign);
        } else {
            addCampaign(dataToSave);
        }
        handleClearForm();
    };

    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این کمپین اطمینان دارید؟')) {
            deleteCampaign(id);
        }
    };
    
    const handleAddMedia = () => {
        const newMedia: CampaignMedia = {
            id: Date.now(),
            type: 'Other',
            cost: 0,
            description: ''
        };
        setFormData(prev => ({...prev, media: [...prev.media, newMedia]}));
    };
    
    const handleMediaChange = (id: number, field: keyof Omit<CampaignMedia, 'id'>, value: any) => {
        setFormData(prev => ({
            ...prev,
            media: prev.media.map(m => m.id === id ? {...m, [field]: value} : m)
        }));
    };

    const handleRemoveMedia = (id: number) => {
        setFormData(prev => ({
            ...prev,
            media: prev.media.filter(m => m.id !== id)
        }));
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">مدیریت کمپین‌ها</h1>
             <Card>
                <form onSubmit={handleSave} className="space-y-6">
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">
                        {editingId ? `ویرایش کمپین: ${formData.name}` : 'ایجاد کمپین جدید'}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <FormInput label="نام کمپین" value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required />
                        <FormInput label="شعار کمپین" value={formData.slogan} onChange={e => setFormData(p => ({ ...p, slogan: e.target.value }))} />
                         <div>
                            <label className="block text-sm font-medium mb-1">تاریخ</label>
                            <ShamsiDatePicker value={formData.date} onChange={date => setFormData(p => ({...p, date}))} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">گروه مخاطبان</label>
                            <SearchableSelect options={audienceGroupOptions} value={formData.audienceGroupId} onChange={val => setFormData(p => ({ ...p, audienceGroupId: val as number }))} />
                        </div>
                        <FormInput label="شاخص KPI" value={formData.kpi} onChange={e => setFormData(p => ({...p, kpi: e.target.value }))} />
                        <FormInput label="شاخص ROI" value={formData.roi} onChange={e => setFormData(p => ({...p, roi: e.target.value }))} />
                        <div>
                            <label className="block text-sm font-medium">هزینه برآوردی</label>
                            <FormattedNumberInput value={formData.budget} onValueChange={val => setFormData(p => ({ ...p, budget: val }))} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md" />
                        </div>
                         <div>
                            <label className="block text-sm font-medium">وضعیت</label>
                            <SearchableSelect options={Object.values(CampaignStatus).map(s => ({ value: s, label: s }))} value={formData.status} onChange={val => setFormData(p => ({ ...p, status: val as CampaignStatus }))} />
                        </div>
                        <div className="lg:col-span-3">
                            <FormInput label="توضیحات" as="textarea" rows={2} value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} />
                        </div>
                    </div>
                     <div className="pt-4 border-t dark:border-slate-600 space-y-4">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">رسانه‌های کمپین</h3>
                            <button type="button" onClick={handleAddMedia} className="px-4 py-2 text-sm text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن رسانه</button>
                        </div>
                        {formData.media.map(m => (
                            <div key={m.id} className="grid grid-cols-1 md:grid-cols-4 gap-2 items-center p-2 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                                <SearchableSelect options={mediaTypeOptions} value={m.type} onChange={val => handleMediaChange(m.id, 'type', val)} />
                                <FormattedNumberInput value={m.cost} onValueChange={val => handleMediaChange(m.id, 'cost', val)} placeholder="هزینه" className="w-full bg-white dark:bg-slate-700 p-2 border rounded" />
                                <div className="md:col-span-2 flex items-center gap-2">
                                <input type="text" value={m.description} onChange={e => handleMediaChange(m.id, 'description', e.target.value)} placeholder="توضیحات رسانه" className="w-full bg-white dark:bg-slate-700 p-2 border rounded"/>
                                <button type="button" onClick={() => handleRemoveMedia(m.id)} className="text-red-500 p-1">&times;</button>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                        {editingId && <button type="button" onClick={handleClearForm} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو ویرایش</button>}
                        <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">{editingId ? 'ذخیره تغییرات' : 'ذخیره کمپین'}</button>
                    </div>
                </form>
            </Card>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام کمپین</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                                <th className="px-4 py-3 text-left text-xs uppercase">بودجه</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {campaigns.length > 0 ? campaigns.map(c => (
                                <tr key={c.id}>
                                    <td className="px-4 py-4 font-medium">{c.name}</td>
                                    <td className="px-4 py-4">{toShamsi(c.date)}</td>
                                    <td className="px-4 py-4">{c.status}</td>
                                    <td className="px-4 py-4 text-left font-mono">{c.budget.toLocaleString()}</td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleEditClick(c)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(c.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={5} className="text-center py-6">هیچ کمپینی یافت نشد.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DefineCampaigns;
