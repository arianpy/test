

import React, { useMemo, useEffect } from 'react';
import type { SalesForecastRow, ProductGroup, Product, SalesInvoice, FiscalYear } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string | number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            innerValue = innerValue.replace(/"/g, '""');
            if (innerValue.search(/("|,|\n)/g) >= 0) {
                innerValue = `"${innerValue}"`;
            }
            if (j > 0) {
                finalVal += ',';
            }
            finalVal += innerValue;
        }
        return finalVal + '\r\n';
    };

    const BOM = '\uFEFF';
    let csvFile = BOM;
    for (const row of rows) {
        csvFile += processRow(row);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};


interface SalesForecastProps {
    productGroups: ProductGroup[];
    products: Product[];
    salesInvoices: SalesInvoice[];
    fiscalYears: FiscalYear[];
    data: SalesForecastRow[];
    setData: React.Dispatch<React.SetStateAction<SalesForecastRow[]>>;
    predictedExchangeRate: number;
}

const SalesForecast: React.FC<SalesForecastProps> = ({ productGroups, products, salesInvoices, fiscalYears, data, setData, predictedExchangeRate }) => {

    useEffect(() => {
        if (data.length === 0 && productGroups.length > 0) {
            const initialData = productGroups.map(group => ({
                productGroupId: group.id,
                monthlyQuantities: Array.from({ length: 12 }, (_, i) => ({ month: i + 1, value: 0 })),
            }));
            setData(initialData);
        }
    }, [data, productGroups, setData]);
    
    const fiscalYear = useMemo(() => fiscalYears.length > 0 ? fiscalYears[0] : null, [fiscalYears]);
    // FIX: Use the predictedExchangeRate prop instead of trying to access it from the fiscalYear object.
    const exchangeRate = predictedExchangeRate || 1;
    const mainCurrency = fiscalYear?.mainCurrency || 'IRR';
    const secondaryCurrency = fiscalYear?.secondaryCurrency || 'USD';

    const avgProductPrices = useMemo(() => {
        const priceData = new Map<number, { totalValue: number; totalQty: number }>();
        salesInvoices.forEach(invoice => {
            invoice.items.forEach(item => {
                const current = priceData.get(item.productId) || { totalValue: 0, totalQty: 0 };
                current.totalQty += item.quantity;
                current.totalValue += item.unitPrice * item.quantity * (1 - item.discount / 100);
                priceData.set(item.productId, current);
            });
        });
        const avgPrices = new Map<number, number>();
        priceData.forEach((data, productId) => {
            if (data.totalQty > 0) {
                avgPrices.set(productId, data.totalValue / data.totalQty);
            }
        });
        products.forEach(p => {
            if (!avgPrices.has(p.id)) {
                avgPrices.set(p.id, p.cost); // Fallback to cost if no sales data
            }
        });
        return avgPrices;
    }, [salesInvoices, products]);

    const avgGroupPrices = useMemo(() => {
        const groupPrices = new Map<number, number>();
        const productsByGroup = new Map<number, number[]>();
        products.forEach(p => {
            const groupProducts = productsByGroup.get(p.productGroupId) || [];
            groupProducts.push(p.id);
            productsByGroup.set(p.productGroupId, groupProducts);
        });

        productsByGroup.forEach((prodIds, groupId) => {
            const prices = prodIds.map(id => avgProductPrices.get(id) || 0).filter(p => p > 0);
            if (prices.length > 0) {
                const avgPrice = prices.reduce((sum, p) => sum + p, 0) / prices.length;
                groupPrices.set(groupId, avgPrice);
            } else {
                 groupPrices.set(groupId, 0);
            }
        });
        return groupPrices;
    }, [products, avgProductPrices]);

    const handleQuantityChange = (groupId: number, month: number, value: number) => {
        const newData = data.map(row => {
            if (row.productGroupId === groupId) {
                const newQuantities = row.monthlyQuantities.map(mq => 
                    mq.month === month ? { ...mq, value } : mq
                );
                return { ...row, monthlyQuantities: newQuantities };
            }
            return row;
        });
        setData(newData);
    };
    
    const handleExport = () => {
        const headers = [
            "گروه محصول",
            ...Array.from({ length: 12 }, (_, i) => `تعداد ماه ${i + 1}`),
            `جمع کل (${mainCurrency})`,
            `جمع کل (${secondaryCurrency})`,
        ];

        const rows = data.map(row => {
            const group = productGroups.find(g => g.id === row.productGroupId);
            if (!group) return null;

            const avgPrice = avgGroupPrices.get(group.id) || 0;
            const totalQty = row.monthlyQuantities.reduce((sum, mq) => sum + (Number(mq.value) || 0), 0);
            const totalValueMain = totalQty * avgPrice;
            const totalValueSecondary = totalValueMain / exchangeRate;
            
            const monthlyQuantities = row.monthlyQuantities.map(mq => mq.value || 0);

            return [
                group.title,
                ...monthlyQuantities,
                totalValueMain,
                totalValueSecondary,
            ].map(v => typeof v === 'number' ? v.toFixed(2) : v);
        }).filter(Boolean);

        exportToCsv("پیشبینی-فروش.csv", [headers, ...rows as (string|number)[][]]);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">پیش‌بینی فروش</h1>
                <button onClick={handleExport} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">خروجی اکسل</button>
            </div>
             <Card className="p-0 overflow-hidden">
                 <div className="overflow-auto border-b dark:border-slate-700" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                    <table className="min-w-full w-max border-collapse text-sm">
                        <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0 z-20 shadow-sm">
                            <tr>
                                <th rowSpan={2} className="px-3 py-3 text-right font-semibold align-middle sticky right-0 bg-slate-100 dark:bg-slate-800 border-l border-b dark:border-slate-700 z-30 whitespace-nowrap">گروه محصول</th>
                                <th rowSpan={2} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">متوسط قیمت فروش</th>
                                {Array.from({ length: 12 }).map((_, i) => <th key={i} colSpan={2} className="px-3 py-3 text-center font-medium border-l border-b dark:border-slate-700 whitespace-nowrap">{i + 1}</th>)}
                                <th colSpan={3} className="px-3 py-3 text-center font-semibold border-l border-b dark:border-slate-700 whitespace-nowrap">جمع کل سالانه</th>
                            </tr>
                            <tr>
                                {Array.from({length: 12}).map((_, i) => (
                                    <React.Fragment key={i}>
                                        <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">تعداد</th>
                                        <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">مبلغ</th>
                                    </React.Fragment>
                                ))}
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">تعداد</th>
                                <th className="px-2 py-2 font-normal border-l border-b dark:border-slate-700 whitespace-nowrap">مبلغ ({mainCurrency})</th>
                                <th className="px-2 py-2 font-normal border-b dark:border-slate-700 whitespace-nowrap">مبلغ ({secondaryCurrency})</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-900">
                             {data.map(row => {
                                const group = productGroups.find(g => g.id === row.productGroupId);
                                if (!group) return null;

                                const avgPrice = avgGroupPrices.get(group.id) || 0;
                                const totalQty = row.monthlyQuantities.reduce((sum, mq) => sum + (Number(mq.value) || 0), 0);
                                const totalValueMain = totalQty * avgPrice;
                                const totalValueSecondary = totalValueMain / exchangeRate;
                                
                                return (
                                <tr key={group.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td className="px-3 py-2 font-semibold whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50 border-l border-b dark:border-slate-700 z-10">{group.title}</td>
                                    <td className="px-3 py-2 font-mono text-center border-l border-b dark:border-slate-700">{avgPrice.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    {row.monthlyQuantities.map(mq => {
                                        const monthlyValue = (Number(mq.value) || 0) * avgPrice;
                                        return (
                                        <React.Fragment key={mq.month}>
                                            <td className="border-l border-b dark:border-slate-700 w-24">
                                                <FormattedNumberInput 
                                                    value={mq.value} 
                                                    onValueChange={(val) => handleQuantityChange(group.id, mq.month, val)} 
                                                    className="w-full h-full bg-transparent p-2 text-center focus:outline-none focus:bg-slate-100 dark:focus:bg-slate-700"
                                                />
                                            </td>
                                            <td className="px-3 py-2 font-mono text-center border-l border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 w-36">{monthlyValue.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                        </React.Fragment>
                                    )})}
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-l border-b dark:border-slate-700 w-28">{totalQty.toLocaleString('en-US')}</td>
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-l border-b dark:border-slate-700 w-36">{totalValueMain.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                    <td className="px-3 py-2 font-semibold font-mono text-center border-b dark:border-slate-700 w-36">{totalValueSecondary.toLocaleString('en-US', {maximumFractionDigits: 0})}</td>
                                </tr>
                                )
                             })}
                         </tbody>
                    </table>
                 </div>
            </Card>
        </div>
    );
};

export default SalesForecast;