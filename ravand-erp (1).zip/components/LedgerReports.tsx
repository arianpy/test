import React, { useState, useMemo } from 'react';
import type { AccountHeadGroup, AccountingDocument, Currency } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface LedgerReportsProps {
    accountHeads: AccountHeadGroup[];
    accountingDocuments: AccountingDocument[];
    currencies: Currency[];
}

type ReportFormat = '2-column' | '4-column' | '6-column' | '8-column';

const formatNumber = (num: number) => new Intl.NumberFormat('fa-IR').format(num);

const LedgerReports: React.FC<LedgerReportsProps> = ({ accountHeads, accountingDocuments, currencies }) => {
    const [selectedSubLedgerId, setSelectedSubLedgerId] = useState<number | null>(null);
    const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
    const [format, setFormat] = useState<ReportFormat>('4-column');

    const subLedgerOptions = useMemo(() => 
        accountHeads.flatMap(g => g.children.flatMap(l => l.children.map(sl => ({
            value: sl.id,
            label: `${sl.code} - ${sl.title}`
        }))))
    , [accountHeads]);
    
    const currencyMap = useMemo(() => new Map(currencies.map(c => [c.code, c.name])), [currencies]);

    const reportData = useMemo(() => {
        if (!selectedSubLedgerId) return [];
        
        const transactions = accountingDocuments
            .filter(doc => doc.date >= startDate && doc.date <= endDate)
            .flatMap(doc => doc.rows.filter(row => row.subLedgerId === selectedSubLedgerId).map(row => ({...row, docDate: doc.date, docNum: doc.docNumber, currencyCode: doc.currencyCode, exchangeRate: doc.exchangeRate })));

        let runningBalance = 0;
        let runningCurrencyBalance = 0;

        return transactions.map(row => {
            runningBalance += row.debit - row.credit;
            runningCurrencyBalance += row.currencyDebit - row.currencyCredit;
            return {
                ...row,
                balance: runningBalance,
                balanceType: runningBalance > 0 ? 'بد' : runningBalance < 0 ? 'بس' : '-',
                currencyBalance: runningCurrencyBalance,
                currencyBalanceType: runningCurrencyBalance > 0 ? 'بد' : runningCurrencyBalance < 0 ? 'بس' : '-',
            };
        });
    }, [selectedSubLedgerId, startDate, endDate, accountingDocuments]);

    const renderTable = () => {
        if (!selectedSubLedgerId) {
            return <p className="text-center p-8 text-slate-500">لطفا یک حساب معین برای نمایش گزارش انتخاب کنید.</p>;
        }
        if (reportData.length === 0) {
            return <p className="text-center p-8 text-slate-500">هیچ تراکنشی در محدوده تاریخ انتخابی برای این حساب یافت نشد.</p>;
        }
        
        const currencyCode = reportData[0]?.currencyCode || 'IRR';

        return (
             <div className="overflow-x-auto">
                <table className="min-w-full w-full text-sm">
                    <thead className="bg-slate-100 dark:bg-slate-800">
                        <tr>
                            <th className="p-2 text-right">تاریخ</th>
                            <th className="p-2 text-right">شماره سند</th>
                            <th className="p-2 text-right" style={{minWidth: '200px'}}>شرح</th>
                            {(format === '6-column' || format === '8-column') && <th className="p-2 text-left">بدهکار ارزی</th>}
                            {(format === '6-column' || format === '8-column') && <th className="p-2 text-left">بستانکار ارزی</th>}
                            {format === '8-column' && <th className="p-2 text-left">مانده ارزی</th>}
                            {format === '8-column' && <th className="p-2 text-center">تشخیص</th>}
                            <th className="p-2 text-left">بدهکار</th>
                            <th className="p-2 text-left">بستانکار</th>
                            {(format === '4-column' || format === '6-column' || format === '8-column') && <th className="p-2 text-left">مانده</th>}
                            {(format === '4-column' || format === '6-column' || format === '8-column') && <th className="p-2 text-center">تشخیص</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {reportData.map(row => (
                            <tr key={row.id} className="border-b dark:border-slate-700">
                                <td className="p-2">{toShamsi(row.docDate)}</td>
                                <td className="p-2">{row.docNum}</td>
                                <td className="p-2">{row.description}</td>
                                {(format === '6-column' || format === '8-column') && <td className="p-2 text-left font-mono">{formatNumber(row.currencyDebit)}</td>}
                                {(format === '6-column' || format === '8-column') && <td className="p-2 text-left font-mono">{formatNumber(row.currencyCredit)}</td>}
                                {format === '8-column' && <td className="p-2 text-left font-mono">{formatNumber(Math.abs(row.currencyBalance))}</td>}
                                {format === '8-column' && <td className="p-2 text-center">{row.currencyBalanceType}</td>}
                                <td className="p-2 text-left font-mono">{formatNumber(row.debit)}</td>
                                <td className="p-2 text-left font-mono">{formatNumber(row.credit)}</td>
                                {(format === '4-column' || format === '6-column' || format === '8-column') && <td className="p-2 text-left font-mono">{formatNumber(Math.abs(row.balance))}</td>}
                                {(format === '4-column' || format === '6-column' || format === '8-column') && <td className="p-2 text-center">{row.balanceType}</td>}
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        )
    }

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گزارش دفاتر</h1>
            <Card>
                <div className="p-4 border dark:border-slate-700 rounded-lg mb-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                    <div className="lg:col-span-2">
                        <label className="block text-sm font-medium mb-1">حساب معین</label>
                        <SearchableSelect options={subLedgerOptions} value={selectedSubLedgerId} onChange={val => setSelectedSubLedgerId(val as number)} placeholder="یک حساب انتخاب کنید..." />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">از تاریخ</label>
                        <ShamsiDatePicker value={startDate} onChange={setStartDate} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium mb-1">تا تاریخ</label>
                        <ShamsiDatePicker value={endDate} onChange={setEndDate} />
                    </div>
                     <div className="lg:col-span-2">
                        <label className="block text-sm font-medium mb-1">قالب گزارش</label>
                        <select value={format} onChange={e => setFormat(e.target.value as ReportFormat)} className="w-full p-2 bg-white dark:bg-slate-700 border rounded-md">
                            <option value="2-column">۲ ستونی</option>
                            <option value="4-column">۴ ستونی</option>
                            <option value="6-column">۶ ستونی (با ارز)</option>
                            <option value="8-column">۸ ستونی (با ارز)</option>
                        </select>
                    </div>
                </div>
                {renderTable()}
            </Card>
        </div>
    );
};

export default LedgerReports;
