import React, { useState, useMemo } from 'react';
import type { TreasuryTransaction, Person } from '../types';
import { TreasuryTransactionType, TreasuryOperationType } from '../types';
import Card from './ui/Card';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';

interface DocumentManagementProps {
    transactions: TreasuryTransaction[];
    updateTransaction: (transaction: TreasuryTransaction) => void;
    persons: Person[];
}

type ActionType = 'assignToBank' | 'returnFromAssigned' | 'return' | 'reclaim' | 'cancel';
type ActionTarget = { type: ActionType; transaction: TreasuryTransaction };

// Action Form component
const ActionForm: React.FC<{
    actionTarget: ActionTarget;
    onCancel: () => void;
    onConfirm: (transactionId: number, date: string, description: string) => void;
}> = ({ actionTarget, onCancel, onConfirm }) => {
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [description, setDescription] = useState('');

    const titleMap: Record<ActionType, string> = {
        assignToBank: 'واگذاری سند به بانک',
        returnFromAssigned: 'برگشت سند واگذار شده',
        return: 'عودت سند',
        reclaim: 'استرداد سند',
        cancel: 'ابطال سند',
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onConfirm(actionTarget.transaction.id, date, description);
    };

    return (
        <Card className="mt-6 border-t-4 border-cyan-500 animate-fade-in-down">
            <h3 className="text-lg font-semibold mb-4">{titleMap[actionTarget.type]} شماره {actionTarget.transaction.docNumber}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium mb-1">تاریخ عملیات</label>
                        <ShamsiDatePicker value={date} onChange={setDate} required />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium mb-1">توضیحات</label>
                        <textarea
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            rows={2}
                            className="w-full p-2 border rounded-md bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        />
                    </div>
                </div>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                    <button type="button" onClick={onCancel} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">انصراف</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">تایید {titleMap[actionTarget.type].split(' ')[0]}</button>
                </div>
            </form>
        </Card>
    );
};

// Main Component
const DocumentManagement: React.FC<DocumentManagementProps> = ({ transactions, updateTransaction, persons }) => {
    const [activeTab, setActiveTab] = useState<ActionType>('assignToBank');
    const [actionTarget, setActionTarget] = useState<ActionTarget | null>(null);

    const personMap = useMemo(() => new Map(persons.map(p => [p.id, p.personType === 'natural' ? `${p.firstName} ${p.lastName}` : p.registeredName])), [persons]);

    const receivableDocs = useMemo(() => transactions.filter(t =>
        t.transactionType === TreasuryTransactionType.Document && t.operationType === TreasuryOperationType.Receipt && t.status === 'active' && t.source.type === 'party'
    ), [transactions]);

    const payableDocs = useMemo(() => transactions.filter(t =>
        t.transactionType === TreasuryTransactionType.Document && t.operationType === TreasuryOperationType.Payment && t.status === 'active' && t.destination.type === 'party'
    ), [transactions]);
    
    const assignedToBankDocs = useMemo(() => transactions.filter(t =>
        t.transactionType === TreasuryTransactionType.Document && t.status === 'assignedToBank'
    ), [transactions]);
    
    const allActiveDocs = useMemo(() => transactions.filter(t =>
        t.transactionType === TreasuryTransactionType.Document && t.status === 'active'
    ), [transactions]);

    const handleActionConfirm = (transactionId: number, date: string, description: string) => {
        if (!actionTarget) return;
        
        const statusMap: Record<ActionType, TreasuryTransaction['status']> = {
            assignToBank: 'assignedToBank',
            returnFromAssigned: 'active',
            return: 'returned',
            reclaim: 'reclaimed',
            cancel: 'cancelled',
        };

        const updatedTransaction: TreasuryTransaction = {
            ...actionTarget.transaction,
            status: statusMap[actionTarget.type],
            statusChangeDate: date,
            statusChangeDescription: description,
        };
        updateTransaction(updatedTransaction);
        setActionTarget(null);
    };

    const renderTable = (docs: TreasuryTransaction[], actionType: ActionType) => {
        const actionTextMap: Record<ActionType, string> = {
            assignToBank: 'واگذاری به بانک',
            returnFromAssigned: 'برگشت از واگذاری',
            return: 'عودت',
            reclaim: 'استرداد',
            cancel: 'ابطال',
        };
        
        return (
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">شماره سند</th>
                            <th className="px-4 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">تاریخ</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">مبلغ</th>
                            <th className="px-4 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">طرف حساب</th>
                            <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عملیات</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {docs.length > 0 ? docs.map(doc => (
                            <tr key={doc.id}>
                                <td className="px-4 py-4 whitespace-nowrap">{doc.docNumber || doc.source.docNumber || doc.destination.docNumber}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{toShamsi(doc.date)}</td>
                                <td className="px-4 py-4 whitespace-nowrap font-mono">{doc.amount.toLocaleString()}</td>
                                <td className="px-4 py-4 whitespace-nowrap">{personMap.get(doc.source.relatedPartyId || doc.destination.relatedPartyId || 0) || '-'}</td>
                                <td className="px-4 py-4 whitespace-nowrap text-center">
                                    <button onClick={() => setActionTarget({ type: actionType, transaction: doc })} className="text-cyan-600 hover:underline">
                                        {actionTextMap[actionType]}
                                    </button>
                                </td>
                            </tr>
                        )) : (
                            <tr><td colSpan={5} className="text-center py-6 text-slate-500 dark:text-slate-400">سندی برای این عملیات یافت نشد.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        );
    }

    const tabContent: Record<ActionType, React.ReactNode> = {
        assignToBank: renderTable(receivableDocs, 'assignToBank'),
        returnFromAssigned: renderTable(assignedToBankDocs, 'returnFromAssigned'),
        return: renderTable(receivableDocs, 'return'),
        reclaim: renderTable(payableDocs, 'reclaim'),
        cancel: renderTable(allActiveDocs, 'cancel'),
    };

    const tabLabels: Record<ActionType, string> = {
        assignToBank: 'واگذار به بانک',
        returnFromAssigned: 'برگشت واگذار به بانک',
        return: 'عودت اسناد',
        reclaim: 'استرداد اسناد',
        cancel: 'ابطال اسناد',
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">مدیریت اسناد خزانه</h1>
            
            <div className="border-b border-slate-200 dark:border-slate-700">
                <nav className="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
                    {(Object.keys(tabLabels) as ActionType[]).map(tabKey => (
                         <button
                            key={tabKey}
                            onClick={() => { setActiveTab(tabKey); setActionTarget(null); }}
                            className={`${activeTab === tabKey ? 'border-custom-blue-primary text-custom-blue-primary' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:hover:text-slate-200'} whitespace-nowrap py-4 px-4 border-b-2 font-medium text-sm transition-colors duration-200 focus:outline-none`}
                            >
                            {tabLabels[tabKey]}
                        </button>
                    ))}
                </nav>
            </div>

            <Card>
                {tabContent[activeTab]}
            </Card>

            {actionTarget && (
                <ActionForm
                    actionTarget={actionTarget}
                    onCancel={() => setActionTarget(null)}
                    onConfirm={handleActionConfirm}
                />
            )}
        </div>
    );
};

export default DocumentManagement;
