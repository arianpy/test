
import React, { useState, useMemo, useEffect } from 'react';
import type { ManufacturingProcess, OrgChartNode, Machinery, Workstation, FunctionalEquivalentGroup } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';
import SearchableSelect from './ui/SearchableSelect';

interface DefineManufacturingProcessProps {
    processes: ManufacturingProcess[];
    addProcess: (process: Omit<ManufacturingProcess, 'id'>) => void;
    updateProcess: (process: ManufacturingProcess) => void;
    deleteProcess: (id: number) => void;
    orgChart: OrgChartNode[];
    machinery: Machinery[];
    workstations: Workstation[];
}

const MultiSelectPillbox: React.FC<{
    title: string;
    options: { value: number, label: string }[];
    selectedIds: number[];
    onToggle: (id: number) => void;
}> = ({ title, options, selectedIds, onToggle }) => {
    const selectedOptions = useMemo(() => options.filter(opt => selectedIds.includes(opt.value)), [options, selectedIds]);
    const availableOptions = useMemo(() => options.filter(opt => !selectedIds.includes(opt.value)), [options, selectedIds]);

    return (
        <div className="p-3 border rounded-lg dark:border-slate-600">
            <h4 className="font-semibold mb-2">{title}</h4>
            <div className="mb-2">
                <SearchableSelect
                    options={availableOptions}
                    value={null}
                    onChange={(val) => { if(val !== null) onToggle(val as number); }}
                    placeholder="افزودن..."
                />
            </div>
            <div className="flex flex-wrap gap-2 min-h-[40px]">
                {selectedOptions.map(opt => (
                    <div key={opt.value} className="flex items-center bg-cyan-100 dark:bg-cyan-900 text-cyan-800 dark:text-cyan-200 text-xs font-medium px-2.5 py-1 rounded-full">
                        <span>{opt.label}</span>
                        <button type="button" onClick={() => onToggle(opt.value)} className="mr-2 text-cyan-600 dark:text-cyan-400 hover:text-cyan-800 dark:hover:text-cyan-200">&times;</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

const FunctionalGroupEditor: React.FC<{
    group: FunctionalEquivalentGroup;
    onUpdate: (group: FunctionalEquivalentGroup) => void;
    onDelete: () => void;
    orgChartOptions: { value: number, label: string }[];
    machineryOptions: { value: number, label: string }[];
    workstationOptions: { value: number, label: string }[];
}> = ({ group, onUpdate, onDelete, orgChartOptions, machineryOptions, workstationOptions }) => {
    
    const handleFieldChange = (field: 'name', value: string) => {
        onUpdate({ ...group, [field]: value });
    };

    const handleMultiSelectToggle = (field: 'positionIds' | 'machineryIds' | 'workstationIds', id: number) => {
        const currentIds = group[field] as number[];
        const newIds = currentIds.includes(id) 
            ? currentIds.filter(currentId => currentId !== id)
            : [...currentIds, id];
        onUpdate({ ...group, [field]: newIds });
    };
    
    return (
        <div className="p-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl space-y-4 bg-slate-50 dark:bg-slate-800/50">
            <div className="flex justify-between items-center pb-3 border-b dark:border-slate-600">
                <input 
                    type="text" 
                    value={group.name} 
                    onChange={e => handleFieldChange('name', e.target.value)}
                    className="font-semibold text-lg bg-transparent focus:bg-white dark:focus:bg-slate-700 rounded p-1 -m-1 outline-none"
                />
                <button type="button" onClick={onDelete} className="text-red-500 hover:text-red-700">حذف گروه</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <MultiSelectPillbox title="سمت های مرتبط" options={orgChartOptions} selectedIds={group.positionIds} onToggle={(id) => handleMultiSelectToggle('positionIds', id)} />
                <MultiSelectPillbox title="ماشین آلات مرتبط" options={machineryOptions} selectedIds={group.machineryIds} onToggle={(id) => handleMultiSelectToggle('machineryIds', id)} />
                <MultiSelectPillbox title="ایستگاه های کاری مرتبط" options={workstationOptions} selectedIds={group.workstationIds} onToggle={(id) => handleMultiSelectToggle('workstationIds', id)} />
            </div>
        </div>
    );
};

const DefineManufacturingProcess: React.FC<DefineManufacturingProcessProps> = ({
    processes,
    addProcess,
    updateProcess,
    deleteProcess,
    orgChart,
    machinery,
    workstations,
}) => {
    const getInitialState = (): Omit<ManufacturingProcess, 'id'> => ({
        name: '',
        description: '',
        functionalEquivalentGroups: [],
    });

    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);

    const orgChartOptions = useMemo(() => {
        const options: { value: number, label: string }[] = [];
        const traverse = (nodes: OrgChartNode[], level = 0) => {
            nodes.forEach(node => {
                options.push({ value: node.id, label: `${'\u00A0'.repeat(level*2)} ${node.title}`});
                if(node.children) traverse(node.children, level + 1);
            });
        };
        traverse(orgChart);
        return options;
    }, [orgChart]);

    const machineryOptions = useMemo(() => machinery.map(m => ({ value: m.id, label: m.name })), [machinery]);
    const workstationOptions = useMemo(() => workstations.map(w => ({ value: w.id, label: w.name })), [workstations]);

    const handleEditClick = (process: ManufacturingProcess) => {
        setEditingId(process.id);
        setFormData(process);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleClearForm = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (editingId !== null) {
            updateProcess({ id: editingId, ...formData });
        } else {
            addProcess(formData);
        }
        handleClearForm();
    };

    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این فرآیند اطمینان دارید؟')) {
            deleteProcess(id);
        }
    };
    
    const handleAddGroup = () => {
        const newGroup: FunctionalEquivalentGroup = {
            id: Date.now(),
            name: `گروه عملکردی ${formData.functionalEquivalentGroups.length + 1}`,
            positionIds: [],
            machineryIds: [],
            workstationIds: [],
        };
        setFormData(prev => ({
            ...prev,
            functionalEquivalentGroups: [...prev.functionalEquivalentGroups, newGroup]
        }));
    };

    const handleUpdateGroup = (groupId: number, updatedGroup: FunctionalEquivalentGroup) => {
        setFormData(prev => ({
            ...prev,
            functionalEquivalentGroups: prev.functionalEquivalentGroups.map(g => g.id === groupId ? updatedGroup : g)
        }));
    };

    const handleDeleteGroup = (groupId: number) => {
        setFormData(prev => ({
            ...prev,
            functionalEquivalentGroups: prev.functionalEquivalentGroups.filter(g => g.id !== groupId)
        }));
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف فرآیند تولید</h1>
            <Card>
                <form onSubmit={handleSave} className="space-y-6">
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-white">
                        {editingId ? `ویرایش فرآیند: ${formData.name}` : 'ایجاد فرآیند جدید'}
                    </h2>
                    <input type="text" placeholder="نام فرآیند" value={formData.name} onChange={e => setFormData(p => ({...p, name: e.target.value}))} required className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                    <textarea placeholder="توضیحات" value={formData.description} onChange={e => setFormData(p => ({...p, description: e.target.value}))} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" rows={3}/>
                    
                    <div className="space-y-6 pt-6 border-t dark:border-slate-600">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">گروه‌های عملکردی همسان</h3>
                            <button type="button" onClick={handleAddGroup} className="px-4 py-2 text-sm text-white bg-custom-blue-primary rounded-md hover:bg-blue-600">افزودن گروه</button>
                        </div>
                        
                        <div className="space-y-4">
                            {formData.functionalEquivalentGroups.map(group => (
                                <FunctionalGroupEditor
                                    key={group.id}
                                    group={group}
                                    onUpdate={(updatedGroup) => handleUpdateGroup(group.id, updatedGroup)}
                                    onDelete={() => handleDeleteGroup(group.id)}
                                    orgChartOptions={orgChartOptions}
                                    machineryOptions={machineryOptions}
                                    workstationOptions={workstationOptions}
                                />
                            ))}
                            {formData.functionalEquivalentGroups.length === 0 && (
                                <p className="text-center text-slate-500 py-4">هنوز گروهی اضافه نشده است.</p>
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                        {editingId && <button type="button" onClick={handleClearForm} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو ویرایش</button>}
                        <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">
                            {editingId ? 'ذخیره تغییرات' : 'ذخیره فرآیند'}
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                 <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فرآیندهای تعریف شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام فرآیند</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">توضیحات</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {processes.length > 0 ? processes.map(p => (
                                <tr key={p.id}>
                                    <td className="px-4 py-4 font-medium">{p.name}</td>
                                    <td className="px-4 py-4">{p.description}</td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleEditClick(p)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={3} className="text-center py-6">هیچ فرآیندی یافت نشد.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DefineManufacturingProcess;
