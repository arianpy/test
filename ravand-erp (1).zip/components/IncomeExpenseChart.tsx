import React, { useMemo } from 'react';
import type { Transaction } from '../types';
import { TransactionType } from '../types';
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar } from 'recharts';
import { toJalaali } from '../utils/jalali';
import { getShamsiMonthName } from '../utils/date';


interface ChartData {
  name: string;
  درآمد: number;
  هزینه: number;
}

const IncomeExpenseChart: React.FC<{ data: Transaction[] }> = ({ data }) => {
  const chartData = useMemo(() => {
    const monthlyData: { [key: string]: { درآمد: number; هزینه: number } } = {}; // Key: YYYY-MM

    data.forEach(transaction => {
      const d = new Date(transaction.date);
      if (isNaN(d.getTime())) return;
      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { 'درآمد': 0, 'هزینه': 0 };
      }
      if (transaction.type === TransactionType.Income) {
        monthlyData[monthKey]['درآمد'] += transaction.amount;
      } else {
        monthlyData[monthKey]['هزینه'] += transaction.amount;
      }
    });

    return Object.keys(monthlyData)
      .map(monthKey => {
        const [year, month] = monthKey.split('-').map(Number);
        const { jy, jm } = toJalaali(year, month, 1);
        const name = `${getShamsiMonthName(jm)} ${jy}`;
        return {
          name,
          sortKey: monthKey,
          ...monthlyData[monthKey],
        };
      })
      .sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  }, [data]);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chartData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128, 128, 128, 0.2)" />
        <XAxis dataKey="name" tick={{ fill: '#64748b' }} />
        <YAxis tickFormatter={(value) => new Intl.NumberFormat('en-US').format(value as number)} tick={{ fill: '#64748b' }} />
        <Tooltip
          contentStyle={{
            backgroundColor: 'rgba(30, 41, 59, 0.8)',
            borderColor: '#475569',
            borderRadius: '0.5rem',
            direction: 'rtl',
            fontFamily: 'Vazirmatn'
          }}
          labelStyle={{ color: '#f9fafb' }}
          formatter={(value) => `${new Intl.NumberFormat('en-US').format(value as number)} تومان`}
        />
        <Legend wrapperStyle={{direction: 'rtl'}} />
        <Bar dataKey="درآمد" fill="#66FFFF" radius={[4, 4, 0, 0]} />
        <Bar dataKey="هزینه" fill="#EF4444" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default IncomeExpenseChart;