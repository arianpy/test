import React, { useState, useMemo, useEffect } from 'react';
import type { Machinery, MachineryGroup, AccountHeadSubLedger } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';
import ShamsiDatePicker from './ui/ShamsiDatePicker';

interface DefineMachineryProps {
    machinery: Machinery[];
    addMachinery: (machine: Omit<Machinery, 'id'>) => void;
    updateMachinery: (machine: Machinery) => void;
    deleteMachinery: (id: number) => void;
    machineryGroups: MachineryGroup[];
    allSubLedgers: AccountHeadSubLedger[];
}

const DefineMachinery: React.FC<DefineMachineryProps> = ({ machinery, addMachinery, updateMachinery, deleteMachinery, machineryGroups, allSubLedgers }) => {
    
    const getInitialState = (): Omit<Machinery, 'id'> => ({
        name: '', code: '', machineryGroupId: 0, assetSubLedgerId: null,
        purchaseDate: new Date().toISOString().split('T')[0], capacity: 0,
        capacityUnit: 'عدد در ساعت', status: 'active',
    });

    const [formData, setFormData] = useState(getInitialState());
    const [editingId, setEditingId] = useState<number | null>(null);

    const groupMap = useMemo(() => {
        const map: Map<number, string> = new Map();
        const traverse = (nodes: MachineryGroup[]) => {
            nodes.forEach(node => {
                map.set(node.id, node.title);
                if (node.children) traverse(node.children);
            });
        };
        traverse(machineryGroups);
        return map;
    }, [machineryGroups]);

    const groupOptions = useMemo(() => {
        const options: { value: number, label: string }[] = [];
        const traverse = (nodes: MachineryGroup[], level = 0) => {
            nodes.forEach(node => {
                options.push({ value: node.id, label: `${'\u00A0'.repeat(level*2)} ${node.title}`});
                if(node.children) traverse(node.children, level + 1);
            });
        };
        traverse(machineryGroups);
        return options;
    }, [machineryGroups]);
    
    const subLedgerOptions = useMemo(() => allSubLedgers.filter(sl => sl.code.startsWith('1210')).map(sl => ({value: sl.id, label: `${sl.code} - ${sl.title}`})), [allSubLedgers]);

    const handleEditClick = (machine: Machinery) => {
        setEditingId(machine.id);
        setFormData(machine);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleClearForm = () => {
        setEditingId(null);
        setFormData(getInitialState());
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.machineryGroupId) { alert('لطفا گروه ماشین را انتخاب کنید.'); return; }
        
        if (editingId !== null) {
            updateMachinery({ id: editingId, ...formData });
        } else {
            addMachinery(formData);
        }
        handleClearForm();
    };
    
    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این ماشین اطمینان دارید؟')) {
            deleteMachinery(id);
        }
    };
    
    const handleChange = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف ماشین آلات</h1>
            <Card>
                <form onSubmit={handleSave} className="space-y-4">
                    <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">
                        {editingId ? `ویرایش ماشین: ${formData.name}` : 'افزودن ماشین جدید'}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                             <input type="text" placeholder="نام ماشین" value={formData.name} onChange={e => handleChange('name', e.target.value)} required className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                        </div>
                        <input type="text" placeholder="کد ماشین" value={formData.code} onChange={e => handleChange('code', e.target.value)} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                        <SearchableSelect options={groupOptions} value={formData.machineryGroupId} onChange={val => handleChange('machineryGroupId', val as number)} placeholder="گروه ماشین..."/>
                        <SearchableSelect options={subLedgerOptions} value={formData.assetSubLedgerId} onChange={val => handleChange('assetSubLedgerId', val)} placeholder="حساب دارایی ثابت..."/>
                        <div><ShamsiDatePicker value={formData.purchaseDate} onChange={date => handleChange('purchaseDate', date)} /></div>
                        <FormattedNumberInput value={formData.capacity} onValueChange={val => handleChange('capacity', val)} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" placeholder="ظرفیت" />
                        <input type="text" placeholder="واحد ظرفیت" value={formData.capacityUnit} onChange={e => handleChange('capacityUnit', e.target.value)} className="w-full p-2 border rounded bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"/>
                        <SearchableSelect options={[{value: 'active', label: 'فعال'}, {value: 'inactive', label: 'غیرفعال'}, {value: 'maintenance', label: 'در دست تعمیر'}]} value={formData.status} onChange={val => handleChange('status', val as 'active' | 'inactive' | 'maintenance')} />
                    </div>
                     <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                        {editingId && <button type="button" onClick={handleClearForm} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو ویرایش</button>}
                        <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">
                            {editingId ? 'ذخیره تغییرات' : 'ذخیره ماشین'}
                        </button>
                    </div>
                </form>
            </Card>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">نام</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">کد</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">گروه</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                                <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {machinery.map(m => (
                                <tr key={m.id}>
                                    <td className="px-4 py-4 font-medium">{m.name}</td>
                                    <td className="px-4 py-4">{m.code}</td>
                                    <td className="px-4 py-4">{groupMap.get(m.machineryGroupId) || '-'}</td>
                                    <td className="px-4 py-4">{m.status}</td>
                                    <td className="px-4 py-4 text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleEditClick(m)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(m.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DefineMachinery;
