import React, { useMemo } from 'react';
import type { Transaction } from '../types';
import { TransactionType } from '../types';
import Card from './ui/Card';

interface ReportsProps {
  transactions: Transaction[];
}

const ReportRow: React.FC<{ label: string; value: number; className?: string; isTotal?: boolean }> = ({ label, value, className, isTotal = false}) => (
    <div className={`flex justify-between py-3 ${isTotal ? 'border-t-2 border-slate-300 dark:border-slate-600 font-bold pt-4' : 'border-b border-slate-200 dark:border-slate-700'}`}>
        <span className="text-slate-600 dark:text-slate-300">{label}</span>
        <span className={`${className} font-mono`}>
            {new Intl.NumberFormat('en-US').format(value)} تومان
        </span>
    </div>
);


const Reports: React.FC<ReportsProps> = ({ transactions }) => {

  const reportData = useMemo(() => {
    const totalIncome = transactions
        .filter(t => t.type === TransactionType.Income)
        .reduce((sum, t) => sum + t.amount, 0);

    const totalExpense = transactions
        .filter(t => t.type === TransactionType.Expense)
        .reduce((sum, t) => sum + t.amount, 0);
    
    const grossProfit = totalIncome;
    const netProfit = totalIncome - totalExpense;

    return { totalIncome, totalExpense, grossProfit, netProfit };
  }, [transactions]);
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گزارش‌ها</h1>
      
      <Card>
        <h2 className="text-xl font-semibold mb-2 text-slate-800 dark:text-white">صورت سود و زیان</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">برای دوره جاری</p>

        <div className="space-y-2">
            <ReportRow label="مجموع درآمد" value={reportData.totalIncome} className="text-custom-blue-primary" />
            <ReportRow label="سود ناخالص" value={reportData.grossProfit} className="text-slate-800 dark:text-slate-200 font-semibold" />

            <h3 className="text-lg font-semibold pt-6 pb-2 text-slate-700 dark:text-slate-300">هزینه‌ها</h3>
            {transactions.filter(t => t.type === TransactionType.Expense).map(t => (
                <ReportRow key={t.id} label={t.description} value={t.amount} className="text-red-600" />
            ))}
            <ReportRow label="مجموع هزینه‌ها" value={reportData.totalExpense} className="text-red-600 font-semibold" isTotal={true}/>
            
            <ReportRow 
                label="سود خالص" 
                value={reportData.netProfit} 
                className={reportData.netProfit >= 0 ? 'text-custom-blue-primary' : 'text-red-600'} 
                isTotal={true}
            />
        </div>
      </Card>
    </div>
  );
};

export default Reports;
