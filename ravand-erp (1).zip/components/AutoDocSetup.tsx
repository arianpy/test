import React from 'react';
import type { AutoDocSetting, AccountHeadSubLedger } from '../types';
import Card from './ui/Card';

const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }> = ({ label, id, children, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <select id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-custom-blue-primary focus:border-custom-blue-primary">
            {children}
        </select>
    </div>
);

const ToggleSwitch: React.FC<{ checked: boolean; onChange: () => void; label: string; }> = ({ checked, onChange, label }) => {
    return (
        <div className="flex items-center justify-between w-full">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
            <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={checked} onChange={onChange} className="sr-only peer" />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-custom-blue-primary"></div>
            </label>
        </div>
    );
};


interface AutoDocSetupProps {
    settings: AutoDocSetting[];
    updateSetting: (setting: AutoDocSetting) => void;
    allSubLedgers: AccountHeadSubLedger[];
}

const AutoDocSetup: React.FC<AutoDocSetupProps> = ({ settings, updateSetting, allSubLedgers }) => {
    
    const handleSettingChange = (formId: string, field: keyof Omit<AutoDocSetting, 'formId' | 'formTitle'>, value: any) => {
        const settingToUpdate = settings.find(s => s.formId === formId);
        if (settingToUpdate) {
            updateSetting({ ...settingToUpdate, [field]: value });
        }
    };
    
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تنظیمات سند خودکار</h1>
             <p className="text-slate-600 dark:text-slate-400">
                در این بخش می‌توانید معین‌های بدهکار و بستانکار پیش‌فرض را برای فرم‌های مختلف سیستم تعریف کنید. همچنین می‌توانید امکان ویرایش این مقادیر پیش‌فرض را برای کاربران محدود نمایید.
            </p>

            <div className="space-y-6">
                {settings.map(setting => (
                    <Card key={setting.formId}>
                        <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">{setting.formTitle}</h2>
                        <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <FormSelect
                                    label="معین بدهکار پیش فرض"
                                    id={`debtor-${setting.formId}`}
                                    value={setting.defaultDebtorSubLedgerId || ''}
                                    onChange={(e) => handleSettingChange(setting.formId, 'defaultDebtorSubLedgerId', e.target.value ? Number(e.target.value) : null)}
                                >
                                    <option value="">-- انتخاب کنید --</option>
                                    {allSubLedgers.map(sl => <option key={sl.id} value={sl.id}>{`${sl.code} - ${sl.title}`}</option>)}
                                </FormSelect>
                                 <FormSelect
                                    label="معین بستانکار پیش فرض"
                                    id={`creditor-${setting.formId}`}
                                    value={setting.defaultCreditorSubLedgerId || ''}
                                    onChange={(e) => handleSettingChange(setting.formId, 'defaultCreditorSubLedgerId', e.target.value ? Number(e.target.value) : null)}
                                >
                                    <option value="">-- انتخاب کنید --</option>
                                    {allSubLedgers.map(sl => <option key={sl.id} value={sl.id}>{`${sl.code} - ${sl.title}`}</option>)}
                                </FormSelect>
                            </div>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t dark:border-slate-700">
                                 <ToggleSwitch
                                    label="امکان ویرایش معین بدهکار برای کاربر"
                                    checked={setting.isDebtorEditable}
                                    onChange={() => handleSettingChange(setting.formId, 'isDebtorEditable', !setting.isDebtorEditable)}
                                 />
                                <ToggleSwitch
                                    label="امکان ویرایش معین بستانکار برای کاربر"
                                    checked={setting.isCreditorEditable}
                                    onChange={() => handleSettingChange(setting.formId, 'isCreditorEditable', !setting.isCreditorEditable)}
                                 />
                            </div>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};

export default AutoDocSetup;
