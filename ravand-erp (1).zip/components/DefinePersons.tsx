import React, { useState } from 'react';
import type { Person, NaturalPerson, LegalPerson } from '../types';
import { ContactType } from '../types';
import Card from './ui/Card';
import FormattedNumberInput from './ui/FormattedNumberInput';
import BulkImportPersonsModal from './BulkImportPersonsModal';


// Reusable Input components
const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, required, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <input id={id} required={required} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);
const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode, required?: boolean }> = ({ label, id, children, required, ...props }) => (
     <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <select id={id} required={required} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-800">
            {children}
        </select>
    </div>
);

// Form for Natural Persons
const NaturalPersonForm: React.FC<{ addPerson: (person: Omit<NaturalPerson, 'id'>) => void; contactTypeContext: ContactType }> = ({ addPerson, contactTypeContext }) => {
    const getInitialState = () => ({
        contactType: contactTypeContext,
        firstName: '', lastName: '', code: '', nationalId: '', economicCode: '',
        workshopCode: '', address: '', postalCode: '', phone: '', mobile: '',
        accountNumber: '', cardNumber: '', iban: '', openingBalance: '' as number | '',
    });

    const [formData, setFormData] = useState(getInitialState());

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addPerson({
            ...formData,
            personType: 'natural',
            openingBalance: Number(formData.openingBalance) || 0,
        });
        setFormData(getInitialState());
        alert('شخص حقیقی با موفقیت ذخیره شد.');
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                 <FormSelect label="نوع اشخاص" id="contactType" name="contactType" value={formData.contactType} disabled>
                    <option value={ContactType.Supplier}>تامین کننده</option>
                    <option value={ContactType.Customer}>مشتری</option>
                </FormSelect>
                <FormInput label="نام" name="firstName" value={formData.firstName} onChange={handleChange} required placeholder="نام را وارد کنید" />
                <FormInput label="نام خانوادگی" name="lastName" value={formData.lastName} onChange={handleChange} required placeholder="نام خانوادگی را وارد کنید" />
                <FormInput label="کد" name="code" value={formData.code} onChange={handleChange} placeholder="کد را وارد کنید" />
                <FormInput label="کد ملی" name="nationalId" value={formData.nationalId} onChange={handleChange} placeholder="کد ملی را وارد کنید" />
                <FormInput label="کد اقتصادی" name="economicCode" value={formData.economicCode} onChange={handleChange} placeholder="کد اقتصادی را وارد کنید" />
                <FormInput label="کد کارگاه" name="workshopCode" value={formData.workshopCode} onChange={handleChange} placeholder="کد کارگاه را وارد کنید" />
                <FormInput label="کد پستی" name="postalCode" value={formData.postalCode} onChange={handleChange} placeholder="کد پستی را وارد کنید" />
                <FormInput label="تلفن ثابت" name="phone" value={formData.phone} onChange={handleChange} placeholder="تلفن ثابت را وارد کنید" />
                <FormInput label="تلفن همراه" name="mobile" value={formData.mobile} onChange={handleChange} placeholder="تلفن همراه را وارد کنید" />
                <FormInput label="شماره حساب" name="accountNumber" value={formData.accountNumber} onChange={handleChange} placeholder="شماره حساب را وارد کنید" />
                <FormInput label="شماره کارت" name="cardNumber" value={formData.cardNumber} onChange={handleChange} placeholder="شماره کارت را وارد کنید" />
                <FormInput label="شماره شبا" name="iban" value={formData.iban} onChange={handleChange} placeholder="شماره شبا را وارد کنید" />
                <div>
                    <label htmlFor="openingBalance" className="block text-sm font-medium text-slate-700 dark:text-slate-300">مانده افتتاحیه استقرار</label>
                    <FormattedNumberInput
                        id="openingBalance"
                        value={formData.openingBalance}
                        onValueChange={val => setFormData(prev => ({ ...prev, openingBalance: val }))}
                        placeholder="مانده افتتاحیه را وارد کنید"
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"
                    />
                </div>
                <div className="lg:col-span-4">
                    <label htmlFor="address" className="block text-sm font-medium">آدرس</label>
                    <input id="address" name="address" value={formData.address} onChange={handleChange} placeholder="آدرس را وارد کنید" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"/>
                </div>
            </div>
            <div className="flex justify-end pt-5">
                <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره شخص حقیقی</button>
            </div>
        </form>
    );
};

// Form for Legal Persons
const LegalPersonForm: React.FC<{ addPerson: (person: Omit<LegalPerson, 'id'>) => void; contactTypeContext: ContactType }> = ({ addPerson, contactTypeContext }) => {
    const getInitialState = () => ({
        contactType: contactTypeContext,
        registeredName: '', brandName: '', code: '', nationalId: '', economicCode: '',
        workshopCode: '', address: '', postalCode: '', phone: '', mobile: '',
        accountNumber: '', cardNumber: '', iban: ''
    });
    const [formData, setFormData] = useState(getInitialState());
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addPerson({
            ...formData,
            personType: 'legal',
        });
        setFormData(getInitialState());
        alert('شخص حقوقی با موفقیت ذخیره شد.');
    };

    return (
         <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <FormSelect label="نوع اشخاص" id="contactType" name="contactType" value={formData.contactType} disabled>
                    <option value={ContactType.Supplier}>تامین کننده</option>
                    <option value={ContactType.Customer}>مشتری</option>
                </FormSelect>
                <FormInput label="نام ثبتی" name="registeredName" value={formData.registeredName} onChange={handleChange} required placeholder="نام ثبتی را وارد کنید" />
                <FormInput label="نام برند" name="brandName" value={formData.brandName} onChange={handleChange} placeholder="نام برند را وارد کنید" />
                <FormInput label="کد" name="code" value={formData.code} onChange={handleChange} placeholder="کد را وارد کنید" />
                <FormInput label="شناسه ملی" name="nationalId" value={formData.nationalId} onChange={handleChange} placeholder="شناسه ملی را وارد کنید" />
                <FormInput label="کد اقتصادی" name="economicCode" value={formData.economicCode} onChange={handleChange} placeholder="کد اقتصادی را وارد کنید" />
                <FormInput label="کد کارگاه" name="workshopCode" value={formData.workshopCode} onChange={handleChange} placeholder="کد کارگاه را وارد کنید" />
                <FormInput label="کد پستی" name="postalCode" value={formData.postalCode} onChange={handleChange} placeholder="کد پستی را وارد کنید" />
                <FormInput label="تلفن ثابت" name="phone" value={formData.phone} onChange={handleChange} placeholder="تلفن ثابت را وارد کنید" />
                <FormInput label="تلفن همراه" name="mobile" value={formData.mobile} onChange={handleChange} placeholder="تلفن همراه را وارد کنید" />
                <FormInput label="شماره حساب" name="accountNumber" value={formData.accountNumber} onChange={handleChange} placeholder="شماره حساب را وارد کنید" />
                <FormInput label="شماره کارت" name="cardNumber" value={formData.cardNumber} onChange={handleChange} placeholder="شماره کارت را وارد کنید" />
                <FormInput label="شماره شبا" name="iban" value={formData.iban} onChange={handleChange} placeholder="شماره شبا را وارد کنید" />
                 <div className="lg:col-span-4">
                    <label htmlFor="address" className="block text-sm font-medium">آدرس</label>
                    <input id="address" name="address" value={formData.address} onChange={handleChange} placeholder="آدرس را وارد کنید" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm"/>
                </div>
            </div>
            <div className="flex justify-end pt-5">
                <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره شخص حقوقی</button>
            </div>
        </form>
    );
};


interface DefinePersonsProps {
    persons: Person[];
    addPerson: (person: Omit<NaturalPerson, 'id'> | Omit<LegalPerson, 'id'>) => void;
    addPersonsBatch: (persons: (Omit<NaturalPerson, 'id'> | Omit<LegalPerson, 'id'>)[]) => void;
    title: string;
    contactTypeContext: ContactType;
}

const DefinePersons: React.FC<DefinePersonsProps> = ({ persons, addPerson, addPersonsBatch, title, contactTypeContext }) => {
    const [personType, setPersonType] = useState<'natural' | 'legal'>('natural');
    const [isBulkModalOpen, setBulkModalOpen] = useState(false);

    return (
        <div className="space-y-6">
             <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>
                 <button
                    type="button"
                    onClick={() => setBulkModalOpen(true)}
                    className="flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L6.293 6.707z" clipRule="evenodd" /></svg>
                    بارگذاری گروهی
                </button>
            </div>
            <Card>
                <div className="border-b border-slate-200 dark:border-slate-700">
                    <nav className="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
                        <button
                            onClick={() => setPersonType('natural')}
                            className={`${personType === 'natural' ? 'border-cyan-500 text-cyan-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:hover:text-slate-200'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200`}
                        >
                            اشخاص حقیقی
                        </button>
                         <button
                            onClick={() => setPersonType('legal')}
                            className={`${personType === 'legal' ? 'border-cyan-500 text-cyan-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:hover:text-slate-200'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200`}
                        >
                            اشخاص حقوقی
                        </button>
                    </nav>
                </div>
                <div className="pt-6">
                    {personType === 'natural' ? <NaturalPersonForm addPerson={addPerson} contactTypeContext={contactTypeContext} /> : <LegalPersonForm addPerson={addPerson} contactTypeContext={contactTypeContext} />}
                </div>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">فهرست اشخاص تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">نوع شخص</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">کد</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">نام شخص</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">کد/شناسه ملی</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">تلفن همراه</th>
                             <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {persons.filter(p => p.contactType === contactTypeContext).length > 0 ? (
                            persons.filter(p => p.contactType === contactTypeContext).map((person) => (
                                <tr key={person.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{person.personType === 'natural' ? 'حقیقی' : 'حقوقی'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{person.code}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">
                                        {person.personType === 'natural' ? `${person.firstName} ${person.lastName}` : person.registeredName}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{person.nationalId}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{person.mobile}</td>
                                     <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز شخصی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>
            <BulkImportPersonsModal 
                isOpen={isBulkModalOpen}
                onClose={() => setBulkModalOpen(false)}
                addPersonsBatch={addPersonsBatch}
            />
        </div>
    );
};

export default DefinePersons;