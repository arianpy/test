import React, { useState, useMemo } from 'react';
import type { TrendForm, TrendInstance } from '../types';
import Card from './ui/Card';
import TrendInstanceModal from './TrendInstanceModal';
import { toShamsi } from '../utils/date';

interface TrendOperationsProps {
    trendForms: TrendForm[];
    trendInstancesByFormId: Record<number, TrendInstance[]>;
    addTrendInstance: (instance: Omit<TrendInstance, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>) => void;
    updateTrendInstance: (instance: TrendInstance) => void;
    getCurrentUser: () => string;
}

const TrendOperations: React.FC<TrendOperationsProps> = ({ trendForms, trendInstancesByFormId, addTrendInstance, updateTrendInstance, getCurrentUser }) => {
    const [selectedFormId, setSelectedFormId] = useState<number | null>(null);
    const [activeInstance, setActiveInstance] = useState<TrendInstance | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const publishedForms = useMemo(() => trendForms.filter(f => f.published), [trendForms]);
    const selectedForm = useMemo(() => trendForms.find(f => f.id === selectedFormId), [trendForms, selectedFormId]);
    const instancesForSelectedForm = useMemo(() => (selectedFormId ? trendInstancesByFormId[selectedFormId] || [] : []), [trendInstancesByFormId, selectedFormId]);

    const handleCreateNew = () => {
        setActiveInstance(null);
        setIsModalOpen(true);
    };

    const handleOpenInstance = (instance: TrendInstance) => {
        setActiveInstance(instance);
        setIsModalOpen(true);
    };

    const handleSaveInstance = (instanceData: TrendInstance | Omit<TrendInstance, 'id' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>) => {
        if ('id' in instanceData) {
            updateTrendInstance(instanceData as TrendInstance);
        } else {
            addTrendInstance(instanceData);
        }
        setIsModalOpen(false);
    };
    
    // View for selecting a form template
    if (!selectedForm) {
        return (
            <div className="space-y-6">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">عملیات روندها</h1>
                <p className="text-slate-600 dark:text-slate-400">یک قالب روند را برای شروع انتخاب کنید.</p>
                {publishedForms.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {publishedForms.map(form => (
                            <Card key={form.id} onClick={() => setSelectedFormId(form.id)} className="cursor-pointer hover:shadow-lg hover:-translate-y-1 transition-transform">
                                <h2 className="text-xl font-bold text-custom-blue-primary">{form.title}</h2>
                                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{form.description}</p>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <Card><p className="text-center p-8 text-slate-500">هیچ قالب روند منتشر شده‌ای وجود ندارد. لطفا از بخش "تعریف روند" یک قالب ایجاد و منتشر کنید.</p></Card>
                )}
            </div>
        );
    }

    // View for a selected form template (list instances)
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <button onClick={() => setSelectedFormId(null)} className="text-sm text-slate-600 dark:text-slate-400 hover:text-custom-blue-primary flex items-center mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                         بازگشت به لیست قالب‌ها
                    </button>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{selectedForm.title}</h1>
                </div>
                <button onClick={handleCreateNew} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ایجاد روند جدید</button>
            </div>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">روندهای ایجاد شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-4 py-3 text-right text-xs uppercase">عنوان</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">تاریخ ایجاد</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">وضعیت</th>
                                <th className="px-4 py-3 text-right text-xs uppercase">مرحله فعلی</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {instancesForSelectedForm.length > 0 ? (
                                instancesForSelectedForm.map(instance => (
                                    <tr key={instance.id} onClick={() => handleOpenInstance(instance)} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                        <td className="px-4 py-4 font-medium">{instance.title}</td>
                                        <td className="px-4 py-4">{toShamsi(instance.createdAt.split('T')[0])}</td>
                                        <td className="px-4 py-4">{instance.status}</td>
                                        <td className="px-4 py-4">{selectedForm.boxes.find(b => b.id === instance.currentBoxId)?.name || 'نامشخص'}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr><td colSpan={4} className="text-center py-6">هیچ روندی برای این قالب ایجاد نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            {isModalOpen && (
                <TrendInstanceModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    formTemplate={selectedForm}
                    instance={activeInstance}
                    onSave={handleSaveInstance}
                    getCurrentUser={getCurrentUser}
                />
            )}
        </div>
    );
};

export default TrendOperations;
