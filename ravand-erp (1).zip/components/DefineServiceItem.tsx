
import React, { useState, useEffect } from 'react';
import type { ServiceItem } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';

// FIX: Add update and delete props to handle editing and removing service items.
interface DefineServiceItemProps {
    serviceItems: ServiceItem[];
    addServiceItem: (service: Omit<ServiceItem, 'id'>) => void;
    updateServiceItem: (service: ServiceItem) => void;
    deleteServiceItem: (serviceId: number) => void;
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, required, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <input id={id} required={required} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const EditServiceItemModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    serviceItem: ServiceItem | null;
    updateServiceItem: (service: ServiceItem) => void;
}> = ({ isOpen, onClose, serviceItem, updateServiceItem }) => {
    const [formData, setFormData] = useState<ServiceItem | null>(null);

    useEffect(() => {
        setFormData(serviceItem);
    }, [serviceItem]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (formData) {
            setFormData({ ...formData, [e.target.name]: e.target.value });
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateServiceItem(formData);
        }
        onClose();
    };

    if (!isOpen || !formData) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش خدمت: ${serviceItem?.title}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <FormInput label="کد خدمت" name="code" value={formData.code} onChange={handleChange} required />
                <FormInput label="عنوان خدمت" name="title" value={formData.title} onChange={handleChange} required />
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};


const DefineServiceItem: React.FC<DefineServiceItemProps> = ({ serviceItems, addServiceItem, updateServiceItem, deleteServiceItem }) => {
    const [code, setCode] = useState('');
    const [title, setTitle] = useState('');
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !code.trim()) return;
        addServiceItem({ code, title });
        setCode('');
        setTitle('');
        alert('خدمت جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (service: ServiceItem) => {
        setSelectedService(service);
        setEditModalOpen(true);
    };

    const handleDelete = (serviceId: number) => {
        if (window.confirm('آیا از حذف این خدمت اطمینان دارید؟')) {
            deleteServiceItem(serviceId);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف خدمات</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                        <FormInput label="کد خدمت" id="code" name="code" type="text" value={code} onChange={(e) => setCode(e.target.value)} required />
                        <div className="md:col-span-2">
                           <FormInput label="عنوان خدمت" id="title" name="title" type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
                        </div>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-custom-blue-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-custom-blue-primary h-10">
                            ذخیره خدمت
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">خدمات تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">کد خدمت</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عنوان</th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {serviceItems.length > 0 ? (
                            serviceItems.map((service) => (
                                <tr key={service.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{service.code}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{service.title}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(service)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(service.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={3} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز خدمتی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditServiceItemModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                serviceItem={selectedService}
                updateServiceItem={updateServiceItem}
            />
        </div>
    );
};

export default DefineServiceItem;
