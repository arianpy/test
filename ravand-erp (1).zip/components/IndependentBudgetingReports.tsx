import React from 'react';
import type { Forecast } from '../types';
import Card from './ui/Card';
import { ResponsiveContainer, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Line } from 'recharts';

interface IndependentBudgetingReportsProps {
    forecasts: Forecast[];
}

const monthNames = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
];


const ForecastReport: React.FC<{ forecast: Forecast }> = ({ forecast }) => {
    const chartData = forecast.analysis.monthlyEurRates.map(item => ({
        name: monthNames[item.month - 1],
        'نرخ یورو': item.rate,
    }));
    
    return (
        <div className="space-y-6">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
                گزارش پیش‌بینی برای سال {forecast.targetYear} (بر اساس داده‌های سال {forecast.baseYear})
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">میانگین نرخ دلار واقعی پیش‌بینی شده</h3>
                    <p className="mt-1 text-3xl font-semibold text-cyan-500">
                        {new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(forecast.analysis.projectedAvgUsdRate)}
                        <span className="text-lg font-normal"> ریال</span>
                    </p>
                </Card>
                <Card>
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">میانگین نرخ یورو واقعی پیش‌بینی شده</h3>
                     <p className="mt-1 text-3xl font-semibold text-cyan-500">
                        {new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(forecast.analysis.projectedAvgEurRate)}
                        <span className="text-lg font-normal"> ریال</span>
                    </p>
                </Card>
            </div>
            
            <Card>
                 <h3 className="text-lg font-semibold mb-4">روند ماهانه نرخ یورو پیش‌بینی شده برای سال {forecast.targetYear}</h3>
                 <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128, 128, 128, 0.2)" />
                        <XAxis dataKey="name" tick={{ fill: '#64748b' }} />
                        <YAxis tickFormatter={(value) => new Intl.NumberFormat('en-US').format(value as number)} tick={{ fill: '#64748b' }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'rgba(30, 41, 59, 0.8)',
                            borderColor: '#475569',
                            borderRadius: '0.5rem',
                            direction: 'rtl',
                            fontFamily: 'Vazirmatn'
                          }}
                          labelStyle={{ color: '#f9fafb' }}
                          formatter={(value) => `${new Intl.NumberFormat('en-US').format(value as number)} ریال`}
                        />
                        <Legend wrapperStyle={{direction: 'rtl'}} />
                        <Line type="monotone" dataKey="نرخ یورو" stroke="#06b6d4" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                 </div>
            </Card>

        </div>
    );
}

const IndependentBudgetingReports: React.FC<IndependentBudgetingReportsProps> = ({ forecasts }) => {
    const latestForecast = forecasts.length > 0 ? forecasts[0] : null;

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گزارشات بودجه ریزی مستقل</h1>
            
            {latestForecast ? (
                <ForecastReport forecast={latestForecast} />
            ) : (
                <Card>
                    <div className="text-center p-8">
                        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-200">هیچ پیش‌بینی‌ای یافت نشد</h2>
                        <p className="mt-2 text-slate-600 dark:text-slate-400">
                            برای مشاهده گزارش، لطفاً ابتدا از بخش "عملیات" یک پیش‌بینی جدید ایجاد کنید.
                        </p>
                    </div>
                </Card>
            )}
        </div>
    );
};

export default IndependentBudgetingReports;
