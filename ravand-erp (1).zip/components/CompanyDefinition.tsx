import React, { useState, useEffect } from 'react';
import Card from './ui/Card';
import ShamsiDatePicker from './ui/ShamsiDatePicker';

// Reusable FileInput component with preview
const FileInput: React.FC<{
    id: string;
    label: string;
    onFileSelect: (file: File | null) => void;
    previewUrl: string | null;
}> = ({ id, label, onFileSelect, previewUrl }) => {
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            onFileSelect(e.target.files[0]);
        } else {
            onFileSelect(null);
        }
    };

    return (
        <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
            <div className="mt-2 flex items-center space-x-4 rtl:space-x-reverse">
                <div className="flex-shrink-0 h-24 w-24 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                    {previewUrl ? (
                        <img src={previewUrl} alt="پیش‌نمایش" className="h-full w-full object-cover" />
                    ) : (
                        <svg className="h-16 w-16 text-slate-300 dark:text-slate-500" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM8.5 12.5l2.5 3.01L14.5 11l4.5 6H5l3.5-4.5z" />
                        </svg>
                    )}
                </div>
                <label htmlFor={id} className="cursor-pointer bg-white dark:bg-slate-700 py-2 px-3 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-sm leading-4 font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
                    <span>انتخاب فایل</span>
                    <input id={id} name={id} type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg" />
                </label>
            </div>
        </div>
    );
};

// Reusable Input component
const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CompanyDefinition: React.FC = () => {
    // State for form fields
    const [formData, setFormData] = useState({
        companyName: '',
        tradeName: '',
        nationalId: '',
        registrationNumber: '',
        phone: '',
        fax: '',
        registrationDate: '',
        email: '',
        postalCode: '',
        address: '',
        ceoPhone: '',
        adminPhone: '',
    });
    const [siteLogo, setSiteLogo] = useState<File | null>(null);
    const [invoiceLogo, setInvoiceLogo] = useState<File | null>(null);
    const [isDirty, setIsDirty] = useState(false);

    const siteLogoPreview = siteLogo ? URL.createObjectURL(siteLogo) : null;
    const invoiceLogoPreview = invoiceLogo ? URL.createObjectURL(invoiceLogo) : null;
    
    // Cleanup object URLs on unmount
    useEffect(() => {
        return () => {
            if (siteLogoPreview) URL.revokeObjectURL(siteLogoPreview);
            if (invoiceLogoPreview) URL.revokeObjectURL(invoiceLogoPreview);
        };
    }, [siteLogoPreview, invoiceLogoPreview]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        setIsDirty(true);
    };
    
    const handleFileSelect = (setter: React.Dispatch<React.SetStateAction<File | null>>) => (file: File | null) => {
        setter(file);
        setIsDirty(true);
    };

    const handleDateChange = (value: string) => {
        setFormData({ ...formData, registrationDate: value });
        setIsDirty(true);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log({ ...formData, siteLogo, invoiceLogo });
        alert('اطلاعات شرکت با موفقیت ذخیره شد.');
        setIsDirty(false);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف شرکت</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8 divide-y divide-slate-200 dark:divide-slate-700">
                    <div className="space-y-6 pt-2">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">اطلاعات پایه شرکت</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">اطلاعات ثبتی و شناسایی شرکت را در این بخش وارد کنید.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormInput label="نام شرکت" id="companyName" name="companyName" type="text" value={formData.companyName} onChange={handleChange} required />
                            <FormInput label="نام تجاری شرکت" id="tradeName" name="tradeName" type="text" value={formData.tradeName} onChange={handleChange} />
                            <FormInput label="شناسه ملی" id="nationalId" name="nationalId" type="text" value={formData.nationalId} onChange={handleChange} />
                            <FormInput label="شماره ثبت" id="registrationNumber" name="registrationNumber" type="text" value={formData.registrationNumber} onChange={handleChange} />
                            <div>
                                <label htmlFor="registrationDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">تاریخ ثبت</label>
                                <ShamsiDatePicker id="registrationDate" value={formData.registrationDate} onChange={handleDateChange} />
                            </div>
                        </div>
                    </div>
                    
                    <div className="space-y-6 pt-8">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">اطلاعات تماس</h3>
                             <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">اطلاعات تماس و آدرس شرکت.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormInput label="شماره تلفن ثابت" id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} />
                            <FormInput label="شماره فکس" id="fax" name="fax" type="tel" value={formData.fax} onChange={handleChange} />
                            <FormInput label="ایمیل سازمانی" id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
                            <FormInput label="کد پستی" id="postalCode" name="postalCode" type="text" value={formData.postalCode} onChange={handleChange} />
                            <FormInput label="شماره تماس مدیرعامل" id="ceoPhone" name="ceoPhone" type="tel" value={formData.ceoPhone} onChange={handleChange} />
                            <FormInput label="شماره ادمین سایت" id="adminPhone" name="adminPhone" type="tel" value={formData.adminPhone} onChange={handleChange} />
                             <div className="md:col-span-2">
                                <label htmlFor="address" className="block text-sm font-medium text-slate-700 dark:text-slate-300">آدرس</label>
                                <textarea id="address" name="address" value={formData.address} onChange={handleChange} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"></textarea>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6 pt-8">
                        <div>
                            <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">لوگوها</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">لوگوی شرکت برای استفاده در سایت و فاکتورها.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FileInput id="site-logo-upload" label="لوگوی سایت" onFileSelect={handleFileSelect(setSiteLogo)} previewUrl={siteLogoPreview} />
                            <FileInput id="invoice-logo-upload" label="لوگوی فاکتور" onFileSelect={handleFileSelect(setInvoiceLogo)} previewUrl={invoiceLogoPreview} />
                        </div>
                    </div>

                    <div className="flex justify-end pt-5">
                        <button type="submit" className="mr-3 rtl:mr-0 rtl:ml-3 px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed" disabled={!isDirty}>
                            ذخیره تغییرات
                        </button>
                    </div>
                </form>
            </Card>
        </div>
    );
};

export default CompanyDefinition;