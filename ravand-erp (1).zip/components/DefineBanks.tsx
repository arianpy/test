import React, { useState, useMemo, useEffect } from 'react';
import type { Bank, Currency } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';
import Modal from './ui/Modal';
import FormattedNumberInput from './ui/FormattedNumberInput';

interface DefineBanksProps {
    banks: Bank[];
    addBank: (bank: Omit<Bank, 'id'>) => void;
    updateBank: (bank: Bank) => void;
    deleteBank: (bankId: number) => void;
    currencies: Currency[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const EditBankModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    bank: Bank | null;
    updateBank: (bank: Bank) => void;
    currencies: Currency[];
}> = ({ isOpen, onClose, bank, updateBank, currencies }) => {
    
    const [formData, setFormData] = useState<Bank | null>(bank);

    useEffect(() => {
        setFormData(bank);
    }, [bank]);

    if (!isOpen || !formData) return null;
    
    const currencyOptions = currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`}));

    const handleChange = (field: keyof Omit<Bank, 'id'>, value: any) => {
        setFormData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateBank(formData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش بانک: ${bank?.branchName}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <FormInput label="نام بانک اصلی" value={formData.mainBankName} onChange={e => handleChange('mainBankName', e.target.value)} required />
                    <FormInput label="عنوان بانک" value={formData.branchName} onChange={e => handleChange('branchName', e.target.value)} required />
                    <FormInput label="کد تفضیلی" value={formData.detailedCode} onChange={e => handleChange('detailedCode', e.target.value)} />
                    <FormInput label="کد شعبه" value={formData.branchCode} onChange={e => handleChange('branchCode', e.target.value)} />
                     <div>
                        <label className="block text-sm font-medium">تاریخ افتتاح</label>
                        <ShamsiDatePicker value={formData.openingDate} onChange={date => handleChange('openingDate', date)} />
                    </div>
                    <FormInput label="شماره حساب" value={formData.accountNumber} onChange={e => handleChange('accountNumber', e.target.value)} />
                    <FormInput label="شماره شبا" value={formData.iban} onChange={e => handleChange('iban', e.target.value)} />
                    <FormInput label="شماره کارت" value={formData.cardNumber} onChange={e => handleChange('cardNumber', e.target.value)} />
                    <CustomFormSelect label="ارز">
                        <SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} />
                    </CustomFormSelect>
                     <div>
                        <label className="block text-sm font-medium">مانده افتتاحیه</label>
                        <FormattedNumberInput value={formData.openingBalance} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full p-2 border rounded-md" />
                    </div>
                </div>

                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};

const DefineBanks: React.FC<DefineBanksProps> = ({ banks, addBank, updateBank, deleteBank, currencies }) => {
    const initialState: Omit<Bank, 'id'> = {
        mainBankName: '',
        branchName: '',
        detailedCode: '',
        branchCode: '',
        openingBalance: 0,
        openingDate: new Date().toISOString().split('T')[0],
        accountNumber: '',
        iban: '',
        cardNumber: '',
        currencyCode: currencies[0]?.code || 'IRR',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedBank, setSelectedBank] = useState<Bank | null>(null);

    const currencyMap = useMemo(() => 
        currencies.reduce((map, currency) => {
            map[currency.code] = currency.name;
            return map;
        }, {} as Record<string, string>),
    [currencies]);

    const currencyOptions = useMemo(() => currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`})), [currencies]);

    const handleChange = (field: keyof Omit<Bank, 'id'>, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addBank(formData);
        setFormData(initialState);
        alert('بانک جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (bank: Bank) => {
        setSelectedBank(bank);
        setEditModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف بانک</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <FormInput label="نام بانک اصلی" value={formData.mainBankName} onChange={e => handleChange('mainBankName', e.target.value)} required placeholder="نام بانک اصلی را وارد کنید"/>
                        <FormInput label="عنوان بانک" value={formData.branchName} onChange={e => handleChange('branchName', e.target.value)} required placeholder="عنوان بانک را وارد کنید"/>
                        <FormInput label="کد تفضیلی" value={formData.detailedCode} onChange={e => handleChange('detailedCode', e.target.value)} placeholder="کد تفضیلی را وارد کنید"/>
                        <FormInput label="کد شعبه" value={formData.branchCode} onChange={e => handleChange('branchCode', e.target.value)} placeholder="کد شعبه را وارد کنید"/>
                        <div>
                            <label className="block text-sm font-medium">تاریخ افتتاح</label>
                            <ShamsiDatePicker value={formData.openingDate} onChange={date => handleChange('openingDate', date)} />
                        </div>
                        <FormInput label="شماره حساب" value={formData.accountNumber} onChange={e => handleChange('accountNumber', e.target.value)} />
                        <FormInput label="شماره شبا" value={formData.iban} onChange={e => handleChange('iban', e.target.value)} />
                        <FormInput label="شماره کارت" value={formData.cardNumber} onChange={e => handleChange('cardNumber', e.target.value)} />
                        <CustomFormSelect label="انتخاب ارز">
                            <SearchableSelect options={currencyOptions} value={formData.currencyCode} onChange={val => handleChange('currencyCode', val)} />
                        </CustomFormSelect>
                        <div className="lg:col-span-full">
                            <label className="block text-sm font-medium">مانده افتتاحیه استقرار</label>
                            <FormattedNumberInput value={formData.openingBalance || ''} onValueChange={val => handleChange('openingBalance', val)} className="mt-1 w-full md:w-1/3 p-2 border rounded-md" placeholder="مانده افتتاحیه استقرار را وارد کنید"/>
                        </div>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                            وارد کردن بانک
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">بانک‌های تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="px-4 py-3 text-right text-xs uppercase">نام بانک اصلی</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">عنوان بانک/شعبه</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">کد شعبه</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">شماره حساب</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">شماره شبا</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">شماره کارت</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">کد تفضیلی</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">تاریخ افتتاح</th>
                            <th className="px-4 py-3 text-right text-xs uppercase">ارز</th>
                            <th className="px-4 py-3 text-left text-xs uppercase">مانده افتتاحیه</th>
                            <th className="px-4 py-3 text-center text-xs uppercase">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {banks.length > 0 ? (
                            banks.map((bank) => (
                                <tr key={bank.id}>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.mainBankName}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.branchName}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.branchCode}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.accountNumber}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.iban}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.cardNumber}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{bank.detailedCode}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{toShamsi(bank.openingDate)}</td>
                                    <td className="px-4 py-4 whitespace-nowrap">{currencyMap[bank.currencyCode] || bank.currencyCode}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-left font-mono">{bank.openingBalance.toLocaleString()}</td>
                                    <td className="px-4 py-4 whitespace-nowrap text-center space-x-4 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(bank)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => deleteBank(bank.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={11} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز بانکی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditBankModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                bank={selectedBank}
                updateBank={updateBank}
                currencies={currencies}
            />
        </div>
    );
};

export default DefineBanks;