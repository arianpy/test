import React from 'react';
import Card from './ui/Card';

const TrendReports: React.FC = () => {
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">گزارشات روندها</h1>
            <Card>
                <div className="text-center p-8">
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-200">در حال توسعه</h2>
                    <p className="mt-2 text-slate-600 dark:text-slate-400">
                        این بخش برای نمایش گزارشات مربوط به روندهای اجرا شده (مدت زمان، توقف در مراحل و ...) طراحی شده است. قابلیت‌ها به زودی اضافه خواهند شد.
                    </p>
                </div>
            </Card>
        </div>
    );
};
export default TrendReports;
