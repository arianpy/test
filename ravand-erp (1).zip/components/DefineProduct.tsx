import React, { useState, useMemo } from 'react';
import type { Product, ProductGroup, PurchaseItem, Process, ProductComponent, MeasurementUnit, Warehouse, ManufacturingProcess } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import FormattedNumberInput from './ui/FormattedNumberInput';


interface DefineProductProps {
    products: Product[];
    addProduct: (product: Omit<Product, 'id'>) => void;
    updateProduct: (product: Product) => void;
    deleteProduct: (productId: number) => void;
    productGroups: ProductGroup[];
    purchaseItems: PurchaseItem[];
    measurementUnits: MeasurementUnit[];
    warehouses: Warehouse[];
    manufacturingProcesses: ManufacturingProcess[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, required, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <input id={id} required={required} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode, required?: boolean }> = ({ label, children, required }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            {label}{required && <span className="text-red-500 mr-1">*</span>}
        </label>
        {children}
    </div>
);

type NewComponentState = {
    componentType: 'purchaseItem' | 'product';
    componentId: number | null;
    quantity: number | '';
};

const DefineProduct: React.FC<DefineProductProps> = ({ products, addProduct, updateProduct, deleteProduct, productGroups, purchaseItems, measurementUnits, warehouses, manufacturingProcesses }) => {
    const initialState = {
        code: '', title: '', productGroupId: '', primaryUnit: '', secondaryUnit: '', cost: '', defaultWarehouseId: null as number | null,
    };
    const [formData, setFormData] = useState(initialState);
    const [processes, setProcesses] = useState<Process[]>([]);
    
    // State for the new component form for each process
    const [newComponentData, setNewComponentData] = useState<Record<number, NewComponentState>>({});

    const productGroupMap = useMemo(() => {
        const map: { [key: number]: string } = {};
        const traverse = (nodes: ProductGroup[]) => {
            nodes.forEach(node => {
                map[node.id] = node.title;
                if (node.children) traverse(node.children);
            });
        };
        traverse(productGroups);
        return map;
    }, [productGroups]);
    
    const warehouseMap = useMemo(() => new Map(warehouses.map(w => [w.id, w.name])), [warehouses]);

    const componentNameMap = useMemo(() => {
        const map: { [key: string]: string } = {};
        purchaseItems.forEach(item => map[`purchaseItem-${item.id}`] = item.title);
        products.forEach(prod => map[`product-${prod.id}`] = prod.title);
        return map;
    }, [purchaseItems, products]);
    
    const manufacturingProcessOptions = useMemo(() => manufacturingProcesses.map(p => ({ value: p.id, label: p.name })), [manufacturingProcesses]);

    const productGroupOptions = useMemo(() => {
        const options: { value: number; label: string }[] = [];
        const buildOptions = (groupNodes: ProductGroup[], level = 0) => {
            for (const group of groupNodes) {
                options.push({ value: group.id, label: '\u00A0'.repeat(level * 4) + group.title });
                if (group.children && group.children.length > 0) buildOptions(group.children, level + 1);
            }
        };
        buildOptions(productGroups);
        return options;
    }, [productGroups]);

    const unitOptions = useMemo(() => measurementUnits.map(u => ({ value: u.title, label: u.title })), [measurementUnits]);
    const warehouseOptions = useMemo(() => warehouses.map(w => ({ value: w.id, label: w.name })), [warehouses]);
    const purchaseItemOptions = useMemo(() => purchaseItems.map(i => ({ value: i.id, label: `${i.code} - ${i.title}` })), [purchaseItems]);
    const productOptions = useMemo(() => products.map(p => ({ value: p.id, label: `${p.code} - ${p.title}` })), [products]);

    const handleChange = (field: keyof typeof initialState, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleAddProcess = () => {
        setProcesses(prev => [...prev, { id: Date.now(), manufacturingProcessId: null, components: [] }]);
    };
    
    const handleProcessChange = (processId: number, manufacturingProcessId: number | null) => {
        setProcesses(prev => prev.map(p => p.id === processId ? { ...p, manufacturingProcessId } : p));
    };
    
    const handleRemoveProcess = (processId: number) => {
        setProcesses(prev => prev.filter(p => p.id !== processId));
    };
    
    const handleNewComponentChange = (processId: number, field: keyof NewComponentState, value: any) => {
        setNewComponentData(prev => ({
            ...prev,
            [processId]: {
                ...prev[processId] || { componentType: 'purchaseItem', componentId: null, quantity: '' },
                [field]: value,
                // Reset componentId when type changes
                ...(field === 'componentType' && { componentId: null })
            }
        }));
    };

    const handleAddComponent = (processId: number) => {
        const newComponent = newComponentData[processId];
        if (!newComponent || !newComponent.componentId || !newComponent.quantity) {
            alert("لطفا نوع، قلم کالا و تعداد را مشخص کنید.");
            return;
        }

        const componentToAdd: ProductComponent = {
            componentType: newComponent.componentType,
            componentId: Number(newComponent.componentId),
            quantity: Number(newComponent.quantity),
        };

        setProcesses(prev => prev.map(p =>
            p.id === processId ? { ...p, components: [...p.components, componentToAdd] } : p
        ));

        // Clear the input form for that process
        setNewComponentData(prev => {
            const newState = { ...prev };
            delete newState[processId];
            return newState;
        });
    };
    
    const handleRemoveComponent = (processId: number, componentIndex: number) => {
        setProcesses(prev => prev.map(p =>
            p.id === processId ? { ...p, components: p.components.filter((_, idx) => idx !== componentIndex) } : p
        ));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.productGroupId) {
            alert('لطفا یک گروه محصول انتخاب کنید.');
            return;
        }
        if (!formData.primaryUnit) {
            alert('لطفا واحد اندازه گیری اصلی را انتخاب کنید.');
            return;
        }
        if (processes.some(p => p.manufacturingProcessId === null)) {
            alert('لطفا برای تمام فرآیندها، یک فرآیند تعریف شده را انتخاب کنید.');
            return;
        }
        addProduct({
            code: formData.code,
            title: formData.title,
            productGroupId: Number(formData.productGroupId),
            primaryUnit: formData.primaryUnit,
            secondaryUnit: formData.secondaryUnit,
            cost: Number(formData.cost),
            processes: processes,
            defaultWarehouseId: formData.defaultWarehouseId
        });
        setFormData(initialState);
        setProcesses([]);
        alert('محصول جدید با موفقیت ذخیره شد.');
    };
    
    const handleDelete = (productId: number) => {
        if(window.confirm('آیا از حذف این محصول اطمینان دارید؟')) {
            deleteProduct(productId);
        }
    }

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف محصول (BOM)</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-8 divide-y divide-slate-200 dark:divide-slate-700">
                    {/* Product Details */}
                    <div className="space-y-6 pt-2">
                        <h3 className="text-lg font-medium text-slate-900 dark:text-white">اطلاعات پایه محصول</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <FormInput label="کد کالا" id="code" name="code" value={formData.code} onChange={e => handleChange('code', e.target.value)} required />
                            <FormInput label="عنوان کالا" id="title" name="title" value={formData.title} onChange={e => handleChange('title', e.target.value)} required />
                            <CustomFormSelect label="گروه محصول" required>
                                <SearchableSelect options={productGroupOptions} value={formData.productGroupId} onChange={val => handleChange('productGroupId', val)} placeholder="انتخاب گروه..."/>
                            </CustomFormSelect>
                            <CustomFormSelect label="واحد اندازه گیری اصلی" required>
                                <SearchableSelect options={unitOptions} value={formData.primaryUnit} onChange={val => handleChange('primaryUnit', val)} placeholder="انتخاب واحد..." />
                            </CustomFormSelect>
                             <CustomFormSelect label="واحد اندازه گیری فرعی">
                                <SearchableSelect options={unitOptions} value={formData.secondaryUnit} onChange={val => handleChange('secondaryUnit', val)} placeholder="انتخاب واحد..." />
                            </CustomFormSelect>
                            <FormInput label="بهای تمام شده ساخت" id="cost" name="cost" type="number" value={formData.cost} onChange={e => handleChange('cost', e.target.value)} required />
                            <CustomFormSelect label="انبار پیشفرض">
                                <SearchableSelect options={warehouseOptions} value={formData.defaultWarehouseId} onChange={val => handleChange('defaultWarehouseId', val)} placeholder="انتخاب انبار..." />
                            </CustomFormSelect>
                        </div>
                    </div>

                    {/* BOM Processes */}
                    <div className="space-y-6 pt-8">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-medium text-slate-900 dark:text-white">فرآیندهای ساخت (BOM)</h3>
                            <button type="button" onClick={handleAddProcess} className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">افزودن فرآیند</button>
                        </div>
                        <div className="space-y-6">
                            {processes.map((process) => (
                                <div key={process.id} className="p-4 border rounded-lg dark:border-slate-700 space-y-4 bg-slate-50 dark:bg-slate-800">
                                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                                        <div className="flex-grow">
                                            <SearchableSelect
                                                options={manufacturingProcessOptions}
                                                value={process.manufacturingProcessId}
                                                onChange={(val) => handleProcessChange(process.id, val as number | null)}
                                                placeholder="انتخاب فرآیند..."
                                            />
                                        </div>
                                        <button type="button" onClick={() => handleRemoveProcess(process.id)} className="p-2 text-red-500 hover:bg-red-100 dark:hover:bg-red-900 rounded-full">
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                                        </button>
                                    </div>
                                    <table className="w-full text-sm">
                                        <thead>
                                            <tr className='text-slate-600 dark:text-slate-400'>
                                                <th className='p-2 text-right'>جزء</th>
                                                <th className='p-2 text-right'>نوع</th>
                                                <th className='p-2 text-center w-24'>تعداد</th>
                                                <th className='w-10'></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {process.components.map((comp, index) => (
                                                <tr key={index} className="border-t dark:border-slate-600">
                                                    <td className="p-2">{componentNameMap[`${comp.componentType}-${comp.componentId}`] || 'نامشخص'}</td>
                                                    <td className="p-2 text-xs">{comp.componentType === 'product' ? 'محصول' : 'خریدنی'}</td>
                                                    <td className="p-2 text-center">{comp.quantity}</td>
                                                    <td><button type="button" onClick={() => handleRemoveComponent(process.id, index)} className="text-red-500">&times;</button></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        <tfoot className="bg-slate-100 dark:bg-slate-700/50">
                                            <tr>
                                                <td className="p-2" colSpan={2}>
                                                    <div className="flex gap-2">
                                                        <div className="w-1/3">
                                                            <SearchableSelect options={[{value: 'purchaseItem', label: 'خریدنی'}, {value: 'product', label: 'محصول'}]} value={newComponentData[process.id]?.componentType || 'purchaseItem'} onChange={val => handleNewComponentChange(process.id, 'componentType', val)} />
                                                        </div>
                                                        <div className="w-2/3">
                                                            <SearchableSelect options={newComponentData[process.id]?.componentType === 'product' ? productOptions : purchaseItemOptions} value={newComponentData[process.id]?.componentId || null} onChange={val => handleNewComponentChange(process.id, 'componentId', val)} placeholder="انتخاب قلم..." />
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="p-1">
                                                     <FormattedNumberInput value={newComponentData[process.id]?.quantity || ''} onValueChange={val => handleNewComponentChange(process.id, 'quantity', val)} className="w-full h-full bg-white dark:bg-slate-700 p-2 text-center focus:outline-none rounded-md border border-slate-300 dark:border-slate-600" />
                                                </td>
                                                <td className="p-2 text-center">
                                                    <button type="button" onClick={() => handleAddComponent(process.id)} className="px-3 py-1 text-xs text-white bg-green-600 rounded-md">+</button>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            ))}
                             {processes.length === 0 && <p className="text-center text-slate-500 dark:text-slate-400 py-4">هنوز فرآیندی اضافه نشده است.</p>}
                        </div>
                    </div>

                    <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">ذخیره محصول</button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">محصولات تعریف شده</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">کد</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">عنوان</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">گروه</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">انبار پیشفرض</th>
                                <th className="px-6 py-3 text-right text-xs font-medium uppercase">بهای تمام شده</th>
                                <th className="px-6 py-3 text-center text-xs font-medium uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {products.length > 0 ? (
                                products.map(p => (
                                    <tr key={p.id}>
                                        <td className="px-6 py-4">{p.code}</td>
                                        <td className="px-6 py-4 font-medium">{p.title}</td>
                                        <td className="px-6 py-4">{productGroupMap[p.productGroupId] || '-'}</td>
                                        <td className="px-6 py-4">{p.defaultWarehouseId ? warehouseMap.get(p.defaultWarehouseId) : '-'}</td>
                                        <td className="px-6 py-4 font-mono">{new Intl.NumberFormat('en-US').format(p.cost)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                            <button className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                            <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr><td colSpan={6} className="text-center py-4">هنوز محصولی تعریف نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default DefineProduct;