import React, { useState, useEffect } from 'react';
import type { Currency } from '../types';
import Card from './ui/Card';
import Modal from './ui/Modal';

interface DefineCurrenciesProps {
    currencies: Currency[];
    addCurrency: (currency: Omit<Currency, 'id'>) => void;
    updateCurrency: (currency: Currency) => void;
    deleteCurrency: (currencyId: number) => void;
}

const CurrencyModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: Omit<Currency, 'id'>) => void;
    mode: 'add' | 'edit';
    initialData?: Currency | null;
}> = ({ isOpen, onClose, onSubmit, mode, initialData }) => {
    const [name, setName] = useState('');
    const [code, setCode] = useState('');

    useEffect(() => {
        if (isOpen) {
            setName(initialData?.name || '');
            setCode(initialData?.code || '');
        }
    }, [initialData, isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit({ name, code });
        onClose();
    };

    const modalTitle = mode === 'add' ? 'افزودن ارز جدید' : `ویرایش ارز: ${initialData?.name}`;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">نام ارز (فارسی)</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="مثال: دلار آمریکا"
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                        required
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">کد اختصاری جهانی (۳ حرفی)</label>
                    <input
                        type="text"
                        value={code}
                        onChange={(e) => setCode(e.target.value.toUpperCase())}
                        placeholder="مثال: USD"
                        maxLength={3}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                        required
                    />
                </div>
                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500">
                        لغو
                    </button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">
                        ذخیره
                    </button>
                </div>
            </form>
        </Modal>
    );
};

const DefineCurrencies: React.FC<DefineCurrenciesProps> = ({ currencies, addCurrency, updateCurrency, deleteCurrency }) => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
    const [selectedCurrency, setSelectedCurrency] = useState<Currency | null>(null);

    const handleOpenAddModal = () => {
        setSelectedCurrency(null);
        setModalMode('add');
        setModalOpen(true);
    };

    const handleOpenEditModal = (currency: Currency) => {
        setSelectedCurrency(currency);
        setModalMode('edit');
        setModalOpen(true);
    };

    const handleDelete = (currencyId: number) => {
        if (window.confirm('آیا از حذف این ارز اطمینان دارید؟ این عمل ممکن است بر بخش‌های دیگر سیستم تاثیر بگذارد.')) {
            deleteCurrency(currencyId);
        }
    };

    const handleModalSubmit = (data: Omit<Currency, 'id'>) => {
        if (modalMode === 'add') {
            addCurrency(data);
        } else if (selectedCurrency) {
            updateCurrency({ ...selectedCurrency, ...data });
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف ارزهای جهانی</h1>
                <button
                    onClick={handleOpenAddModal}
                    className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700"
                >
                    افزودن ارز جدید
                </button>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
                در این بخش می‌توانید ارزهای مورد استفاده در سیستم را مدیریت کنید. این فهرست در تمام بخش‌های نرم‌افزار (مانند تعریف سال مالی و ثبت فاکتور) استفاده خواهد شد.
            </p>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">نام ارز</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">کد اختصاری</th>
                                <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">عملیات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                            {currencies.map((currency) => (
                                <tr key={currency.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{currency.name}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400 font-mono">{currency.code}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-2 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(currency)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => handleDelete(currency.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
            <CurrencyModal
                isOpen={isModalOpen}
                onClose={() => setModalOpen(false)}
                onSubmit={handleModalSubmit}
                mode={modalMode}
                initialData={selectedCurrency}
            />
        </div>
    );
};

export default DefineCurrencies;
