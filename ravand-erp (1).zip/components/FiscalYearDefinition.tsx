

import React, { useState, useMemo, useEffect } from 'react';
import type { FiscalYear, Currency } from '../types';
import Card from './ui/Card';
import SearchableSelect from './ui/SearchableSelect';
import ShamsiDatePicker from './ui/ShamsiDatePicker';
import { toShamsi } from '../utils/date';
import Modal from './ui/Modal';


interface FiscalYearDefinitionProps {
    fiscalYears: FiscalYear[];
    addFiscalYear: (year: Omit<FiscalYear, 'id'>) => void;
    updateFiscalYear: (year: FiscalYear) => void;
    deleteFiscalYear: (yearId: number) => void;
    isFiscalYearEmpty: (yearId: number) => boolean;
    currencies: Currency[];
}

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <input id={id} {...props} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 disabled:bg-slate-100 dark:disabled:bg-slate-800" />
    </div>
);

const CustomFormSelect: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
     <div>
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {children}
    </div>
);

const EditFiscalYearModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    fiscalYear: FiscalYear | null;
    updateFiscalYear: (year: FiscalYear) => void;
    isFiscalYearEmpty: boolean;
    currencies: Currency[];
}> = ({ isOpen, onClose, fiscalYear, updateFiscalYear, isFiscalYearEmpty, currencies }) => {
    
    const [formData, setFormData] = useState<FiscalYear | null>(fiscalYear);

    useEffect(() => {
        setFormData(fiscalYear);
    }, [fiscalYear]);

    if (!isOpen || !formData) return null;
    
    const currencyOptions = currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`}));

    const handleChange = (field: keyof Omit<FiscalYear, 'id'>, value: any) => {
        setFormData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData) {
            updateFiscalYear(formData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`ویرایش سال مالی: ${fiscalYear?.title}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <FormInput label="عنوان سال مالی" id="title" value={formData.title} onChange={e => handleChange('title', e.target.value)} required />
                <div>
                    <label className="block text-sm font-medium mb-1">تاریخ شروع</label>
                    <ShamsiDatePicker value={formData.startDate} onChange={date => handleChange('startDate', date)} required disabled={!isFiscalYearEmpty} />
                </div>
                 <div>
                    <label className="block text-sm font-medium mb-1">تاریخ پایان</label>
                    <ShamsiDatePicker value={formData.endDate} onChange={date => handleChange('endDate', date)} required disabled={!isFiscalYearEmpty} />
                </div>
                <CustomFormSelect label="ارز اصلی">
                    <SearchableSelect options={currencyOptions} value={formData.mainCurrency} onChange={val => handleChange('mainCurrency', val)} disabled={!isFiscalYearEmpty} />
                </CustomFormSelect>
                <CustomFormSelect label="ارز فرعی">
                    <SearchableSelect options={currencyOptions} value={formData.secondaryCurrency} onChange={val => handleChange('secondaryCurrency', val)} disabled={!isFiscalYearEmpty} />
                </CustomFormSelect>

                {!isFiscalYearEmpty && (
                    <p className="text-sm text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/50 p-3 rounded-md">
                        چون در این سال مالی اطلاعات ثبت شده است، فقط عنوان قابل ویرایش است.
                    </p>
                )}

                <div className="flex justify-end pt-4 space-x-2 rtl:space-x-reverse border-t dark:border-slate-600">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-600 dark:hover:bg-slate-500">لغو</button>
                    <button type="submit" className="px-4 py-2 text-sm rounded-md text-white bg-cyan-600 hover:bg-cyan-700">ذخیره تغییرات</button>
                </div>
            </form>
        </Modal>
    );
};


const FiscalYearDefinition: React.FC<FiscalYearDefinitionProps> = ({ fiscalYears, addFiscalYear, updateFiscalYear, deleteFiscalYear, isFiscalYearEmpty, currencies }) => {
    const initialState: Omit<FiscalYear, 'id'> = {
        title: '',
        startDate: '',
        endDate: '',
        mainCurrency: 'IRR',
        secondaryCurrency: 'USD',
    };
    
    const [formData, setFormData] = useState(initialState);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [selectedFiscalYear, setSelectedFiscalYear] = useState<FiscalYear | null>(null);

    const currencyMap = useMemo(() => 
        currencies.reduce((map, currency) => {
            map[currency.code] = currency.name;
            return map;
        }, {} as Record<string, string>),
    [currencies]);

    const currencyOptions = useMemo(() => currencies.map(c => ({ value: c.code, label: `${c.name} (${c.code})`})), [currencies]);

    const handleSelectChange = (name: string, value: string | number | null) => {
        setFormData({ ...formData, [name]: value });
    }

    const handleDateChange = (name: 'startDate' | 'endDate', value: string) => {
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addFiscalYear(formData);
        setFormData(initialState); // Reset form after submission
        alert('سال مالی جدید با موفقیت ذخیره شد.');
    };
    
    const handleOpenEditModal = (year: FiscalYear) => {
        setSelectedFiscalYear(year);
        setEditModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">تعریف سال مالی</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-end">
                        <FormInput label="عنوان سال مالی" id="title" name="title" type="text" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} required />
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تاریخ شروع سال مالی</label>
                            <ShamsiDatePicker value={formData.startDate} onChange={date => handleDateChange('startDate', date)} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">تاریخ پایان سال مالی</label>
                            <ShamsiDatePicker value={formData.endDate} onChange={date => handleDateChange('endDate', date)} required />
                        </div>
                        <CustomFormSelect label="ارز اصلی سیستم">
                            <SearchableSelect options={currencyOptions} value={formData.mainCurrency} onChange={val => handleSelectChange('mainCurrency', val)} />
                        </CustomFormSelect>
                         <CustomFormSelect label="ارز فرعی سیستم">
                             <SearchableSelect options={currencyOptions} value={formData.secondaryCurrency} onChange={val => handleSelectChange('secondaryCurrency', val)} />
                        </CustomFormSelect>
                    </div>
                     <div className="flex justify-end pt-5">
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
                            ذخیره سال مالی
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">سال‌های مالی تعریف شده</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عنوان سال مالی</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">تاریخ شروع</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">تاریخ پایان</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">ارز اصلی</th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">ارز فرعی</th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        {fiscalYears.length > 0 ? (
                            fiscalYears.map((year) => (
                                <tr key={year.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{year.title}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{toShamsi(year.startDate)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{toShamsi(year.endDate)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{`${currencyMap[year.mainCurrency] || year.mainCurrency}`}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{`${currencyMap[year.secondaryCurrency] || year.secondaryCurrency}`}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center space-x-4 rtl:space-x-reverse">
                                        <button onClick={() => handleOpenEditModal(year)} className="text-amber-600 hover:text-amber-800">ویرایش</button>
                                        <button onClick={() => deleteFiscalYear(year.id)} className="text-red-600 hover:text-red-800">حذف</button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                                    هنوز سال مالی تعریف نشده است.
                                </td>
                            </tr>
                        )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <EditFiscalYearModal
                isOpen={isEditModalOpen}
                onClose={() => setEditModalOpen(false)}
                fiscalYear={selectedFiscalYear}
                updateFiscalYear={updateFiscalYear}
                isFiscalYearEmpty={selectedFiscalYear ? isFiscalYearEmpty(selectedFiscalYear.id) : true}
                currencies={currencies}
            />
        </div>
    );
};

export default FiscalYearDefinition;