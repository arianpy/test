
import type { Currency } from '../types';

export const initialCurrencies: Currency[] = [
  { id: 1, name: 'ریال ایران', code: 'IRR' },
  { id: 2, name: 'دلار آمریکا', code: 'USD' },
  { id: 3, name: 'یورو', code: 'EUR' },
  { id: 4, name: 'پوند بریتانیا', code: 'GBP' },
  { id: 5, name: 'درهم امارات', code: 'AED' },
  { id: 6, name: 'لیر ترکیه', code: 'TRY' },
  { id: 7, name: 'ین ژاپن', code: 'JPY' },
  { id: 8, name: 'فرانک سوئیس', code: 'CHF' },
  { id: 9, name: 'دلار کانادا', code: 'CAD' },
  { id: 10, name: 'دلار استرالیا', code: 'AUD' },
  { id: 11, name: 'یوان چین', code: 'CNY' },
  { id: 12, name: 'روپیه هند', code: 'INR' },
  { id: 13, name: 'روبل روسیه', code: 'RUB' },
  { id: 14, name: 'وون کره جنوبی', code: 'KRW' },
  { id: 15, name: 'دلار سنگاپور', code: 'SGD' },
  { id: 16, name: 'دلار نیوزیلند', code: 'NZD' },
  { id: 17, name: 'بیت‌کوین', code: 'BTC' },
  { id: 18, name: 'اتریوم', code: 'ETH' },
  { id: 19, name: 'تتر', code: 'USDT' },
  { id: 20, name: 'بایننس کوین', code: 'BNB' },
];
