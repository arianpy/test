import React from 'react';
import type { Module, SubView } from '../App';

const DashboardIcon = () => React.createElement(
  'svg',
  { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
  React.createElement('path', { d: "M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" })
);

const AccountingIcon = () => React.createElement(
  'svg',
  { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
  React.createElement('path', { d: "M2 6a2 2 0 012-2h12a2 2 0 012 2v1H2V6zM2 9h16v7a2 2 0 01-2 2H4a2 2 0 01-2-2V9zm4 2a1 1 0 00-1 1v1a1 1 0 102 0v-1a1 1 0 00-1-1z" })
);

const ReceiveAndPayIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M8.433 7.418c.158-.103.34-.153.521-.153h.092a2.458 2.458 0 011.895 1.034.5.5 0 10.832-.552A3.458 3.458 0 009.045 6.26c-.305 0-.594.082-.843.231l-4.03 2.518a.5.5 0 00-.017.893l4.03 2.518c.249.15.538.232.843.232.87 0 1.638-.42 2.14-1.09a.5.5 0 10-.764-.648A1.458 1.458 0 019.045 11.26a.5.5 0 00-.521-.153L4.49 8.589l4.033-2.518a.5.5 0 00-.09-.653z" }),
    React.createElement('path', { d: "M12.5 7.5a.5.5 0 01.5-.5h3a.5.5 0 01.5.5v5a.5.5 0 01-1 0v-2h-2.5a.5.5 0 01-.5-.5V8h1v1.5a.5.5 0 01-.5.5H13v-1.5a.5.5 0 01.5-.5z" })
);

const BudgetingIcon = () => React.createElement(
  'svg',
  { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
  React.createElement('path', { d: "M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" }),
  React.createElement('path', { d: "M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" })
);

const ProductionIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { fillRule: "evenodd", d: "M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379-1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z", clipRule: "evenodd" })
);

const PayrollIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" })
);

const HumanResourcesIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 24 24", fill: "currentColor" },
    React.createElement('path', { d: "M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM12 14c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" })
);


const AssetManagementIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M8.433 7.418c.158-.103.34-.153.521-.153h.092a2.458 2.458 0 011.895 1.034.5.5 0 10.832-.552A3.458 3.458 0 009.045 6.26c-.305 0-.594.082-.843.231l-4.03 2.518a.5.5 0 00-.017.893l4.03 2.518c.249.15.538.232.843.232.87 0 1.638-.42 2.14-1.09a.5.5 0 10-.764-.648A1.458 1.458 0 019.045 11.26a.5.5 0 00-.521-.153L4.49 8.589l4.033-2.518a.5.5 0 00-.09-.653z" }),
    React.createElement('path', { d: "M12.5 7.5a.5.5 0 01.5-.5h3a.5.5 0 01.5.5v5a.5.5 0 01-1 0v-2h-2.5a.5.5 0 01-.5-.5V8h1v1.5a.5.5 0 01-.5.5H13v-1.5a.5.5 0 01.5-.5z" })
);

const SettingsIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { fillRule: "evenodd", d: "M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379-1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z", clipRule: "evenodd" })
);

const FinancialManagementIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 24 24", fill: "currentColor" },
    React.createElement('path', { d: "M11.5,1L2,6v2h19V6L11.5,1z M16,10v6h2v-6h-2z M10,10v6h2v-6h-2z M4,10v6h2v-6H4z M21,18H2v2h19V18z" })
);

const SalesManagementIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 24 24", fill: "currentColor" },
    React.createElement('path', { d: "M19 7h-1V5h-2v2H8V5H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm0 12H5V10h14v9z M7 12h5v5H7v-5z" })
);

const TrendsManagementIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" }),
    React.createElement('path', { d: "M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" })
);

const SupplyChainIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M11 17a1 1 0 001.447.894l4-2A1 1 0 0017 15V5a1 1 0 00-1.447-.894l-4 2A1 1 0 0011 7v10z" }),
    React.createElement('path', { d: "M4 3a1 1 0 00-1 1v10a1 1 0 001.447.894l4-2A1 1 0 009 15V5a1 1 0 00-1.447-.894l-4 2A1 1 0 003 7V4a1 1 0 001-1z" })
);

const CampaignIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { fillRule: "evenodd", d: "M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 000 18h20a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4z", clipRule: "evenodd" })
);

const OpportunityIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { fillRule: "evenodd", d: "M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z", clipRule: "evenodd" })
);

const QuotationIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" }),
    React.createElement('path', { d: "M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" })
);

const CrmIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" })
);

const BusinessArchitectureIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { d: "M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3 1a1 1 0 000 2h3a1 1 0 100-2H5zm0 4a1 1 0 000 2h3a1 1 0 100-2H5zm0 4a1 1 0 000 2h3a1 1 0 100-2H5zm5-8a1 1 0 000 2h3a1 1 0 100-2h-3zm0 4a1 1 0 000 2h3a1 1 0 100-2h-3zm0 4a1 1 0 000 2h3a1 1 0 100-2h-3z" })
);

const DeploymentIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", viewBox: "0 0 20 20", fill: "currentColor" },
    React.createElement('path', { fillRule: "evenodd", d: "M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm9 4a1 1 0 10-2 0v6a1 1 0 102 0V7zm-3 2a1 1 0 10-2 0v4a1 1 0 102 0V9zm-3 3a1 1 0 10-2 0v1a1 1 0 102 0v-1z", clipRule: "evenodd" })
);

const OrgStructureIcon = () => React.createElement(
    'svg',
    { xmlns: "http://www.w3.org/2000/svg", className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: 2 },
    React.createElement('path', { strokeLinecap: "round", strokeLinejoin: "round", d: "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" })
);


export type SubViewSimple = { id: SubView, label: string };
export type SubViewGroup = {
    type: 'subgroup';
    label: string;
    subViews: SubViewSimple[];
};
export type SubViewEntry = SubViewSimple | SubViewGroup;

export type ModuleItem = {
    type: 'module';
    id: Module;
    label: string;
    icon: React.ReactElement;
    subViews: SubViewEntry[];
};

export type GroupItem = {
    type: 'group';
    id: string;
    label: string;
    icon: React.ReactElement;
    modules: ModuleItem[];
};

export type SidebarItem = ModuleItem | GroupItem;

export const sidebarStructure: SidebarItem[] = [
    {
        type: 'module',
        id: 'settings', label: 'تنظیمات نرم افزار', icon: React.createElement(SettingsIcon),
        subViews: [
            { id: 'companyDefinition', label: 'تعریف شرکت' },
            { id: 'defineCurrencies', label: 'تعریف ارزهای جهانی' },
            { id: 'fiscalYearDefinition', label: 'تعریف سال مالی' },
            { id: 'appearanceSettings', label: 'تنظیمات ظاهری' },
            {
                type: 'subgroup',
                label: 'مدیریت کاربران',
                subViews: [
                    { id: 'groupPermissions', label: 'گروه کاربران و دسترسی‌ها' },
                    { id: 'userManagement', label: 'تعریف کاربران' },
                ]
            },
            { id: 'groupingManagement', label: 'مدیریت گروه بندی فرمها' },
            { id: 'backupAndRestore', label: 'پشتیبانی و بازیابی' },
        ]
    },
    {
        type: 'group',
        id: 'businessArchitecture',
        label: 'معماری کسب و کار',
        icon: React.createElement(BusinessArchitectureIcon),
        modules: [
            {
                type: 'module',
                id: 'deploymentManagement',
                label: 'مدیریت استقرار سازمان',
                icon: React.createElement(DeploymentIcon),
                subViews: [
                    { type: 'subgroup', label: 'تعاریف', subViews: [{ id: 'deploymentStructureDefinition', label: 'تعریف ساختار استقرار' }] },
                    { id: 'operations', label: 'عملیات' },
                    { id: 'reports', label: 'گزارشات' },
                ]
            },
            { 
                type: 'module', 
                id: 'trendsManagement', 
                label: 'مدیریت روندها (BPMS)', 
                icon: React.createElement(TrendsManagementIcon), 
                subViews: [
                    { id: 'defineTrend', label: 'تعریف روند' },
                    { id: 'operations', label: 'عملیات روندها' },
                    { id: 'reports', label: 'گزارشات روندها' },
                    { id: 'personalSettings', label: 'تنظیمات شخصی' },
                ]
            },
            {
                type: 'module',
                id: 'orgStructure',
                label: 'ساختار سازمانی',
                icon: React.createElement(OrgStructureIcon),
                subViews: [
                    { type: 'subgroup', label: 'تعاریف', subViews: [
                        { id: 'orgChartSetup', label: 'تنظیم چارت سازمانی' },
                        { id: 'orgTaskSetup', label: 'تنظیم وظایف سازمانی' },
                        { id: 'personnelDefinition', label: 'تعریف پرسنل سازمانی' },
                        { id: 'personnelContractSettings', label: 'تنظیم قرارداد پرسنلی' },
                    ] },
                    { id: 'reports', label: 'گزارشات' },
                ]
            },
        ]
    },
     {
        type: 'group',
        id: 'financial',
        label: 'مدیریت مالی',
        icon: React.createElement(FinancialManagementIcon),
        modules: [
            {
                type: 'module',
                id: 'accounting', label: 'حسابداری', icon: React.createElement(AccountingIcon),
                subViews: [
                    {
                        type: 'subgroup',
                        label: 'تعاریف',
                        subViews: [
                            { id: 'accountHeadDefinition', label: 'تعریف سرفصل' },
                            { id: 'detailedCodingSetup', label: 'تنظیمات کدینگ تفصیلی' },
                            { id: 'autoDocSetup', label: 'تنظیمات سند خودکار' },
                        ]
                    },
                     {
                        type: 'subgroup',
                        label: 'عملیات',
                        subViews: [
                            { id: 'issueAccountingDocument', label: 'صدور سند حسابداری' },
                            { id: 'accountControl', label: 'کنترل سرفصلها' },
                        ]
                    },
                    {
                        type: 'subgroup',
                        label: 'گزارشات',
                        subViews: [
                            { id: 'ledgerReports', label: 'گزارش دفاتر' },
                        ]
                    }
                ]
            },
            {
                type: 'module',
                id: 'receiveAndPay', label: 'خزانه داری', icon: React.createElement(ReceiveAndPayIcon),
                subViews: [
                     {
                        type: 'subgroup',
                        label: 'تعاریف',
                        subViews: [
                            { id: 'defineBanks', label: 'تعریف بانکها' },
                            { id: 'defineCheckbooks', label: 'تعریف دسته چک‌ها' },
                            { id: 'defineCashboxes', label: 'تعریف صندوق' },
                            { id: 'definePOSTerminals', label: 'تعریف کارت خوان' },
                            { id: 'definePaymentGateways', label: 'تعریف درگاه پرداخت' },
                            { id: 'definePettyCash', label: 'تعریف تنخواه گردان' },
                        ]
                    },
                     {
                        type: 'subgroup',
                        label: 'عملیات',
                        subViews: [
                            { id: 'registerTreasuryTransaction', label: 'ثبت تراکنش خزانه' },
                            { id: 'documentManagement', label: 'مدیریت اسناد خزانه' },
                        ]
                    },
                    {
                        type: 'subgroup',
                        label: 'گزارشات',
                        subViews: [
                            { id: 'cashAndBankReport', label: 'گزارش نقد و بانک' },
                        ]
                    },
                ]
            },
             {
                type: 'module',
                id: 'payroll', label: 'حقوق و دستمزد', icon: React.createElement(PayrollIcon),
                subViews: [
                     { type: 'subgroup', label: 'تعاریف', subViews: [{ id: 'payrollFactorsDefinition', label: 'تعریف عوامل حقوق و دستمزد' }] },
                     { type: 'subgroup', label: 'عملیات', subViews: [
                         { id: 'registerMonthlyWorklog', label: 'ثبت کارکرد ماهیانه' },
                         { id: 'monthlyPayrollCalculation', label: 'محاسبه حقوق ماهانه' },
                     ] },
                     { id: 'reports', label: 'گزارشات' },
                ]
            },
            {
                type: 'module',
                id: 'assetManagement', label: 'جمع داری اموال', icon: React.createElement(AssetManagementIcon),
                subViews: [
                    { type: 'subgroup', label: 'تعاریف', subViews: [
                        { id: 'defineAssetLocation', label: 'تعریف محل استقرار' },
                        { id: 'defineDepreciationMethod', label: 'تعریف روش استهلاک' },
                        { id: 'defineAsset', label: 'تعریف دارایی' },
                    ]},
                    { type: 'subgroup', label: 'عملیات', subViews: [
                        { id: 'assetDeployment', label: 'استقرار دارایی' },
                        { id: 'assetDepreciation', label: 'استهلاک دارایی' },
                    ]},
                    { id: 'reports', label: 'گزارشات' },
                ]
            },
        ]
    },
    {
        type: 'module',
        id: 'supplyManagement', label: 'مدیریت تامین', icon: React.createElement(SupplyChainIcon),
        subViews: [
            {
                type: 'subgroup',
                label: 'تعاریف',
                subViews: [
                    { id: 'definePurchaseItemGroup', label: 'تعریف گروه اقلام خریدنی' },
                    { id: 'definePurchaseItem', label: 'تعریف اقلام خریدنی' },
                    { id: 'defineServiceItem', label: 'تعریف خدمات' },
                    { id: 'defineWarehouse', label: 'تعریف انبار' },
                    { id: 'defineMeasurementUnit', label: 'تعریف واحد اندازه گیری' },
                    { id: 'definePersons', label: 'تعریف اشخاص (تامین کنندگان)' },
                ]
            },
            {
                type: 'subgroup',
                label: 'عملیات',
                subViews: [
                    { id: 'registerPurchaseInvoice', label: 'ثبت فاکتور خرید اقلام' },
                    { id: 'registerPurchaseReturnInvoice', label: 'ثبت فاکتور برگشت خرید اقلام' },
                    { id: 'registerAssetPurchaseInvoice', label: 'ثبت فاکتور خرید دارایی' },
                    { id: 'registerAssetPurchaseReturnInvoice', label: 'ثبت فاکتور برگشت خرید دارایی' },
                    { id: 'registerServicePurchaseInvoice', label: 'ثبت فاکتور خرید خدمات (هزینه)' },
                    { id: 'registerWarehouseReceipt', label: 'ثبت رسید انبار' },
                    { id: 'registerWarehouseReceiptReturn', label: 'ثبت برگشت رسید انبار' },
                    { id: 'registerWarehouseIssue', label: 'ثبت خروج انبار' },
                    { id: 'registerWarehouseIssueReturn', label: 'ثبت برگشت خروج انبار' },
                    { id: 'registerWarehouseTransfer', label: 'ثبت انتقال بین انبارها' },
                ]
            },
            {
                type: 'subgroup',
                label: 'گزارشات',
                subViews: [
                    { id: 'reports', label: 'گزارشات تامین' },
                ]
            },
        ]
    },
    {
        type: 'module',
        id: 'productionManagement', label: 'مدیریت تولید', icon: React.createElement(ProductionIcon),
        subViews: [
            {
                type: 'subgroup',
                label: 'تعاریف',
                subViews: [
                    { id: 'defineWorkstations', label: 'تعریف ایستگاه کاری' },
                    { id: 'defineMachineryGroup', label: 'تعریف گروه ماشین آلات' },
                    { id: 'defineMachinery', label: 'تعریف ماشین آلات' },
                    { id: 'defineManufacturingProcess', label: 'تعریف فرآیند' },
                    { id: 'defineProductGroup', label: 'تعریف گروه محصولات' },
                    { id: 'defineProducts', label: 'تعریف محصولات' },
                ]
            },
            {
                type: 'subgroup',
                label: 'عملیات',
                subViews: [
                    { id: 'registerProductManufacturing', label: 'ثبت سند تولید محصول' },
                ]
            },
            {
                type: 'subgroup',
                label: 'گزارشات',
                subViews: [
                    { id: 'reports', label: 'گزارشات تولید' },
                ]
            },
        ]
    },
    {
        type: 'group',
        id: 'salesAndMarketing',
        label: 'مدیریت فروش و بازاریابی',
        icon: React.createElement(SalesManagementIcon),
        modules: [
            {
                type: 'module',
                id: 'crm', label: 'مدیریت ارتباط با مشتری', icon: React.createElement(CrmIcon),
                subViews: [
                     { id: 'salesTimeline', label: 'تایم لاین عملیاتی' },
                ]
            },
            {
                type: 'module',
                id: 'campaignManagement', label: 'مدیریت کمپین ها', icon: React.createElement(CampaignIcon),
                subViews: [
                     {
                        type: 'subgroup',
                        label: 'تعاریف',
                        subViews: [
                            { id: 'defineCampaignAudience', label: 'تعریف مخاطبان کمپین' },
                            { id: 'defineEmailTemplate', label: 'تعریف قالب ایمیل مارکتینگ' },
                            { id: 'defineSmsTemplate', label: 'تعریف قالب SMS مارکتینگ' },
                            { id: 'defineSocialTemplate', label: 'تعریف قالب سوشال مارکتینگ' },
                        ]
                    },
                     { id: 'defineCampaigns', label: 'عملیات' },
                     { id: 'reports', label: 'گزارشات' },
                ]
            },
            {
                type: 'module',
                id: 'opportunityManagement', label: 'مدیریت فرصت‌ها', icon: React.createElement(OpportunityIcon),
                subViews: [
                     { id: 'registerOpportunity', label: 'عملیات' },
                     { id: 'reports', label: 'گزارشات' },
                ]
            },
            {
                type: 'module',
                id: 'quotationManagement', label: 'مدیریت پیش فاکتورها', icon: React.createElement(QuotationIcon),
                subViews: [
                    { id: 'registerQuotation', label: 'عملیات' },
                     { id: 'reports', label: 'گزارشات' },
                ]
            },
            {
                type: 'module',
                id: 'invoiceManagement', label: 'مدیریت فاکتورها', icon: React.createElement(SalesManagementIcon),
                subViews: [
                     { type: 'subgroup', label: 'تعاریف مشتریان', subViews: [{ id: 'definePersons', label: 'تعریف اشخاص' }] },
                     { type: 'subgroup', label: 'عملیات فروش', subViews: [
                         { id: 'registerSalesInvoice', label: 'ثبت فاکتور فروش اقلام' },
                         { id: 'registerSalesReturnInvoice', label: 'ثبت فاکتور برگشت فروش اقلام' },
                         { id: 'registerAssetSalesInvoice', label: 'ثبت فاکتور فروش دارایی' },
                         { id: 'registerAssetSalesReturnInvoice', label: 'ثبت فاکتور برگشت فروش دارایی' },
                         { id: 'registerServiceSalesInvoice', label: 'ثبت فاکتور فروش خدمات (درآمد)' },
                     ] },
                     { id: 'reports', label: 'گزارشات' },
                ]
            },
        ]
    },
     {
        type: 'module',
        id: 'budgeting', label: 'بودجه ریزی', icon: React.createElement(BudgetingIcon),
        subViews: [
            { id: 'definitions', label: 'تعاریف' },
            {
                type: 'subgroup',
                label: 'عملیات',
                subViews: [
                    { id: 'salesForecast', label: 'پیشبینی فروش' },
                    { id: 'directMaterialPurchaseForecast', label: 'پیشبینی خرید مواد مستقیم' },
                    { id: 'directLaborForecast', label: 'پیشبینی دستمزد مستقیم' },
                    { id: 'otherIncomeExpenseForecast', label: 'پیشبینی سایر درآمدها و هزینه ها' },
                    { id: 'salesTargetControl', label: 'کنترل اهداف فروش' },
                ]
            },
            { id: 'reports', label: 'گزارشات' },
        ]
    },
];