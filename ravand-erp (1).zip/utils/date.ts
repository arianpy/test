// FIX: Renamed imported 'toGregorian' to avoid conflict with local function declaration.
import { toJalaali, toGregorian as toGregorianFromJalali, isValidJalaaliDate } from './jalali';

const SHAMSI_MONTHS = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
];

export function getShamsiMonthName(monthNumber: number): string {
    if (monthNumber < 1 || monthNumber > 12) return '';
    return SHAMSI_MONTHS[monthNumber - 1];
}

export function toShamsi(gregorianDate: string): string { // Expects YYYY-MM-DD
  if (!gregorianDate || typeof gregorianDate !== 'string') return '';
  const parts = gregorianDate.split('-').map(Number);
  if (parts.length < 3 || parts.some(isNaN)) return '';
  const [gy, gm, gd] = parts;
  try {
      const { jy, jm, jd } = toJalaali(gy, gm, gd);
      return `${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`;
  } catch (e) {
      return '';
  }
}

export function toGregorian(shamsiDate: string): string | null { // Expects YYYY/MM/DD
  if (!shamsiDate || typeof shamsiDate !== 'string') return null;
  const parts = shamsiDate.split(/[-/]/);
  if (parts.length !== 3) return null;
  const [jy, jm, jd] = parts.map(Number);
   if (isNaN(jy) || isNaN(jm) || isNaN(jd) || !isValidJalaaliDate(jy, jm, jd)) {
        return null;
   }
  try {
      // FIX: Used the renamed 'toGregorianFromJalali' to call the correct function from the './jalali' module, resolving the recursive call.
      const { gy, gm, gd } = toGregorianFromJalali(jy, jm, jd);
      return `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(2, '0')}`;
  } catch(e) {
      return null;
  }
}